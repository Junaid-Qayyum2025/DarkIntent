# DarkIntent-GNN Reproducibility Package

Implementation of DarkIntent-GNN: heterogeneous temporal graph neural network for proactive detection of malicious human intent in enterprise networks. The package covers the complete pipeline described in the manuscript: event log adapters, feature engineering (Eqs. 5 to 10), heterogeneous graph construction (5 node types, 8 relation types, Eqs. 2 and 4), hierarchical node, edge and subgraph attention (Eqs. 11 to 16), temporal GCN with GRU recurrence (Eqs. 17 to 21), learnable threat propagation (Eqs. 22 to 24), multi-task learning with focal loss and meta learned task weights (Eqs. 25 to 29), all baselines, every experiment in Section IV, and the publication figure scripts.

## Layout

```
darkintent/
  data/        schema.py, features.py, graph_builder.py, synthetic.py, cert.py, lanl.py, netflow.py, loader.py
  models/      layers.py (attention, temporal, propagation), darkintent_gnn.py, losses.py, baselines.py
  utils/       common.py, metrics.py
  experiment.py          shared train / evaluate loop (temporal split, early stopping, validation threshold)
  train.py               main entry (Table 2 style evaluation over 5 seeds)
  run_baselines.py       Tables 2 and 10, Fig. 5
  ablation.py            Table 4, Fig. 7
  sensitivity.py         Table 5, Fig. 8
  efficiency.py          Table 6, Fig. 9
  imbalance.py           Table 7, Fig. 10
  zero_day.py            Table 8, Fig. 11
  early_warning.py       Tables 3 and 9, Figs. 6 and 12
  interpretability.py    Fig. 13
configs/default.yaml     hyperparameters from Section IV-A (d=256, dk=64, K=8, 72 h window, 3 hops, Adam, lr 1e-3 cosine, dropout 0.3)
figures/scripts/         fig5.py to fig13.py (600 dpi PNG plus PDF, Times New Roman)
figures/output/          rendered figures
results/tables/paper_tables.csv   values reported in the manuscript
scripts/run_all.sh, scripts/smoke_test.sh
data/README.md           where to place the raw datasets
```

## Install

```
pip install -r requirements.txt
```
CPU is enough for the synthetic smoke test; the full experiments were run on an NVIDIA A100 40 GB.

## Quick check

```
bash scripts/smoke_test.sh
```
This trains on generated enterprise logs (no download needed) and writes `results/tables/smoke.json`.

## Full reproduction

1. Download the four datasets to the folders listed in `data/README.md`.
2. `DATASET=cert bash scripts/run_all.sh` (repeat with lanl, unsw, cicids).
3. Every script writes a JSON file under `results/tables/`; the figure scripts read the tabulated values.

Individual experiments accept `--epochs`, `--seeds 42,43`, `--max_windows N` for shorter runs.

## Implementation notes

1. Graph windows: each 72 h window is split into 24 h snapshots; user labels are assigned per window and never enter the feature matrix. Windows are ordered in time and split 60/20/20 for train, validation and test, so evaluation is always on later data.
2. Hierarchical attention: edge level attention is applied per relation, the relation specific embeddings are fused by subgraph attention, and a softmax weighted combination over 0 to L hop representations is used before the temporal module to avoid oversmoothing at 3 hops.
3. Threat propagation: lambda is a sigmoid parameterised learnable scalar initialised at 0.5; alpha_neural is fixed to 0.7.
4. Multi-task: task weights are updated after each epoch with the validation losses (Eq. 29). The auxiliary heads receive gradient scaled access to the shared trunk (`aux_grad_scale`) so that sparse category labels do not dominate the intent objective.
5. Decision threshold is selected on the validation set by F1; AUC is threshold free.
6. Lead time follows the definition in Section IV-I: time between the first high confidence alert for a user and the first labelled malicious event.

## Reporting

`results/tables/paper_tables.csv` lists the values that appear in the manuscript. Numbers obtained from a fresh run depend on the dataset preprocessing, hardware and seeds; the package fixes seeds (42 to 46) and reports mean and standard deviation over five runs, as in the paper.

## Contact

favadhassanjaskani@gmail.com, 233217041@seu.edu.cn
