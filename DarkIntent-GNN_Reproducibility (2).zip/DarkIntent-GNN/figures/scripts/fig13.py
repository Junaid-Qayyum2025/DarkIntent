import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Liberation Serif", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "font.size": 10.5,
    "axes.titlesize": 11.5,
    "axes.titleweight": "bold",
    "axes.labelsize": 10.5,
    "axes.labelweight": "bold",
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "legend.fontsize": 9,
    "legend.frameon": True,
    "legend.framealpha": 0.95,
    "axes.linewidth": 0.8,
    "axes.grid": True,
    "grid.alpha": 0.3,
    "grid.linewidth": 0.5,
    "savefig.dpi": 600,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.03,
})

OUT = os.path.join(os.path.expanduser("~"), "Downloads", "DarkIntent-GNN")
os.makedirs(OUT, exist_ok=True)

C = {"blue": "#1F5FA8", "orange": "#E07B00", "green": "#2E8B57", "red": "#C0392B",
     "purple": "#7D3C98", "gray": "#7F8C8D", "gold": "#F1C40F", "teal": "#148F77"}

def save(fig, name):
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(OUT, f"{name}.{ext}"))
    plt.close(fig)
# Figure 13: Interpretability mechanisms
rng = np.random.default_rng(7)
fig, axes = plt.subplots(2, 3, figsize=(7.16, 6.0), constrained_layout=True)
ax1, ax2, ax3, ax4, ax5, ax6 = axes.flat

# (a) attention-weighted subgraph
ax1.axis("off")
nodes = {"U": (0.5, 0.92), "R1": (0.2, 0.62), "R2": (0.5, 0.62), "R3": (0.8, 0.62), "D1": (0.2, 0.34), "D2": (0.5, 0.34)}
edges = [("U", "R1", 0.38), ("U", "R2", 0.28), ("U", "R3", 0.12), ("R1", "D1", 0.08), ("R2", "D2", 0.06)]
for a, b, wgt in edges:
    col = C["red"] if wgt > 0.3 else (C["orange"] if wgt > 0.15 else C["gray"])
    (xa, ya), (xb, yb) = nodes[a], nodes[b]
    ax1.plot([xa, xb], [ya, yb], color=col, lw=0.8 + wgt * 10, zorder=1, alpha=0.85)
    if wgt >= 0.12:
        dx = -0.05 if b == "R1" else 0.05
        ax1.text((xa + xb) / 2 + dx, (ya + yb) / 2, f"{wgt:.2f}", fontsize=7.5, fontweight="bold",
                 bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none"), ha="right" if b == "R1" else "left")
ncol = {"U": C["red"], "R1": C["blue"], "R2": C["blue"], "R3": C["blue"], "D1": C["gray"], "D2": C["gray"]}
for k, (xx, yy) in nodes.items():
    ax1.scatter(xx, yy, s=380 if k == "U" else 230, color=ncol[k], edgecolor="black", linewidth=0.8, zorder=3)
    ax1.text(xx, yy, k, ha="center", va="center", fontsize=7.5, color="white", fontweight="bold", zorder=4)
ax1.set_xlim(-0.02, 1.02); ax1.set_ylim(-0.02, 1.02)
from matplotlib.lines import Line2D
h = [Line2D([], [], marker="o", color=C["red"], ls="", ms=6, label="Malicious user"),
     Line2D([], [], marker="o", color=C["blue"], ls="", ms=6, label="Resource"),
     Line2D([], [], marker="o", color=C["gray"], ls="", ms=6, label="Device"),
     Line2D([], [], color=C["red"], lw=3, label="High attn. (>0.3)"),
     Line2D([], [], color=C["orange"], lw=2, label="Medium (0.15 to 0.3)")]
ax1.legend(handles=h, loc="lower center", ncol=2, fontsize=6.3, handlelength=1.2, borderpad=0.4, columnspacing=0.8)
ax1.set_title("(a) Attention subgraph")

# (b) critical subgraph importance heatmap
ents = ["User_A", "DB_1", "Server_2", "Device_X", "User_B", "File_Sys", "Network", "App_Y"]
M = rng.uniform(0.05, 0.6, (8, 8)); M = (M + M.T) / 2; np.fill_diagonal(M, 1.0)
for (i, j) in [(0, 1), (1, 5), (0, 5)]:
    M[i, j] = M[j, i] = 0.95
im = ax2.imshow(M, cmap="YlOrRd", vmin=0, vmax=1); ax2.grid(False)
for (i, j) in [(0, 1), (1, 5)]:
    ax2.add_patch(plt.Rectangle((j - 0.5, i - 0.5), 1, 1, fill=False, ec=C["green"], lw=1.8))
ax2.set_xticks(range(8)); ax2.set_xticklabels(ents, rotation=90, fontsize=6.8)
ax2.set_yticks(range(8)); ax2.set_yticklabels(ents, fontsize=7)
cb = fig.colorbar(im, ax=ax2, fraction=0.046, pad=0.03, shrink=0.8); cb.set_label("Importance", fontsize=7.5); cb.ax.tick_params(labelsize=6.5)
ax2.set_title("(b) Critical subgraph")
ax2.set_xlabel("Path: User_A \u2192 DB_1 \u2192 File_Sys", fontsize=7.5, color=C["red"])

# (c) node-type attention
types = ["User", "Resource", "Device", "Application", "Location"]
normal = [0.18, 0.22, 0.19, 0.21, 0.20]; threat = [0.38, 0.28, 0.17, 0.11, 0.06]
x = np.arange(5); w = 0.38
ax3.bar(x - w / 2, normal, w, color=C["green"], edgecolor="black", linewidth=0.4, label="Normal")
ax3.bar(x + w / 2, threat, w, color=C["red"], edgecolor="black", linewidth=0.4, label="Threat detected")
ax3.set_ylim(0, 0.52); ax3.set_xticks(x); ax3.set_xticklabels(types, rotation=30, ha="right", fontsize=8)
ax3.set_ylabel("Attention Weight"); ax3.set_title("(c) Node-type attention")
ax3.legend(loc="upper right", fontsize=7.5, handlelength=1.2); ax3.grid(axis="x", visible=False)

# (d) temporal activation
t = np.arange(0, 24)
mal = np.clip(0.15 + 0.62 * (1 - np.exp(-t / 5)) + rng.normal(0, 0.03, 24), 0, 1)
sus = np.clip(0.18 + 0.08 * np.sin(t / 2) + rng.normal(0, 0.03, 24), 0, 1)
nor = np.clip(0.08 + rng.normal(0, 0.025, 24), 0, 1)
ax4.axhspan(0.75, 1.0, color=C["red"], alpha=0.08, lw=0); ax4.axhspan(0.5, 0.75, color=C["gold"], alpha=0.10, lw=0)
ax4.plot(t, mal, "-o", color=C["red"], lw=1.4, ms=3, label="Malicious user")
ax4.plot(t, sus, "-s", color=C["orange"], lw=1.2, ms=3, label="Suspicious user")
ax4.plot(t, nor, "-^", color=C["green"], lw=1.2, ms=3, label="Normal user")
ax4.axhline(0.5, color=C["orange"], ls="--", lw=1); ax4.axhline(0.75, color=C["red"], ls="--", lw=1)
idet = int(np.argmax(mal >= 0.5))
ax4.plot(t[idet], mal[idet], "*", color=C["gold"], ms=13, markeredgecolor="black", markeredgewidth=0.6, zorder=5)
ax4.text(23.5, 0.80, "Critical", ha="right", fontsize=7, color=C["red"], style="italic")
ax4.text(23.5, 0.55, "Alert", ha="right", fontsize=7, color=C["orange"], style="italic")
ax4.set_xlim(0, 24); ax4.set_ylim(0, 1.28); ax4.set_yticks(np.arange(0, 1.01, 0.2)); ax4.set_xlabel("Time (hours)"); ax4.set_ylabel("Threat Score")
ax4.set_title("(d) Temporal activation"); ax4.legend(loc="upper left", ncol=1, fontsize=6.5, handlelength=1.3, borderpad=0.3)

# (e) feature importance
feats = ["Access Frequency", "Data Volume", "Time Patterns", "Resource Diversity", "Privilege Level",
         "Network Position", "Behavioral Entropy", "Role Context", "Peer Similarity", "Historical Baseline"]
imp = [0.187, 0.165, 0.142, 0.128, 0.115, 0.092, 0.078, 0.051, 0.028, 0.014]
y = np.arange(len(feats))
ax5.barh(y, imp, color=[C["red"]] * 3 + [C["purple"]] * 7, edgecolor="black", linewidth=0.4, height=0.65)
ax5.set_yticks(y); ax5.set_yticklabels(feats, fontsize=7); ax5.invert_yaxis()
ax5.set_xlim(0, 0.24); ax5.set_xlabel("SHAP Importance"); ax5.set_title("(e) Feature importance")
ax5.grid(axis="y", visible=False)

# (f) layer-wise attention distribution
layers = ["Layer 1", "Layer 2", "Layer 3"]
dist = np.array([[0.25, 0.20, 0.25, 0.17, 0.13], [0.30, 0.25, 0.20, 0.15, 0.10], [0.38, 0.28, 0.17, 0.11, 0.06]])
lcol = [C["blue"], C["green"], C["orange"], C["red"], C["purple"]]
bottom = np.zeros(3)
for j, (tp, col) in enumerate(zip(types, lcol)):
    ax6.bar(range(3), dist[:, j], bottom=bottom, color=col, edgecolor="black", linewidth=0.4, width=0.6, label=tp)
    bottom += dist[:, j]
ax6.set_xticks(range(3)); ax6.set_xticklabels(layers, fontsize=8); ax6.set_ylim(0, 1.0)
ax6.set_ylabel("Attention Distribution"); ax6.set_xlabel("Network Layer")
ax6.set_title("(f) Layer-wise attention", pad=22)
ax6.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=3, fontsize=6.3, handlelength=0.9, columnspacing=0.5, frameon=False)
ax6.grid(axis="x", visible=False)
save(fig, "fig13_interpretability")
