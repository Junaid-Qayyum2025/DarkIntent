import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Liberation Serif", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "font.size": 10.5,
    "axes.titlesize": 11.5,
    "axes.titleweight": "bold",
    "axes.labelsize": 10.5,
    "axes.labelweight": "bold",
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "legend.fontsize": 9,
    "legend.frameon": True,
    "legend.framealpha": 0.95,
    "axes.linewidth": 0.8,
    "axes.grid": True,
    "grid.alpha": 0.3,
    "grid.linewidth": 0.5,
    "savefig.dpi": 600,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.03,
})

OUT = os.path.join(os.path.expanduser("~"), "Downloads", "DarkIntent-GNN")
os.makedirs(OUT, exist_ok=True)

C = {"blue": "#1F5FA8", "orange": "#E07B00", "green": "#2E8B57", "red": "#C0392B",
     "purple": "#7D3C98", "gray": "#7F8C8D", "gold": "#F1C40F", "teal": "#148F77"}

def save(fig, name):
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(OUT, f"{name}.{ext}"))
    plt.close(fig)
# Figure 7: Ablation study (Table 4)
comps = ["Heterogeneous\nGraph", "Hierarchical\nAttention", "Temporal\nGCN", "Threat\nPropagation", "Multi-Task\nLearning"]
gain = [0.057, 0.044, 0.036, 0.027, 0.020]
cfgs = ["Full Model", "w/o Het. Graph", "w/o Hier. Attention", "w/o Temporal GCN", "w/o Threat Prop.", "w/o Multi-Task"]
acc = [0.978, 0.921, 0.934, 0.942, 0.951, 0.958]
f1  = [0.974, 0.916, 0.929, 0.937, 0.947, 0.953]
auc = [0.993, 0.962, 0.971, 0.976, 0.981, 0.984]
fpr = [0.016, 0.041, 0.035, 0.031, 0.027, 0.023]

fig = plt.figure(figsize=(7.16, 6.2), constrained_layout=True)
gs = fig.add_gridspec(2, 2, height_ratios=[1, 1.05])
ax1 = fig.add_subplot(gs[0, :]); ax2 = fig.add_subplot(gs[1, 0]); ax3 = fig.add_subplot(gs[1, 1])

# (a) waterfall
cols = [C["blue"], C["purple"], C["orange"], C["red"], C["teal"]]
base = 0.0
for i, (g, col) in enumerate(zip(gain, cols)):
    ax1.bar(i, g, bottom=base, color=col, edgecolor="black", linewidth=0.5, width=0.6)
    if i < len(gain) - 1:
        ax1.plot([i + 0.3, i + 0.7], [base + g, base + g], color="black", lw=0.7, ls=":")
    base += g
ax1.bar(len(gain), base, color=C["green"], edgecolor="black", linewidth=0.8, width=0.6)
ax1.set_xticks(range(len(gain) + 1)); ax1.set_xticklabels(comps + ["Full\nModel"])
ax1.set_ylim(0, 0.225); ax1.set_ylabel("Cumulative Accuracy Gain")
ax1.set_title("(a) Sequential component contribution to accuracy (CERT)")
ax1.grid(axis="x", visible=False)

# (b) grouped bars
x = np.arange(len(cfgs)); w = 0.2
for i, (lab, v, col) in enumerate([("Accuracy", acc, C["blue"]), ("F1-Score", f1, C["green"]),
                                   ("AUC", auc, C["purple"]), ("FPR (×10)", [10 * v for v in fpr], C["red"])]):
    ax2.bar(x + (i - 1.5) * w, v, w, label=lab, color=col, edgecolor="black", linewidth=0.4)
ax2.axhline(0.978, color=C["green"], ls="--", lw=1)
ax2.set_ylim(0, 1.25); ax2.set_yticks(np.arange(0, 1.01, 0.2)); ax2.set_xticks(x); ax2.set_xticklabels(cfgs, fontsize=8, rotation=35, ha="right")
ax2.set_ylabel("Score"); ax2.set_title("(b) Metrics per ablation configuration")
ax2.legend(loc="upper center", ncol=4, fontsize=8, handlelength=1, columnspacing=0.6, bbox_to_anchor=(0.5, 1.0))
ax2.grid(axis="x", visible=False)

# (c) heatmap
data = np.array([acc, f1, auc, fpr]).T
norm = data.copy()
for j in range(3):
    norm[:, j] = (data[:, j] - data[:, j].min()) / (data[:, j].max() - data[:, j].min())
norm[:, 3] = 1 - (data[:, 3] - data[:, 3].min()) / (data[:, 3].max() - data[:, 3].min())
im = ax3.imshow(norm, cmap="RdYlGn", vmin=0, vmax=1, aspect="auto")
for i in range(6):
    for j in range(4):
        ax3.text(j, i, f"{data[i, j]:.3f}", ha="center", va="center", fontsize=8.5,
                 color="black" if 0.25 < norm[i, j] < 0.85 else "white", fontweight="bold")
ax3.set_xticks(range(4)); ax3.set_xticklabels(["Accuracy", "F1-Score", "AUC", "FPR"])
ax3.set_yticks(range(6)); ax3.set_yticklabels(cfgs, fontsize=8.5)
ax3.set_title("(c) Normalized metric heatmap"); ax3.grid(False)
cb = fig.colorbar(im, ax=ax3, fraction=0.045, pad=0.02); cb.set_label("Normalized performance", fontsize=9)
save(fig, "fig7_ablation_study")
