import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Liberation Serif", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "font.size": 10.5,
    "axes.titlesize": 11.5,
    "axes.titleweight": "bold",
    "axes.labelsize": 10.5,
    "axes.labelweight": "bold",
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "legend.fontsize": 9,
    "legend.frameon": True,
    "legend.framealpha": 0.95,
    "axes.linewidth": 0.8,
    "axes.grid": True,
    "grid.alpha": 0.3,
    "grid.linewidth": 0.5,
    "savefig.dpi": 600,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.03,
})

OUT = os.path.join(os.path.expanduser("~"), "Downloads", "DarkIntent-GNN")
os.makedirs(OUT, exist_ok=True)

C = {"blue": "#1F5FA8", "orange": "#E07B00", "green": "#2E8B57", "red": "#C0392B",
     "purple": "#7D3C98", "gray": "#7F8C8D", "gold": "#F1C40F", "teal": "#148F77"}

def save(fig, name):
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(OUT, f"{name}.{ext}"))
    plt.close(fig)
# Figure 6: Performance by threat type (Table 3)
threats = ["Insider\nThreat", "APT", "Data\nExfiltration", "Privilege\nAbuse", "Lateral\nMovement"]
prec = [0.974, 0.961, 0.982, 0.968, 0.953]
rec  = [0.965, 0.954, 0.978, 0.961, 0.947]
f1   = [0.969, 0.957, 0.980, 0.964, 0.950]
lead = [18.7, 14.3, 22.4, 16.8, 12.1]
samples = [142, 87, 203, 156, 94]

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.16, 3.2), constrained_layout=True,
                               gridspec_kw={"width_ratios": [1.35, 1]})
x = np.arange(len(threats)); w = 0.26
for i, (lab, v, col) in enumerate([("Precision", prec, C["blue"]), ("Recall", rec, C["orange"]), ("F1-Score", f1, C["green"])]):
    ax1.bar(x + (i - 1) * w, v, w, label=lab, color=col, edgecolor="black", linewidth=0.4)
ax1.axhline(0.964, color=C["red"], ls="--", lw=1, label="Average F1 = 0.964")
ax1.set_ylim(0.93, 0.99); ax1.set_xticks(x); ax1.set_xticklabels(threats)
ax1.set_ylabel("Performance Score"); ax1.set_xlabel("Threat Type")
ax1.set_title("(a) Precision, recall and F1 by threat type", pad=18)
ax1.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=4, fontsize=7.5, handlelength=1.1, columnspacing=0.7, frameon=False)

colors = [C["blue"], C["orange"], C["green"], C["red"], C["purple"]]
bars = ax2.barh(x, lead, color=colors, edgecolor="black", linewidth=0.4, height=0.6)
ax2.axvline(16.9, color=C["red"], ls="--", lw=1)
ax2.text(16.9, -0.55, "Avg 16.9 h", ha="center", va="bottom", fontsize=8.5, color=C["red"])
ax2.set_yticks(x); ax2.set_yticklabels([t.replace("\n", " ") for t in threats])
ax2.set_xlim(0, 30); ax2.invert_yaxis()
ax2.set_xlabel("Prediction Lead Time (hours)")
ax2.set_title("(b) Early-warning lead time", pad=18)
ax2.grid(axis="y", visible=False)
save(fig, "fig6_threat_type_performance")
