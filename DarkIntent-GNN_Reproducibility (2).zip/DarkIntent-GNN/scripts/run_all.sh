#!/usr/bin/env bash
# Full experimental pipeline. Set DATASET to cert | lanl | unsw | cicids after placing the raw files under ./data
set -e
DATASET=${DATASET:-synthetic}
python -m darkintent.train          --dataset $DATASET --out results/tables/overall.json
python -m darkintent.run_baselines  --dataset $DATASET --out results/tables/baselines.json      # Tables 2, 10 / Fig. 5
python -m darkintent.ablation       --dataset $DATASET --out results/tables/ablation.json       # Table 4 / Fig. 7
python -m darkintent.sensitivity    --dataset $DATASET --out results/tables/sensitivity.json    # Table 5 / Fig. 8
python -m darkintent.efficiency     --dataset $DATASET --out results/tables/efficiency.json     # Table 6 / Fig. 9
python -m darkintent.imbalance      --dataset $DATASET --out results/tables/imbalance.json      # Table 7 / Fig. 10
python -m darkintent.zero_day       --dataset $DATASET --out results/tables/zero_day.json       # Table 8 / Fig. 11
python -m darkintent.early_warning  --dataset $DATASET --out results/tables/early_warning.json  # Table 3, 9 / Fig. 6, 12
python -m darkintent.interpretability --dataset $DATASET --out results/tables/interpretability.json  # Fig. 13
cd figures/scripts && for f in fig*.py; do python $f; done
