#!/usr/bin/env bash
# Two-minute CPU check that the whole pipeline runs on synthetic logs
set -e
python -m darkintent.train --dataset synthetic --epochs 5 --seeds 42 --max_windows 8 --out results/tables/smoke.json
