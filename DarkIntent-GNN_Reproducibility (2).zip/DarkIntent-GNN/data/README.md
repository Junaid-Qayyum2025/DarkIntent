Place raw datasets here (not distributed with the package):

data/cert_r4.2/        logon.csv device.csv http.csv email.csv file.csv LDAP/*.csv answers/insiders.csv
                       https://kilthub.cmu.edu/articles/dataset/Insider_Threat_Test_Dataset/12841247
data/lanl/             auth.txt.gz redteam.txt.gz         https://csr.lanl.gov/data/cyber1/
data/unsw_nb15/        UNSW-NB15_1.csv ... _4.csv, NUSW-NB15_features.csv   https://research.unsw.edu.au/projects/unsw-nb15-dataset
data/cic_ids2017/      *.csv (MachineLearningCVE)         https://www.unb.ca/cic/datasets/ids-2017.html
