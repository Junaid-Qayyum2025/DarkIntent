"""Node and edge feature engineering (Section III-B, Eqs. 5 to 10)."""
import numpy as np
import pandas as pd


def _entropy(counts):
    p = np.asarray(counts, dtype=float); p = p / max(p.sum(), 1e-9)
    p = p[p > 0]
    return float(-(p * np.log(p)).sum())


def user_features(ev: pd.DataFrame, window_hours: float) -> pd.DataFrame:
    """Behavioral (Eq. 5), contextual (Eq. 6) and statistical (Eq. 7) features per user.
    `ev` is the event frame restricted to the current temporal window."""
    rows = []
    hours = (ev["timestamp"] % 24.0)
    ev = ev.assign(hour=hours, after_hours=((hours < 7) | (hours > 19)).astype(float),
                   day=(ev["timestamp"] // 24.0).astype(int))
    global_action_freq = ev["action"].value_counts(normalize=True)
    for u, g in ev.groupby("user", sort=True):
        n = len(g)
        # behavioral
        f_freq = n / max(window_hours, 1.0)
        f_time = g["after_hours"].mean()
        f_diversity = g["resource"].nunique() / max(n, 1)
        f_volume = np.log1p(g["bytes"].sum())
        acts = g["action"].astype("category").cat.codes.values
        f_sequence = float(np.mean(np.diff(acts) != 0)) if n > 1 else 0.0
        # contextual
        role_code = float(hash(g["role"].iloc[0]) % 97) / 97.0
        dept_code = float(hash(g["dept"].iloc[0]) % 97) / 97.0
        f_tenure = float(g["tenure"].iloc[0]) / 120.0
        f_priv = float(g["privilege"].max())
        f_loc = g["location"].nunique() / max(n, 1)
        # statistical
        per_day = g.groupby("day").size().values
        mu = float(per_day.mean()); sd = float(per_day.std()) if len(per_day) > 1 else 0.0
        ent = _entropy(g["action"].value_counts().values)
        rare = float(np.mean([1.0 - global_action_freq.get(a, 0.0) for a in g["action"]]))
        rows.append([u, f_freq, f_time, f_diversity, f_volume, f_sequence,
                     role_code, dept_code, f_tenure, f_priv, f_loc,
                     mu, sd, ent, rare])
    cols = ["user", "f_freq", "f_time", "f_diversity", "f_volume", "f_sequence",
            "f_role", "f_dept", "f_tenure", "f_privilege", "f_location",
            "mu_access", "sigma_access", "entropy_actions", "rareness_events"]
    return pd.DataFrame(rows, columns=cols)


USER_FEATURE_DIM = 14


def entity_features(ev: pd.DataFrame, col: str, window_hours: float) -> pd.DataFrame:
    """Generic features for resource / device / application / location nodes."""
    rows = []
    for e, g in ev.groupby(col, sort=True):
        n = len(g)
        rows.append([e, n / max(window_hours, 1.0), g["user"].nunique() / max(n, 1),
                     np.log1p(g["bytes"].sum()), float(g["label"].mean()) * 0.0,  # label never leaks; placeholder 0
                     _entropy(g["action"].value_counts().values)])
    return pd.DataFrame(rows, columns=[col, "e_freq", "e_user_div", "e_volume", "e_zero", "e_entropy"])


ENTITY_FEATURE_DIM = 5


def edge_weights(g: pd.DataFrame, t_current: float, tau: float, importance: float = 1.0):
    """Eq. 9 and Eq. 10: (w_freq, w_recency, w_importance, t_first, t_last)."""
    t_first = float(g["timestamp"].min()); t_last = float(g["timestamp"].max())
    w_freq = np.log1p(len(g))
    w_rec = float(np.exp(-(t_current - t_last) / max(tau, 1e-6)))
    return [w_freq, w_rec, importance, t_first / max(t_current, 1.0), t_last / max(t_current, 1.0)]


EDGE_FEATURE_DIM = 5
