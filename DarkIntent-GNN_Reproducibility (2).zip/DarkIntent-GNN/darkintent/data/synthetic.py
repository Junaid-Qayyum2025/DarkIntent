"""Synthetic enterprise log generator used for smoke tests and CI.

It reproduces the *shape* of the CERT scenario logs (users, resources, devices,
after-hours access, exfiltration bursts, preparatory behaviour with a lead time)
so that the full pipeline runs without downloading any dataset. It is NOT a
substitute for the benchmark datasets used in the paper.
"""
import numpy as np
import pandas as pd
from .schema import normalize_events, THREAT_TYPES


def generate(num_users=200, days=14, malicious_frac=0.15, seed=0, imbalance_ratio=None):
    rng = np.random.default_rng(seed)
    hours = days * 24
    n_res, n_dev, n_app, n_loc = 60, 40, 8, 5
    roles = ["staff", "engineer", "manager", "admin"]
    depts = [f"dept{i}" for i in range(6)]
    users = [f"u{i:04d}" for i in range(num_users)]
    role_of = {u: rng.choice(roles) for u in users}
    dept_of = {u: rng.choice(depts) for u in users}
    tenure_of = {u: float(rng.integers(1, 120)) for u in users}
    home_dev = {u: f"d{rng.integers(0, n_dev):03d}" for u in users}
    fav_res = {u: rng.choice(n_res, size=6, replace=False) for u in users}
    n_mal = int(round(num_users * malicious_frac)) if imbalance_ratio is None else max(1, num_users // (imbalance_ratio + 1))
    mal_users = set(rng.choice(users, size=n_mal, replace=False))
    rows = []
    for u in users:
        rate = rng.uniform(4, 12)  # events per working day
        for d in range(days):
            k = rng.poisson(rate)
            for _ in range(k):
                h = float(np.clip(rng.normal(13, 3), 0, 23.99))
                r = f"r{rng.choice(fav_res[u]) if rng.random() < 0.8 else rng.integers(0, n_res):03d}"
                act = rng.choice(["logon", "http", "file_read", "email", "file_copy"], p=[.25, .35, .2, .15, .05])
                peer = rng.choice(users) if act == "email" else ""
                rows.append([u, r, home_dev[u], f"app{rng.integers(0, n_app)}", f"loc{depts.index(dept_of[u]) % n_loc}",
                             act, d * 24 + h, float(rng.lognormal(6, 1)), role_of[u], dept_of[u],
                             int(role_of[u] == "admin"), tenure_of[u], 0, -1, "", peer])
    # malicious scenarios: preparatory phase (labelled, low intensity) then attack burst
    for j, u in enumerate(sorted(mal_users)):
        ttype = int(rng.integers(0, len(THREAT_TYPES)))
        attack_t = rng.uniform(40, hours - 6)
        lead = rng.uniform(8, 30)
        scen = f"s{j:03d}"
        # threat-type specific preparatory signature
        n_prep = int(rng.integers(12, 30)) if ttype != 1 else int(rng.integers(30, 60))   # APT: long, low intensity
        for _ in range(n_prep):
            t = rng.uniform(attack_t - (lead if ttype != 1 else lead * 2.5), attack_t)
            day = int(t // 24)
            if ttype in (0, 2):      # insider / exfiltration: after hours
                h = rng.choice([rng.uniform(0, 6), rng.uniform(20, 23.9)])
            else:
                h = float(np.clip(rng.normal(13, 3), 0, 23.99))
            t = day * 24 + h
            act = {0: "file_read", 1: "http", 2: "file_copy", 3: "logon", 4: "logon"}[ttype]
            dev = home_dev[u] if ttype in (0, 2) else f"d{rng.integers(0, n_dev):03d}"      # lateral / priv / APT hop devices
            byt = {0: 7.5, 1: 6.0, 2: 9.5, 3: 6.5, 4: 6.0}[ttype]
            rows.append([u, f"r{rng.integers(0, n_res):03d}", dev,
                         f"app{rng.integers(0, n_app)}", f"loc{rng.integers(0, n_loc)}", act, t, float(rng.lognormal(byt, 1)),
                         role_of[u], dept_of[u], int(ttype == 3 or role_of[u] == "admin"), tenure_of[u],
                         1, ttype, scen, ""])
        for _ in range(int(rng.integers(15, 40))):         # execution burst
            t = attack_t + rng.uniform(0, 3)
            rows.append([u, f"r{rng.integers(0, n_res):03d}", f"d{rng.integers(0, n_dev):03d}",
                         f"app{rng.integers(0, n_app)}", f"loc{rng.integers(0, n_loc)}",
                         "file_copy" if ttype == 2 else "logon", t, float(rng.lognormal(9, 1)),
                         role_of[u], dept_of[u], 1, tenure_of[u], 1, ttype, scen, ""])
    cols = ["user", "resource", "device", "application", "location", "action", "timestamp", "bytes",
            "role", "dept", "privilege", "tenure", "label", "threat_type", "scenario", "peer"]
    return normalize_events(pd.DataFrame(rows, columns=cols))
