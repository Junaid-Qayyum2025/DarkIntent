"""Common event schema used by every dataset adapter.

Every adapter returns a pandas DataFrame with the columns below. Missing
columns are filled with defaults by `normalize_events`.

  user        str   actor identifier (user id, account, source IP)
  resource    str   accessed object (file, host, URL, destination IP)
  device      str   endpoint used by the actor
  application str   application or service (http, email, ssh, ...)
  location    str   coarse location (dept, subnet, site)
  action      str   action type (logon, file_copy, email, http, flow, ...)
  timestamp   float hours since dataset start
  bytes       float data volume associated with the event
  role        str   contextual attribute of the user
  dept        str
  privilege   int   0 normal, 1 elevated
  tenure      float months in organization
  label       int   1 if the event belongs to a malicious scenario
  threat_type int   0 insider, 1 apt, 2 exfiltration, 3 priv_abuse, 4 lateral, -1 none
  scenario    str   id of the malicious scenario (for lead time), '' otherwise
"""
import numpy as np
import pandas as pd

NODE_TYPES = ["user", "resource", "device", "application", "location"]
EDGE_TYPES = ["access", "comm", "own", "trust", "hier", "sim", "temp", "priv"]
THREAT_TYPES = ["insider_threat", "apt", "data_exfiltration", "privilege_abuse", "lateral_movement"]

REQUIRED = ["user", "resource", "timestamp"]
DEFAULTS = {"device": "dev_unknown", "application": "app_unknown", "location": "loc_unknown",
            "action": "generic", "bytes": 0.0, "role": "staff", "dept": "none", "privilege": 0,
            "tenure": 12.0, "label": 0, "threat_type": -1, "scenario": "", "peer": ""}


def normalize_events(df: pd.DataFrame) -> pd.DataFrame:
    for c in REQUIRED:
        if c not in df.columns:
            raise ValueError(f"event frame is missing required column '{c}'")
    for c, v in DEFAULTS.items():
        if c not in df.columns:
            df[c] = v
    df = df.copy()
    df["timestamp"] = df["timestamp"].astype(float)
    df["timestamp"] -= df["timestamp"].min()
    df["bytes"] = df["bytes"].fillna(0.0).astype(float)
    df["label"] = df["label"].fillna(0).astype(int)
    df["threat_type"] = df["threat_type"].fillna(-1).astype(int)
    df["scenario"] = df["scenario"].fillna("").astype(str)
    df["peer"] = df["peer"].fillna("").astype(str)
    for c in ["user", "resource", "device", "application", "location", "action", "role", "dept"]:
        df[c] = df[c].astype(str)
    return df.sort_values("timestamp").reset_index(drop=True)
