from . import synthetic, cert, lanl, netflow


def load_events(name: str, root: str, **kw):
    name = name.lower()
    if name == "synthetic":
        return synthetic.generate(**kw)
    if name == "cert":
        return cert.load(root, **kw)
    if name == "lanl":
        return lanl.load(root, **kw)
    if name in ("unsw", "unsw_nb15"):
        return netflow.load_unsw(root, **kw)
    if name in ("cicids", "cic_ids2017"):
        return netflow.load_cicids(root, **kw)
    raise ValueError(f"unknown dataset {name}")
