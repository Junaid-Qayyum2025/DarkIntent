"""LANL Comprehensive Cyber Security Events adapter.
Download: https://csr.lanl.gov/data/cyber1/  (auth.txt.gz, redteam.txt.gz)."""
import os
import pandas as pd
from .schema import normalize_events


def load(root, max_rows=5_000_000):
    d = os.path.join(root, "lanl")
    auth = pd.read_csv(os.path.join(d, "auth.txt.gz"), header=None, nrows=max_rows,
                       names=["time", "src_user", "dst_user", "src_comp", "dst_comp", "auth_type",
                              "logon_type", "orientation", "success"])
    auth = auth[~auth["src_user"].str.endswith("$")]  # drop machine accounts
    ev = pd.DataFrame({"user": auth["src_user"], "resource": auth["dst_comp"], "device": auth["src_comp"],
                       "application": auth["auth_type"].astype(str), "action": auth["logon_type"].astype(str),
                       "timestamp": auth["time"] / 3600.0, "bytes": 0.0,
                       "privilege": auth["dst_user"].str.contains("ADMIN|SYSTEM", case=False).astype(int),
                       "location": auth["src_comp"].str[:3]})
    red = os.path.join(d, "redteam.txt.gz")
    ev["label"] = 0; ev["threat_type"] = -1; ev["scenario"] = ""
    if os.path.exists(red):
        R = pd.read_csv(red, header=None, names=["time", "user", "src_comp", "dst_comp"])
        key = set(zip(R["time"], R["user"], R["src_comp"], R["dst_comp"]))
        m = [(t, u, s, c) in key for t, u, s, c in zip(auth["time"], auth["src_user"], auth["src_comp"], auth["dst_comp"])]
        m = pd.Series(m, index=ev.index)
        ev.loc[m, "label"] = 1; ev.loc[m, "threat_type"] = 4  # red team = lateral movement / APT style
        ev.loc[m, "scenario"] = "lanl_red_" + ev.loc[m, "user"]
    return normalize_events(ev)
