"""Temporal heterogeneous graph construction (Section III-B, Eqs. 2 and 4).

Produces a sequence of graph snapshots G_1 ... G_T over the temporal window.
Node types: user, resource, device, application, location.
Edge types (8): access, comm, own, trust, hier, sim, temp, priv.
"""
from dataclasses import dataclass, field
from typing import Dict, List
import numpy as np
import pandas as pd
import torch
from sklearn.neighbors import NearestNeighbors

from .schema import NODE_TYPES, EDGE_TYPES
from .features import (user_features, entity_features, edge_weights,
                       USER_FEATURE_DIM, ENTITY_FEATURE_DIM, EDGE_FEATURE_DIM)


@dataclass
class Snapshot:
    edge_index: torch.Tensor      # [2, E]
    edge_type: torch.Tensor       # [E]
    edge_attr: torch.Tensor       # [E, 5]
    x: torch.Tensor               # [N, F] window specific node features


@dataclass
class HeteroTemporalGraph:
    node_type: torch.Tensor                 # [N]
    node_names: List[str]
    user_index: torch.Tensor                # indices of user nodes
    snapshots: List[Snapshot]
    y_intent: torch.Tensor                  # [U] 0/1
    y_category: torch.Tensor                # [U] threat type or -1
    anomaly_target: torch.Tensor            # [U] self-supervised anomaly target
    attack_time: torch.Tensor               # [U] hours, nan if benign
    window_end: float
    meta: dict = field(default_factory=dict)

    @property
    def num_nodes(self):
        return int(self.node_type.numel())

    def to(self, dev):
        self.node_type = self.node_type.to(dev); self.user_index = self.user_index.to(dev)
        self.y_intent = self.y_intent.to(dev); self.y_category = self.y_category.to(dev)
        self.anomaly_target = self.anomaly_target.to(dev); self.attack_time = self.attack_time.to(dev)
        for s in self.snapshots:
            s.edge_index = s.edge_index.to(dev); s.edge_type = s.edge_type.to(dev)
            s.edge_attr = s.edge_attr.to(dev); s.x = s.x.to(dev)
        return self


NODE_FEATURE_DIM = max(USER_FEATURE_DIM, ENTITY_FEATURE_DIM)


class GraphBuilder:
    def __init__(self, window_hours=72.0, snapshot_hours=24.0, tau=24.0, sim_k=5, hetero=True):
        self.window_hours = window_hours; self.snapshot_hours = snapshot_hours
        self.tau = tau; self.sim_k = sim_k; self.hetero = hetero

    # ------------------------------------------------------------------ nodes
    def _index_nodes(self, ev: pd.DataFrame):
        names, types = [], []
        for ti, col in enumerate(NODE_TYPES):
            if not self.hetero and col != "user":
                continue
            for v in sorted(ev[col].unique()):
                names.append(f"{col}:{v}"); types.append(ti)
        idx = {n: i for i, n in enumerate(names)}
        return names, torch.tensor(types, dtype=torch.long), idx

    def _node_matrix(self, ev_win, names, idx):
        X = np.zeros((len(names), NODE_FEATURE_DIM), dtype=np.float32)
        uf = user_features(ev_win, self.window_hours)
        for _, r in uf.iterrows():
            i = idx.get(f"user:{r['user']}")
            if i is not None:
                X[i, :USER_FEATURE_DIM] = r.values[1:].astype(np.float32)
        if self.hetero:
            for col in NODE_TYPES[1:]:
                ef = entity_features(ev_win, col, self.window_hours)
                for _, r in ef.iterrows():
                    i = idx.get(f"{col}:{r[col]}")
                    if i is not None:
                        X[i, :ENTITY_FEATURE_DIM] = r.values[1:].astype(np.float32)
        return X

    # ------------------------------------------------------------------ edges
    def _add(self, store, src, dst, et, attr):
        store["src"].append(src); store["dst"].append(dst); store["et"].append(et); store["attr"].append(attr)

    def _edges(self, ev_win: pd.DataFrame, idx, t_cur, user_feat_matrix, user_ids):
        store = {"src": [], "dst": [], "et": [], "attr": []}
        E = {n: i for i, n in enumerate(EDGE_TYPES)}
        # access / priv: user -> resource
        for (u, r), g in ev_win.groupby(["user", "resource"]):
            su, sr = idx.get(f"user:{u}"), idx.get(f"resource:{r}")
            if su is None or sr is None:
                continue
            priv = float(g["privilege"].max())
            self._add(store, su, sr, E["access"], edge_weights(g, t_cur, self.tau))
            if priv > 0:
                self._add(store, su, sr, E["priv"], edge_weights(g, t_cur, self.tau, importance=2.0))
        if not self.hetero:
            return self._pack(store, ev_win, idx, t_cur, user_feat_matrix, user_ids, E, homogeneous=True)
        # own: user -> device
        for (u, d), g in ev_win.groupby(["user", "device"]):
            su, sd = idx.get(f"user:{u}"), idx.get(f"device:{d}")
            if su is not None and sd is not None:
                self._add(store, su, sd, E["own"], edge_weights(g, t_cur, self.tau))
        # trust: user -> application (authenticated service use)
        for (u, a), g in ev_win.groupby(["user", "application"]):
            su, sa = idx.get(f"user:{u}"), idx.get(f"application:{a}")
            if su is not None and sa is not None:
                self._add(store, su, sa, E["trust"], edge_weights(g, t_cur, self.tau))
        # hier: user -> location (department / site membership)
        for (u, l), g in ev_win.groupby(["user", "location"]):
            su, sl = idx.get(f"user:{u}"), idx.get(f"location:{l}")
            if su is not None and sl is not None:
                self._add(store, su, sl, E["hier"], edge_weights(g, t_cur, self.tau))
        return self._pack(store, ev_win, idx, t_cur, user_feat_matrix, user_ids, E)

    def _pack(self, store, ev_win, idx, t_cur, ufm, user_ids, E, homogeneous=False):
        # comm: user -> user via explicit peer column (email / message)
        comm = ev_win[ev_win["peer"] != ""]
        for (u, p), g in comm.groupby(["user", "peer"]):
            su, sp = idx.get(f"user:{u}"), idx.get(f"user:{p}")
            if su is not None and sp is not None:
                self._add(store, su, sp, E["comm"], edge_weights(g, t_cur, self.tau))
        # temp: users co-active in the same hour bucket
        ev_win = ev_win.assign(bucket=(ev_win["timestamp"] // 1.0).astype(int))
        for _, g in ev_win.groupby("bucket"):
            us = [idx[f"user:{u}"] for u in g["user"].unique() if f"user:{u}" in idx]
            if len(us) < 2:
                continue
            us = us[:8]  # cap clique size
            for i in range(len(us)):
                for j in range(i + 1, len(us)):
                    a = [1.0, 1.0, 0.5, 0.0, 0.0]
                    self._add(store, us[i], us[j], E["temp"], a); self._add(store, us[j], us[i], E["temp"], a)
        # sim: behavioural kNN among users
        if len(user_ids) > self.sim_k + 1:
            nn = NearestNeighbors(n_neighbors=self.sim_k + 1).fit(ufm)
            _, nb = nn.kneighbors(ufm)
            for i, row in enumerate(nb):
                for j in row[1:]:
                    self._add(store, user_ids[i], user_ids[j], E["sim"], [1.0, 1.0, 0.5, 0.0, 0.0])
        if len(store["src"]) == 0:
            return (torch.zeros(2, 0, dtype=torch.long), torch.zeros(0, dtype=torch.long),
                    torch.zeros(0, EDGE_FEATURE_DIM))
        ei = torch.tensor([store["src"], store["dst"]], dtype=torch.long)
        et = torch.tensor(store["et"], dtype=torch.long)
        ea = torch.tensor(np.asarray(store["attr"], dtype=np.float32))
        if homogeneous:
            et = torch.zeros_like(et)
        return ei, et, ea

    # ------------------------------------------------------------------ build
    def build(self, ev: pd.DataFrame, window_end: float = None) -> HeteroTemporalGraph:
        if window_end is None:
            window_end = float(ev["timestamp"].max())
        window_start = window_end - self.window_hours
        ev_all = ev[(ev["timestamp"] > window_start) & (ev["timestamp"] <= window_end)]
        if len(ev_all) == 0:
            raise ValueError("empty temporal window")
        names, ntype, idx = self._index_nodes(ev_all)
        user_names = [n for n in names if n.startswith("user:")]
        user_ids = [idx[n] for n in user_names]

        snapshots = []
        n_snap = int(np.ceil(self.window_hours / self.snapshot_hours))
        for s in range(n_snap):
            s_start = window_start + s * self.snapshot_hours
            s_end = min(s_start + self.snapshot_hours, window_end)
            ev_s = ev_all[(ev_all["timestamp"] > s_start) & (ev_all["timestamp"] <= s_end)]
            if len(ev_s) == 0:
                ev_s = ev_all.iloc[:1]
            X = self._node_matrix(ev_s, names, idx)
            for t in ntype.unique().tolist():                                        # per node-type standardisation
                m = (ntype == t).numpy()
                X[m] = (X[m] - X[m].mean(0, keepdims=True)) / (X[m].std(0, keepdims=True) + 1e-6)
            ufm = X[user_ids, :USER_FEATURE_DIM]
            ei, et, ea = self._edges(ev_s, idx, s_end, ufm, user_ids)
            snapshots.append(Snapshot(ei, et, ea, torch.tensor(X)))

        # labels at user level (never used as features)
        per_user = ev_all.groupby("user").agg(label=("label", "max"),
                                              threat_type=("threat_type", "max"))
        y_int, y_cat, atk = [], [], []
        for n in user_names:
            u = n.split(":", 1)[1]
            lab = int(per_user.loc[u, "label"]) if u in per_user.index else 0
            y_int.append(lab); y_cat.append(int(per_user.loc[u, "threat_type"]) if lab else -1)
            if lab:
                mal = ev_all[(ev_all["user"] == u) & (ev_all["label"] == 1)]
                atk.append(float(mal["timestamp"].min()))
            else:
                atk.append(float("nan"))
        # anomaly target: deviation of last snapshot behaviour from the user's window mean (Eq. 26 target)
        Xs = np.stack([s.x.numpy()[user_ids, :USER_FEATURE_DIM] for s in snapshots])
        mu, sd = Xs.mean(0), Xs.std(0) + 1e-6
        anomaly = np.abs((Xs[-1] - mu) / sd).mean(1)
        anomaly = (anomaly - anomaly.min()) / (anomaly.max() - anomaly.min() + 1e-9)

        return HeteroTemporalGraph(
            node_type=ntype, node_names=names, user_index=torch.tensor(user_ids, dtype=torch.long),
            snapshots=snapshots, y_intent=torch.tensor(y_int, dtype=torch.float32),
            y_category=torch.tensor(y_cat, dtype=torch.long),
            anomaly_target=torch.tensor(anomaly, dtype=torch.float32),
            attack_time=torch.tensor(atk, dtype=torch.float32), window_end=window_end,
            meta={"window_start": window_start, "num_edges": [int(s.edge_index.shape[1]) for s in snapshots]})


def sliding_windows(ev: pd.DataFrame, builder: GraphBuilder, stride_hours: float, max_windows=None):
    """Yield graphs for consecutive windows across the full event timeline."""
    t_max = float(ev["timestamp"].max()); t = builder.window_hours
    out = []
    while t <= t_max + 1e-9:
        try:
            out.append(builder.build(ev, window_end=t))
        except ValueError:
            pass
        t += stride_hours
        if max_windows and len(out) >= max_windows:
            break
    return out
