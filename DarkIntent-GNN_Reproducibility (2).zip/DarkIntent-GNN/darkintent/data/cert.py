"""CERT Insider Threat Test Dataset r4.2 adapter.
Download: https://kilthub.cmu.edu/articles/dataset/Insider_Threat_Test_Dataset/12841247
Expected files under <root>/cert_r4.2/: logon.csv, device.csv, http.csv, email.csv, file.csv,
LDAP/*.csv, and answers/insiders.csv (scenario ground truth)."""
import os, glob
import numpy as np
import pandas as pd
from .schema import normalize_events

SCENARIO_TO_TYPE = {1: 2, 2: 0, 3: 3, 4: 4, 5: 1}  # CERT scenarios mapped to paper threat categories


def load(root, max_rows=None):
    d = os.path.join(root, "cert_r4.2")
    frames = []
    def read(name, action, res_col, bytes_col=None, peer_col=None):
        p = os.path.join(d, name)
        if not os.path.exists(p):
            return
        df = pd.read_csv(p, nrows=max_rows)
        out = pd.DataFrame({"user": df["user"], "resource": df[res_col].astype(str),
                            "device": df["pc"], "application": action, "action": action,
                            "timestamp": pd.to_datetime(df["date"]).astype("int64") / 3.6e12,
                            "bytes": df[bytes_col] if bytes_col and bytes_col in df else 0.0,
                            "peer": df[peer_col].astype(str).str.split(";").str[0] if peer_col and peer_col in df else ""})
        frames.append(out)
    read("logon.csv", "logon", "pc")
    read("device.csv", "device", "pc")
    read("http.csv", "http", "url")
    read("email.csv", "email", "to", bytes_col="size", peer_col="to")
    read("file.csv", "file_copy", "filename")
    ev = pd.concat(frames, ignore_index=True)
    # LDAP context
    ldap = sorted(glob.glob(os.path.join(d, "LDAP", "*.csv")))
    if ldap:
        L = pd.read_csv(ldap[-1])
        ctx = L.set_index("user_id")
        ev["role"] = ev["user"].map(ctx["role"]).fillna("staff")
        ev["dept"] = ev["user"].map(ctx["department"]).fillna("none")
        ev["location"] = ev["user"].map(ctx["business_unit"]).fillna("bu0").astype(str)
        ev["privilege"] = ev["role"].str.contains("Admin|ITAdmin|Director", case=False).astype(int)
    # ground truth
    ans = os.path.join(d, "answers", "insiders.csv")
    ev["label"] = 0; ev["threat_type"] = -1; ev["scenario"] = ""
    if os.path.exists(ans):
        A = pd.read_csv(ans)
        for _, r in A.iterrows():
            t0 = pd.to_datetime(r["start"]).value / 3.6e12; t1 = pd.to_datetime(r["end"]).value / 3.6e12
            m = (ev["user"] == r["user"]) & (ev["timestamp"] >= t0) & (ev["timestamp"] <= t1)
            ev.loc[m, "label"] = 1
            ev.loc[m, "threat_type"] = SCENARIO_TO_TYPE.get(int(r["scenario"]), 0)
            ev.loc[m, "scenario"] = f"cert_{r['user']}_{r['scenario']}"
    return normalize_events(ev)
