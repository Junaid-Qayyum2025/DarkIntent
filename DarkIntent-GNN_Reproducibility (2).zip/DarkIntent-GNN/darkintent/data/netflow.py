"""UNSW-NB15 and CIC-IDS2017 adapters. Flows are events, src IP is the actor,
dst IP the resource, service/protocol the application. Attack class labels are
used as the intent proxy described in Section III-A of the paper."""
import os, glob
import numpy as np
import pandas as pd
from .schema import normalize_events

UNSW_TYPE = {"Exploits": 1, "Fuzzers": 1, "Generic": 1, "Reconnaissance": 4, "DoS": 1, "Analysis": 4,
             "Backdoor": 3, "Shellcode": 1, "Worms": 4}
CIC_TYPE = {"DoS": 1, "DDoS": 1, "PortScan": 4, "Bot": 3, "Infiltration": 2, "Web Attack": 1,
            "Brute Force": 3, "Heartbleed": 2, "SSH-Patator": 3, "FTP-Patator": 3}


def load_unsw(root, max_rows=None):
    d = os.path.join(root, "unsw_nb15")
    files = sorted(glob.glob(os.path.join(d, "UNSW-NB15_*.csv")))
    cols = pd.read_csv(os.path.join(d, "NUSW-NB15_features.csv"), encoding="latin1")["Name"].tolist()
    df = pd.concat([pd.read_csv(f, header=None, names=cols, nrows=max_rows) for f in files], ignore_index=True)
    ev = pd.DataFrame({"user": df["srcip"].astype(str), "resource": df["dstip"].astype(str),
                       "device": df["srcip"].astype(str), "application": df["service"].astype(str),
                       "action": df["proto"].astype(str), "timestamp": df["Stime"] / 3600.0,
                       "bytes": df["sbytes"] + df["dbytes"], "location": df["srcip"].astype(str).str.rsplit(".", n=1).str[0],
                       "label": df["Label"].astype(int)})
    ev["threat_type"] = df["attack_cat"].astype(str).str.strip().map(UNSW_TYPE).fillna(-1).astype(int)
    ev.loc[ev["label"] == 0, "threat_type"] = -1
    ev["scenario"] = np.where(ev["label"] == 1, "unsw_" + ev["user"], "")
    return normalize_events(ev)


def load_cicids(root, max_rows=None):
    d = os.path.join(root, "cic_ids2017")
    files = sorted(glob.glob(os.path.join(d, "*.csv")))
    parts = []
    for f in files:
        df = pd.read_csv(f, nrows=max_rows); df.columns = [c.strip() for c in df.columns]
        parts.append(df)
    df = pd.concat(parts, ignore_index=True)
    ts = pd.to_datetime(df["Timestamp"], errors="coerce")
    lab = df["Label"].astype(str)
    ev = pd.DataFrame({"user": df["Source IP"].astype(str), "resource": df["Destination IP"].astype(str),
                       "device": df["Source IP"].astype(str), "application": df["Destination Port"].astype(str),
                       "action": df["Protocol"].astype(str), "timestamp": ts.astype("int64") / 3.6e12,
                       "bytes": df["Total Length of Fwd Packets"] + df["Total Length of Bwd Packets"],
                       "location": df["Source IP"].astype(str).str.rsplit(".", n=1).str[0],
                       "label": (lab != "BENIGN").astype(int)})
    ttype = pd.Series(-1, index=df.index)
    for k, v in CIC_TYPE.items():
        ttype[lab.str.contains(k, case=False)] = v
    ev["threat_type"] = ttype.values
    ev["scenario"] = np.where(ev["label"] == 1, "cic_" + ev["user"], "")
    return normalize_events(ev)
