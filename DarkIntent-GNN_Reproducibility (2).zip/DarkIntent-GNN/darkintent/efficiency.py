"""Table 6 / Fig. 9: training time, inference latency, memory, parameters, scalability."""
import argparse, time
import torch
from .utils.common import load_config, get_logger, save_json
from .experiment import prepare_graphs, temporal_split, train_model, make_model, device
from .data import synthetic


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--config", default="configs/default.yaml"); ap.add_argument("--dataset", default=None)
    ap.add_argument("--epochs", type=int, default=3); ap.add_argument("--max_windows", type=int, default=None)
    ap.add_argument("--models", default="lstm,gcn,gat,graphch,itdsts,darkintent"); ap.add_argument("--sizes", default="1000,2500,5000,10000")
    ap.add_argument("--out", default="results/tables/efficiency.json"); a = ap.parse_args()
    cfg = load_config(a.config, {"dataset": a.dataset} if a.dataset else None); cfg["train"]["epochs"] = a.epochs
    log = get_logger("efficiency"); dev = device(); ev, graphs = prepare_graphs(cfg, max_windows=a.max_windows); tr, va, te = temporal_split(graphs)
    table = {}
    for name in a.models.split(","):
        if dev.type == "cuda": torch.cuda.reset_peak_memory_stats()
        m, info = train_model(cfg, tr, va, name, 42, log, epochs=a.epochs); m.eval()
        g = te[-1].to(dev)
        with torch.no_grad():
            for _ in range(3): m(g)
            t0 = time.time(); [m(g) for _ in range(10)]; lat = (time.time() - t0) / 10 * 1000
        mem = torch.cuda.max_memory_allocated() / 1e9 if dev.type == "cuda" else float("nan")
        table[name] = {"train_min_per_epoch": info["train_minutes"] / info["epochs_run"], "inference_ms": lat, "memory_gb": mem, "params_M": info["params_M"]}
        log.info(f"{name}: {table[name]}")
    # scalability with synthetic network size (users)
    table["scalability"] = {}
    for n in [int(s) for s in a.sizes.split(",")]:
        ev_n = synthetic.generate(num_users=n, days=4, seed=1); _, gs = prepare_graphs(cfg, events=ev_n, max_windows=2)
        m = make_model(cfg).to(dev); opt = torch.optim.Adam(m.parameters(), 1e-3)
        t0 = time.time()
        for g in gs:
            g.to(dev); opt.zero_grad(); out = m(g); out["p_intent"].mean().backward(); opt.step()
        table["scalability"][str(n)] = (time.time() - t0) / 60.0
        log.info(f"nodes={n}: {table['scalability'][str(n)]:.3f} min/epoch")
    save_json(table, a.out)


if __name__ == "__main__":
    main()
