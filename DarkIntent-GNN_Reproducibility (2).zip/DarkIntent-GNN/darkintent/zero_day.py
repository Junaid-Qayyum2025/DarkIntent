"""Table 8 / Fig. 11: temporal hold-out zero-day evaluation.
Training uses the first part of the timeline with a subset of threat types; the
held-out threat types appearing only in the test period are treated as zero-day."""
import argparse
import numpy as np
from .utils.common import load_config, get_logger, save_json
from .experiment import prepare_graphs, temporal_split, train_model, evaluate, device
from .data.loader import load_events


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--config", default="configs/default.yaml"); ap.add_argument("--dataset", default=None)
    ap.add_argument("--epochs", type=int, default=None); ap.add_argument("--max_windows", type=int, default=None); ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--holdout_types", default="1,4"); ap.add_argument("--models", default="lstm,gcn,graphch,itdsts,darkintent")
    ap.add_argument("--out", default="results/tables/zero_day.json"); a = ap.parse_args()
    cfg = load_config(a.config, {"dataset": a.dataset} if a.dataset else None)
    if a.epochs: cfg["train"]["epochs"] = a.epochs
    log = get_logger("zero_day"); ev = load_events(cfg["dataset"], cfg["data_root"], **cfg.get("data_kwargs", {}))
    hold = [int(x) for x in a.holdout_types.split(",")]
    _, graphs = prepare_graphs(cfg, events=ev, max_windows=a.max_windows); tr, va, te = temporal_split(graphs)
    # remove held-out threat types from training/validation graphs (mask their labels to benign users would leak; drop the users instead)
    def strip(gs):
        out = []
        for g in gs:
            keep = ~np.isin(g.y_category.numpy(), hold)
            if keep.all(): out.append(g); continue
            g.user_index = g.user_index[keep]; g.y_intent = g.y_intent[keep]; g.y_category = g.y_category[keep]
            g.anomaly_target = g.anomaly_target[keep]; g.attack_time = g.attack_time[keep]; out.append(g)
        return out
    tr, va = strip(tr), strip(va)
    table = {}
    for name in a.models.split(","):
        m, _ = train_model(cfg, tr, va, name, a.seed, log)
        res = evaluate(m, te, device()); y = np.array(res["y_true"]); p = np.array(res["y_prob"])
        cat = np.concatenate([g.y_category.cpu().numpy() for g in te])
        known = ~np.isin(cat, hold) | (cat < 0); zd = np.isin(cat, hold) | (cat < 0)
        from .utils.metrics import binary_metrics
        k = binary_metrics(y[known], p[known]); z = binary_metrics(y[zd], p[zd])
        table[name] = {"known_f1": k["f1"], "zero_day_f1": z["f1"], "degradation_pct": 100 * (k["f1"] - z["f1"]) / max(k["f1"], 1e-9), "auc": res["auc"],
                       "monthly": [evaluate(m, [g], device())["accuracy"] for g in te]}
        log.info(f"{name}: known_f1={k['f1']:.4f} zero_day_f1={z['f1']:.4f} deg={table[name]['degradation_pct']:.1f}% auc={res['auc']:.4f}")
    save_json(table, a.out)


if __name__ == "__main__":
    main()
