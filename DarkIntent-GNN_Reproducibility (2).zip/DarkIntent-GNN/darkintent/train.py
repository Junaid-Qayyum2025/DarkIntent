"""Main training entry point: python -m darkintent.train --config configs/default.yaml --dataset synthetic"""
import argparse, os
from .utils.common import load_config, get_logger, save_json
from .experiment import prepare_graphs, temporal_split, train_model, evaluate, summarize, device


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--dataset", default=None); ap.add_argument("--epochs", type=int, default=None)
    ap.add_argument("--model", default="darkintent"); ap.add_argument("--seeds", default=None)
    ap.add_argument("--max_windows", type=int, default=None); ap.add_argument("--out", default="results/tables/overall.json")
    a = ap.parse_args()
    cfg = load_config(a.config, {"dataset": a.dataset} if a.dataset else None)
    if a.epochs: cfg["train"]["epochs"] = a.epochs
    seeds = [int(s) for s in a.seeds.split(",")] if a.seeds else cfg["eval"]["seeds"]
    log = get_logger("train")
    ev, graphs = prepare_graphs(cfg, max_windows=a.max_windows)
    tr, va, te = temporal_split(graphs)
    log.info(f"dataset={cfg['dataset']} windows train/val/test={len(tr)}/{len(va)}/{len(te)} users/window={len(graphs[0].user_index)}")
    runs, cost = [], []
    for s in seeds:
        model, info = train_model(cfg, tr, va, a.model, s, log)
        res = evaluate(model, te, device()); res.pop("y_true"); res.pop("y_prob")
        runs.append(res); cost.append(info)
        log.info(f"[{a.model}] seed={s} test acc={res['accuracy']:.4f} prec={res['precision']:.4f} rec={res['recall']:.4f} f1={res['f1']:.4f} auc={res['auc']:.4f} fpr={res['fpr']:.4f}")
    summary = {"model": a.model, "dataset": cfg["dataset"], "seeds": seeds, "metrics": summarize(runs), "runs": runs, "cost": cost}
    save_json(summary, a.out); log.info(f"saved {a.out}")


if __name__ == "__main__":
    main()
