"""Table 4 / Fig. 7: additive deletion ablation."""
import argparse, copy
from .utils.common import load_config, get_logger, save_json
from .experiment import prepare_graphs, temporal_split, train_model, evaluate, summarize, device

CONFIGS = {"full": {}, "wo_hetero_graph": {"use_hetero_graph": False}, "wo_hier_attention": {"use_hier_attention": False},
           "wo_temporal_gcn": {"use_temporal_gcn": False}, "wo_threat_prop": {"use_threat_prop": False},
           "wo_multitask": {"use_multitask": False}}


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--config", default="configs/default.yaml"); ap.add_argument("--dataset", default=None)
    ap.add_argument("--epochs", type=int, default=None); ap.add_argument("--max_windows", type=int, default=None); ap.add_argument("--seeds", default=None)
    ap.add_argument("--out", default="results/tables/ablation.json"); a = ap.parse_args()
    cfg = load_config(a.config, {"dataset": a.dataset} if a.dataset else None)
    if a.epochs: cfg["train"]["epochs"] = a.epochs
    seeds = [int(s) for s in a.seeds.split(",")] if a.seeds else cfg["eval"]["seeds"]; log = get_logger("ablation")
    ev, _ = prepare_graphs(cfg, max_windows=a.max_windows)
    table = {}
    for name, over in CONFIGS.items():
        c = copy.deepcopy(cfg); c["model"].update(over)
        _, graphs = prepare_graphs(c, events=ev, max_windows=a.max_windows, hetero=c["model"]["use_hetero_graph"]); tr, va, te = temporal_split(graphs)
        runs = []
        for s in seeds:
            m, _ = train_model(c, tr, va, "darkintent", s, log); r = evaluate(m, te, device()); r.pop("y_true"); r.pop("y_prob"); runs.append(r)
        table[name] = summarize(runs); log.info(f"{name:18s} " + " ".join(f"{k}={v['mean']:.4f}" for k, v in table[name].items()))
    save_json(table, a.out)


if __name__ == "__main__":
    main()
