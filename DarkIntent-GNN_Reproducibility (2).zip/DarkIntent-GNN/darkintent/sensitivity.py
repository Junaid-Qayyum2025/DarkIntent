"""Table 5 / Fig. 8: hyperparameter sensitivity."""
import argparse, copy
from .utils.common import load_config, get_logger, save_json
from .experiment import prepare_graphs, temporal_split, train_model, evaluate, device

GRID = {"model.num_heads": [1, 2, 4, 8, 12, 16], "model.hidden_dim": [64, 128, 256, 384, 512],
        "temporal_window_hours": [24, 48, 72, 96, 120, 144, 168], "model.num_layers": [1, 2, 3, 4, 5],
        "train.lr": [1e-4, 3e-4, 1e-3, 3e-3, 1e-2], "model.lambda_init": [0.1, 0.3, 0.5, 0.7, 0.9]}


def setp(cfg, key, val):
    d = cfg; ks = key.split(".")
    for k in ks[:-1]: d = d[k]
    d[ks[-1]] = val


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--config", default="configs/default.yaml"); ap.add_argument("--dataset", default=None)
    ap.add_argument("--epochs", type=int, default=None); ap.add_argument("--max_windows", type=int, default=None); ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--params", default=",".join(GRID.keys())); ap.add_argument("--out", default="results/tables/sensitivity.json"); a = ap.parse_args()
    cfg = load_config(a.config, {"dataset": a.dataset} if a.dataset else None)
    if a.epochs: cfg["train"]["epochs"] = a.epochs
    log = get_logger("sensitivity"); ev, _ = prepare_graphs(cfg, max_windows=a.max_windows); table = {}
    for key in a.params.split(","):
        table[key] = {}
        for v in GRID[key]:
            c = copy.deepcopy(cfg); setp(c, key, v)
            if key == "model.hidden_dim": c["model"]["head_dim"] = max(16, v // 4)
            if key == "model.num_heads": c["model"]["hidden_dim"] = (cfg["model"]["hidden_dim"] // v) * v
            _, graphs = prepare_graphs(c, events=ev, max_windows=a.max_windows); tr, va, te = temporal_split(graphs)
            m, _ = train_model(c, tr, va, "darkintent", a.seed, log); r = evaluate(m, te, device())
            table[key][str(v)] = {"accuracy": r["accuracy"], "f1": r["f1"]}
            log.info(f"{key}={v}: acc={r['accuracy']:.4f} f1={r['f1']:.4f}")
        vals = [x["f1"] for x in table[key].values()]; table[key]["impact_pct"] = 100 * (max(vals) - min(vals)) / 2
    save_json(table, a.out)


if __name__ == "__main__":
    main()
