"""DarkIntent-GNN: heterogeneous temporal GNN for malicious intent detection."""
__version__ = "1.0.0"
