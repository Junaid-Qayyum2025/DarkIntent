import numpy as np
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             roc_auc_score, confusion_matrix, precision_recall_curve)


def binary_metrics(y_true, y_prob, threshold=0.5):
    y_true = np.asarray(y_true).astype(int); y_prob = np.asarray(y_prob)
    y_pred = (y_prob >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    out = {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
        "fpr": fp / max(fp + tn, 1),
    }
    try:
        out["auc"] = roc_auc_score(y_true, y_prob)
    except ValueError:
        out["auc"] = float("nan")
    return out


def per_class_metrics(y_true, y_pred, num_classes):
    rows = []
    for c in range(num_classes):
        t = (np.asarray(y_true) == c).astype(int); p = (np.asarray(y_pred) == c).astype(int)
        rows.append({"class": c, "precision": precision_score(t, p, zero_division=0),
                     "recall": recall_score(t, p, zero_division=0), "f1": f1_score(t, p, zero_division=0),
                     "support": int(t.sum())})
    return rows


def pr_curve(y_true, y_prob):
    p, r, _ = precision_recall_curve(y_true, y_prob)
    return p, r


def lead_time_stats(alert_times, attack_times, thresholds=(24, 12, 6, 3, 1)):
    """Cumulative detection rate at each lead-time threshold (hours before attack)."""
    lead = np.asarray(attack_times, dtype=float) - np.asarray(alert_times, dtype=float)
    lead = lead[~np.isnan(lead)]
    out = {}
    for th in thresholds:
        out[f">{th}h"] = float((lead > th).mean()) if len(lead) else float("nan")
    out["mean_lead_hours"] = float(lead.mean()) if len(lead) else float("nan")
    return out
