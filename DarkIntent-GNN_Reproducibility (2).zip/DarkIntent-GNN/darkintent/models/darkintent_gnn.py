"""DarkIntent-GNN full model (Fig. 3)."""
import torch
import torch.nn as nn
import torch.nn.functional as F
from .layers import NodeLevelAttention, HierarchicalGATLayer, TemporalGCNGRU, ThreatPropagation


class _GradScale(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, s):
        ctx.s = s; return x.view_as(x)

    @staticmethod
    def backward(ctx, g):
        return g * ctx.s, None


def grad_scale(x, s):
    """Identity in the forward pass; scales the gradient flowing back into the shared trunk.
    Used on the auxiliary heads so that sparse-label task gradients (threat category) cannot dominate the
    intent objective, while the heads still share the trunk representation."""
    return _GradScale.apply(x, s)


class DarkIntentGNN(nn.Module):
    def __init__(self, in_dim, edge_dim, cfg):
        super().__init__()
        H = cfg["hidden_dim"]; self.cfg = cfg
        self.use_temporal = cfg.get("use_temporal_gcn", True)
        self.use_prop = cfg.get("use_threat_prop", True)
        self.use_mt = cfg.get("use_multitask", True)
        R = cfg["num_relations"] if cfg.get("use_hetero_graph", True) else 1
        self.type_emb = nn.Embedding(5, H)
        self.use_node_att = cfg.get("use_node_attention", True)
        self.node_att = NodeLevelAttention(in_dim, H, cfg["head_dim"], dropout=cfg["dropout"]) if self.use_node_att else nn.Linear(in_dim, H)
        self.layers = nn.ModuleList([HierarchicalGATLayer(H, cfg["num_heads"], edge_dim, R, cfg["dropout"],
                                                          use_hier=cfg.get("use_hier_attention", True))
                                     for _ in range(cfg["num_layers"])])
        self.jk = nn.Parameter(torch.zeros(cfg["num_layers"] + 1))   # jumping-knowledge weights over hop depths
        self.temporal = TemporalGCNGRU(H, cfg["dropout"]) if self.use_temporal else None
        self.prop = ThreatPropagation(cfg.get("lambda_init", 0.5), cfg.get("propagation_steps", 3)) if self.use_prop else None
        self.alpha_neural = cfg.get("alpha_neural", 0.7)
        self.intent_head = nn.Sequential(nn.Linear(H, H // 2), nn.ELU(), nn.Dropout(cfg["dropout"]), nn.Linear(H // 2, 1))
        self.anomaly_head = nn.Sequential(nn.Linear(H, H // 2), nn.ELU(), nn.Linear(H // 2, 1))
        self.category_head = nn.Sequential(nn.Linear(H, H // 2), nn.ELU(), nn.Linear(H // 2, cfg["num_threat_types"]))

    def encode_snapshot(self, snap, node_type):
        if self.use_node_att:
            h, feat_att = self.node_att(snap.x)
        else:
            h, feat_att = self.node_att(snap.x), None
        h = h + self.type_emb(node_type)
        atts, hs = [], [h]
        for layer in self.layers:
            h, a = layer(h, snap.edge_index, snap.edge_attr, snap.edge_type)
            atts.append(a); hs.append(h)
        w = torch.softmax(self.jk, 0)
        h = sum(wi * hi for wi, hi in zip(w, hs))       # softmax-weighted combination of 0..L hop representations
        return h, feat_att, atts

    def forward(self, graph):
        H_list, ei_list, att_last = [], [], None
        for snap in graph.snapshots:
            h, feat_att, atts = self.encode_snapshot(snap, graph.node_type)
            H_list.append(h); ei_list.append(snap.edge_index); att_last = (feat_att, atts)
        z = self.temporal(H_list, ei_list) if self.use_temporal else H_list[-1]
        zu = z[graph.user_index]
        logit = self.intent_head(zu).squeeze(-1)
        p_gnn = torch.sigmoid(logit)
        if self.use_prop:
            last = graph.snapshots[-1]
            p_all = torch.zeros(graph.num_nodes, device=zu.device).index_copy(0, graph.user_index, p_gnn)
            p_prop = self.prop(p_all, last.edge_index, last.edge_attr[:, 0] * last.edge_attr[:, 1] + 1e-3, graph.num_nodes)
            p_final = self.alpha_neural * p_gnn + (1 - self.alpha_neural) * p_prop[graph.user_index]   # Eq. 24
        else:
            p_final = p_gnn
        out = {"p_intent": p_final, "logit": logit, "embedding": zu, "attention": att_last}
        if self.use_mt:
            gs = self.cfg.get("aux_grad_scale", 0.1)
            out["anomaly"] = torch.sigmoid(self.anomaly_head(grad_scale(zu, gs))).squeeze(-1)
            out["category_logits"] = self.category_head(grad_scale(zu, gs))
        return out
