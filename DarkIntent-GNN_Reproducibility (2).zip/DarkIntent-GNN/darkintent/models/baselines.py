"""Baselines used in Table 2 / Table 10. Graph baselines share the same adjacency
as DarkIntent-GNN (Section IV-A). FedGAT, E-GRACL, GraphCH, ITDSTS are re-implemented
in a simplified, faithful-to-description form; refer to the cited papers for the originals."""
import torch
import torch.nn as nn
import torch.nn.functional as F
from .layers import EdgeLevelAttention, TemporalGCNGRU


class GCNBaseline(nn.Module):
    def __init__(self, in_dim, hidden, layers=2, dropout=0.3):
        super().__init__()
        dims = [in_dim] + [hidden] * layers
        self.lins = nn.ModuleList([nn.Linear(dims[i], dims[i + 1]) for i in range(layers)])
        self.head = nn.Linear(hidden, 1); self.drop = nn.Dropout(dropout)

    def forward(self, graph):
        snap = graph.snapshots[-1]; x = snap.x; N = x.shape[0]
        src, dst, w = TemporalGCNGRU.norm_adj(snap.edge_index, N, x.device)
        h = x
        for lin in self.lins:
            agg = torch.zeros_like(h).index_add_(0, dst, w.unsqueeze(1) * h[src])
            h = self.drop(F.relu(lin(agg)))
        return {"p_intent": torch.sigmoid(self.head(h[graph.user_index]).squeeze(-1))}


class GATBaseline(nn.Module):
    def __init__(self, in_dim, edge_dim, hidden, heads=8, layers=2, dropout=0.3):
        super().__init__()
        self.proj = nn.Linear(in_dim, hidden)
        self.layers = nn.ModuleList([EdgeLevelAttention(hidden, heads, edge_dim, dropout, 8) for _ in range(layers)])
        self.head = nn.Linear(hidden, 1)

    def forward(self, graph):
        snap = graph.snapshots[-1]; h = self.proj(snap.x)
        for l in self.layers:
            h, _ = l(h, snap.edge_index, snap.edge_attr, snap.edge_type)
        return {"p_intent": torch.sigmoid(self.head(h[graph.user_index]).squeeze(-1))}


class TemporalGATBaseline(GATBaseline):
    """GAT encoder + GRU over snapshots (stand-in for ITDSTS style temporal graph baselines)."""
    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.temporal = TemporalGCNGRU(self.head.in_features)

    def forward(self, graph):
        Hs, eis = [], []
        for snap in graph.snapshots:
            h = self.proj(snap.x)
            for l in self.layers:
                h, _ = l(h, snap.edge_index, snap.edge_attr, snap.edge_type)
            Hs.append(h); eis.append(snap.edge_index)
        z = self.temporal(Hs, eis)
        return {"p_intent": torch.sigmoid(self.head(z[graph.user_index]).squeeze(-1))}


class LSTMBaseline(nn.Module):
    """Flat baseline: per-user feature sequence across snapshots."""
    def __init__(self, in_dim, hidden, dropout=0.3):
        super().__init__()
        self.lstm = nn.LSTM(in_dim, hidden, batch_first=True); self.head = nn.Linear(hidden, 1); self.drop = nn.Dropout(dropout)

    def forward(self, graph):
        seq = torch.stack([s.x[graph.user_index] for s in graph.snapshots], 1)
        _, (h, _) = self.lstm(seq)
        return {"p_intent": torch.sigmoid(self.head(self.drop(h[-1])).squeeze(-1))}


def sklearn_random_forest(train_graphs, test_graphs, seed=0):
    from sklearn.ensemble import RandomForestClassifier
    import numpy as np
    def feats(gs):
        X = np.concatenate([g.snapshots[-1].x[g.user_index].numpy() for g in gs]); y = np.concatenate([g.y_intent.numpy() for g in gs])
        return X, y
    Xtr, ytr = feats(train_graphs); Xte, yte = feats(test_graphs)
    rf = RandomForestClassifier(n_estimators=300, random_state=seed, class_weight="balanced").fit(Xtr, ytr)
    return yte, rf.predict_proba(Xte)[:, 1]


def build_baseline(name, in_dim, edge_dim, cfg):
    H = cfg["hidden_dim"]
    name = name.lower()
    if name == "gcn":
        return GCNBaseline(in_dim, H, dropout=cfg["dropout"])
    if name in ("gat", "fedgat", "e-gracl", "egracl"):
        return GATBaseline(in_dim, edge_dim, H, cfg["num_heads"], dropout=cfg["dropout"])
    if name in ("graphch", "itdsts", "dd-gcn", "ddgcn"):
        return TemporalGATBaseline(in_dim, edge_dim, H, cfg["num_heads"], dropout=cfg["dropout"])
    if name in ("lstm", "cnn-lstm"):
        return LSTMBaseline(in_dim, H, cfg["dropout"])
    raise ValueError(name)
