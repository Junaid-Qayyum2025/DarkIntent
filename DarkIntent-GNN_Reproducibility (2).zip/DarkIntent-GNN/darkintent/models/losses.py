"""Multi-task objective (Eqs. 25 to 29)."""
import torch
import torch.nn as nn
import torch.nn.functional as F


def focal_loss(p, y, alpha=0.25, gamma=2.0):                          # Eq. 25
    p = p.clamp(1e-6, 1 - 1e-6)
    ce = -(y * torch.log(p) + (1 - y) * torch.log(1 - p))
    pt = torch.where(y == 1, p, 1 - p)
    a = torch.where(y == 1, torch.full_like(p, alpha), torch.full_like(p, 1 - alpha))
    return (a * (1 - pt) ** gamma * ce).mean()


def anomaly_loss(s_hat, s, edge_index_users, lambda_smooth=0.01):     # Eq. 26
    mse = F.mse_loss(s_hat, s)
    if edge_index_users is not None and edge_index_users.shape[1] > 0:
        src, dst = edge_index_users
        smooth = ((s_hat[src] - s_hat[dst]) ** 2).mean()
    else:
        smooth = torch.tensor(0.0, device=s_hat.device)
    return mse + lambda_smooth * smooth


def category_loss(logits, y_cat):                                      # Eq. 27
    m = y_cat >= 0
    if m.sum() == 0:
        return torch.tensor(0.0, device=logits.device)
    # Eq. 27 averages over all N users; benign users contribute zero, so the sum over labelled users is divided by N
    return F.cross_entropy(logits[m], y_cat[m], reduction="sum") / logits.shape[0]


class MultiTaskLoss(nn.Module):
    """Eq. 28 with task weights lambda_i adapted by a validation gradient step (Eq. 29)."""
    def __init__(self, init=(1.0, 0.5, 0.5, 1e-4), meta_lr=0.01, focal_alpha=0.25, focal_gamma=2.0, lambda_smooth=0.01):
        super().__init__()
        self.register_buffer("w", torch.tensor(init, dtype=torch.float32))
        self.meta_lr = meta_lr; self.fa = focal_alpha; self.fg = focal_gamma; self.ls = lambda_smooth

    def components(self, out, graph, model, user_edges=None):
        L = {"focal": focal_loss(out["p_intent"], graph.y_intent, self.fa, self.fg)}
        if "anomaly" in out:
            L["anomaly"] = anomaly_loss(out["anomaly"], graph.anomaly_target, user_edges, self.ls)
            L["category"] = category_loss(out["category_logits"], graph.y_category)
        else:
            L["anomaly"] = torch.tensor(0.0, device=out["p_intent"].device); L["category"] = L["anomaly"]
        L["reg"] = sum(p.pow(2).sum() for p in model.parameters()) / 1e6
        return L

    def forward(self, out, graph, model, user_edges=None):
        L = self.components(out, graph, model, user_edges)
        total = self.w[0] * L["focal"] + self.w[1] * L["anomaly"] + self.w[2] * L["category"] + self.w[3] * L["reg"]
        return total, {k: float(v.detach()) for k, v in L.items()}

    @torch.no_grad()
    def meta_update(self, val_components):
        """Eq. 29: move each task weight against the gradient of the validation loss w.r.t. that weight,
        which for a linear combination equals the task's validation loss itself. Weights are renormalised
        so the intent term keeps unit scale."""
        g = torch.tensor([val_components["focal"], val_components["anomaly"], val_components["category"], val_components["reg"]])
        self.w[:3] = (self.w[:3] - self.meta_lr * g[:3]).clamp(min=0.05)
        self.w[:3] = self.w[:3] / self.w[0]
