"""Building blocks of DarkIntent-GNN (Section III-C and III-D)."""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F


def scatter_softmax(src, index, num_nodes):
    """Softmax of edge scores grouped by destination node."""
    src_max = torch.full((num_nodes,), -1e9, device=src.device).scatter_reduce(0, index, src, reduce="amax", include_self=True)
    out = torch.exp(src - src_max[index])
    denom = torch.zeros(num_nodes, device=src.device).index_add_(0, index, out)
    return out / (denom[index] + 1e-16)


class NodeLevelAttention(nn.Module):
    """Eq. 11 and Eq. 12: self-attention over feature groups of each node."""
    def __init__(self, in_dim, hidden_dim, head_dim, groups=4, dropout=0.3):
        super().__init__()
        self.groups = groups
        self.proj = nn.Linear(in_dim, hidden_dim)
        self.gdim = hidden_dim // groups
        self.WQ = nn.Linear(self.gdim, head_dim); self.WK = nn.Linear(self.gdim, head_dim); self.WV = nn.Linear(self.gdim, self.gdim)
        self.dk = head_dim; self.drop = nn.Dropout(dropout); self.norm = nn.LayerNorm(hidden_dim)

    def forward(self, x):
        h = self.proj(x)                                   # [N, H]
        g = h.view(h.shape[0], self.groups, self.gdim)     # feature groups as tokens
        Q, K, V = self.WQ(g), self.WK(g), self.WV(g)
        att = F.softmax(Q @ K.transpose(1, 2) / math.sqrt(self.dk), dim=-1)   # Eq. 11
        out = (att @ V).reshape(h.shape[0], -1)
        return self.norm(self.drop(out) + h), att.mean(1)                     # Eq. 12 (residual)


class EdgeLevelAttention(nn.Module):
    """Eq. 13 and Eq. 14: multi-head edge attention with edge features."""
    def __init__(self, hidden_dim, num_heads, edge_dim, dropout=0.3, num_relations=8):
        super().__init__()
        self.K = num_heads; self.d = hidden_dim // num_heads
        self.Wh = nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.We = nn.Linear(edge_dim, self.K * self.d)
        self.rel_emb = nn.Embedding(num_relations, self.K * self.d)
        self.a = nn.Parameter(torch.empty(self.K, 3 * self.d)); nn.init.xavier_uniform_(self.a)
        self.drop = nn.Dropout(dropout); self.norm = nn.LayerNorm(hidden_dim)

    def forward(self, x, edge_index, edge_attr, edge_type):
        N = x.shape[0]; src, dst = edge_index
        h = self.Wh(x).view(N, self.K, self.d)
        e = (self.We(edge_attr) + self.rel_emb(edge_type)).view(-1, self.K, self.d)
        cat = torch.cat([h[src], h[dst], e], dim=-1)                       # [E, K, 3d]
        score = F.leaky_relu((cat * self.a.unsqueeze(0)).sum(-1), 0.2)      # [E, K]
        alpha = torch.stack([scatter_softmax(score[:, k], dst, N) for k in range(self.K)], 1)   # Eq. 13
        alpha = self.drop(alpha)
        msg = alpha.unsqueeze(-1) * h[src]                                  # [E, K, d]
        out = torch.zeros(N, self.K, self.d, device=x.device).index_add_(0, dst, msg)
        out = F.elu(out.mean(1))                                            # Eq. 14 (head average)
        return self.norm(out.repeat(1, self.K) if out.shape[1] != x.shape[1] else out + x), alpha.mean(1)


class SubgraphLevelAttention(nn.Module):
    """Eq. 15 and Eq. 16: attention over relation-specific subgraph embeddings."""
    def __init__(self, hidden_dim, num_relations):
        super().__init__()
        self.R = num_relations
        self.Wr = nn.ModuleList([nn.Linear(hidden_dim, hidden_dim) for _ in range(num_relations)])
        self.q = nn.Parameter(torch.randn(hidden_dim) / math.sqrt(hidden_dim))

    def forward(self, h_rel):                     # h_rel: [R, N, H]
        s = torch.stack([torch.tanh(self.Wr[r](h_rel[r])) @ self.q for r in range(self.R)], 0)   # [R, N]
        beta = F.softmax(s, dim=0)                                                               # Eq. 15
        z = (beta.unsqueeze(-1) * h_rel).sum(0)                                                  # Eq. 16
        return z, beta


class HierarchicalGATLayer(nn.Module):
    """One hierarchical layer = edge attention per relation followed by subgraph attention."""
    def __init__(self, hidden_dim, num_heads, edge_dim, num_relations, dropout=0.3, use_hier=True):
        super().__init__()
        self.R = num_relations; self.use_hier = use_hier
        self.edge_att = EdgeLevelAttention(hidden_dim, num_heads, edge_dim, dropout, num_relations)
        self.sub_att = SubgraphLevelAttention(hidden_dim, num_relations) if use_hier else None
        self.ff = nn.Sequential(nn.Linear(hidden_dim, hidden_dim), nn.ELU(), nn.Dropout(dropout), nn.Linear(hidden_dim, hidden_dim))
        self.norm = nn.LayerNorm(hidden_dim)

    def forward(self, x, edge_index, edge_attr, edge_type):
        if not self.use_hier:
            h, alpha = self.edge_att(x, edge_index, edge_attr, edge_type)
            return self.norm(h + self.ff(h)), {"edge": alpha, "subgraph": None}
        h_rel = []
        for r in range(self.R):
            m = edge_type == r
            if m.sum() == 0:
                h_rel.append(x); continue
            h_r, _ = self.edge_att(x, edge_index[:, m], edge_attr[m], edge_type[m])
            h_rel.append(h_r)
        z, beta = self.sub_att(torch.stack(h_rel, 0))
        _, alpha = self.edge_att(x, edge_index, edge_attr, edge_type)
        return self.norm(z + self.ff(z)), {"edge": alpha, "subgraph": beta}


class TemporalGCNGRU(nn.Module):
    """Eq. 17 (spectral GCN on each snapshot) followed by GRU recurrence Eqs. 18 to 21."""
    def __init__(self, hidden_dim, dropout=0.3):
        super().__init__()
        self.W = nn.Linear(hidden_dim, hidden_dim)
        self.gru = nn.GRUCell(hidden_dim, hidden_dim)
        self.drop = nn.Dropout(dropout)

    @staticmethod
    def norm_adj(edge_index, N, device):
        src, dst = edge_index
        loop = torch.arange(N, device=device)
        src = torch.cat([src, loop]); dst = torch.cat([dst, loop])
        deg = torch.zeros(N, device=device).index_add_(0, dst, torch.ones_like(dst, dtype=torch.float))
        dinv = deg.pow(-0.5)
        return src, dst, dinv[src] * dinv[dst]

    def forward(self, H_list, edge_index_list, h0=None):
        N = H_list[0].shape[0]; dev = H_list[0].device
        h = torch.zeros(N, H_list[0].shape[1], device=dev) if h0 is None else h0
        for H, ei in zip(H_list, edge_index_list):
            src, dst, w = self.norm_adj(ei, N, dev)
            agg = torch.zeros_like(H).index_add_(0, dst, w.unsqueeze(1) * H[src])
            Ht = torch.sigmoid(self.W(agg))                     # Eq. 17
            h = self.gru(self.drop(Ht), h)                       # Eqs. 18 to 21
        return h


class ThreatPropagation(nn.Module):
    """Eq. 22 and Eq. 23: discrete diffusion of intent probabilities over the graph.
    lambda is learnable (initialised to 0.5) and constrained to (0, 1)."""
    def __init__(self, lambda_init=0.5, steps=3):
        super().__init__()
        self.raw = nn.Parameter(torch.logit(torch.tensor(float(lambda_init))))
        self.steps = steps

    @property
    def lam(self):
        return torch.sigmoid(self.raw)

    def forward(self, p, edge_index, edge_weight, N):
        src, dst = edge_index
        deg = torch.zeros(N, device=p.device).index_add_(0, dst, edge_weight) + 1e-9
        for _ in range(self.steps):
            Ap = torch.zeros(N, device=p.device).index_add_(0, dst, edge_weight * p[src]) / deg
            p = (1 - self.lam) * p + self.lam * Ap                 # Eq. 23
        return p.clamp(0, 1)
