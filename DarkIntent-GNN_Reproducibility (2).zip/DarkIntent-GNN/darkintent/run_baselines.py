"""Table 2 / Table 10: DarkIntent-GNN versus baselines on the same graphs."""
import argparse
from .utils.common import load_config, get_logger, save_json
from .experiment import prepare_graphs, temporal_split, train_model, evaluate, summarize, device
from .models.baselines import sklearn_random_forest
from .utils.metrics import binary_metrics

BASELINES = ["random_forest", "lstm", "gcn", "gat", "fedgat", "e-gracl", "graphch", "itdsts", "darkintent"]


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--dataset", default=None); ap.add_argument("--epochs", type=int, default=None)
    ap.add_argument("--max_windows", type=int, default=None); ap.add_argument("--seeds", default=None)
    ap.add_argument("--out", default="results/tables/baselines.json"); a = ap.parse_args()
    cfg = load_config(a.config, {"dataset": a.dataset} if a.dataset else None)
    if a.epochs: cfg["train"]["epochs"] = a.epochs
    seeds = [int(s) for s in a.seeds.split(",")] if a.seeds else cfg["eval"]["seeds"]
    log = get_logger("baselines"); ev, graphs = prepare_graphs(cfg, max_windows=a.max_windows); tr, va, te = temporal_split(graphs)
    table = {}
    for name in BASELINES:
        runs = []
        for s in seeds:
            if name == "random_forest":
                y, p = sklearn_random_forest(tr + va, te, s); runs.append(binary_metrics(y, p))
            else:
                m, _ = train_model(cfg, tr, va, name, s, log); r = evaluate(m, te, device()); r.pop("y_true"); r.pop("y_prob"); runs.append(r)
        table[name] = summarize(runs)
        log.info(f"{name:14s} " + " ".join(f"{k}={v['mean']:.4f}±{v['std']:.4f}" for k, v in table[name].items()))
    save_json(table, a.out)


if __name__ == "__main__":
    main()
