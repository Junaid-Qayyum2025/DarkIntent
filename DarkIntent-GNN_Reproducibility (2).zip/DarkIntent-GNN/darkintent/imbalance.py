"""Table 7 / Fig. 10: performance under class imbalance (synthetic re-sampling of the actor population)."""
import argparse
import numpy as np
from .utils.common import load_config, get_logger, save_json
from .experiment import prepare_graphs, temporal_split, train_model, evaluate, device
from .data.loader import load_events

RATIOS = {"balanced_1_1": 1, "moderate_1_10": 10, "high_1_100": 100, "extreme_1_1000": 1000, "realworld_1_5000": 5000}


def resample(ev, ratio, seed):
    rng = np.random.default_rng(seed)
    mal = sorted(set(ev.loc[ev["label"] == 1, "user"])); ben = sorted(set(ev["user"]) - set(mal))
    keep_mal = max(1, min(len(mal), len(ben) // ratio)) if ratio > 1 else min(len(mal), len(ben))
    keep_ben = min(len(ben), keep_mal * ratio)
    users = set(rng.choice(mal, keep_mal, replace=False)) | set(rng.choice(ben, keep_ben, replace=False))
    return ev[ev["user"].isin(users)].reset_index(drop=True)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--config", default="configs/default.yaml"); ap.add_argument("--dataset", default=None)
    ap.add_argument("--epochs", type=int, default=None); ap.add_argument("--max_windows", type=int, default=None); ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default="results/tables/imbalance.json"); a = ap.parse_args()
    cfg = load_config(a.config, {"dataset": a.dataset} if a.dataset else None)
    if a.epochs: cfg["train"]["epochs"] = a.epochs
    log = get_logger("imbalance"); ev = load_events(cfg["dataset"], cfg["data_root"], **cfg.get("data_kwargs", {})); table = {}
    for name, r in RATIOS.items():
        _, graphs = prepare_graphs(cfg, events=resample(ev, r, a.seed), max_windows=a.max_windows); tr, va, te = temporal_split(graphs)
        m, _ = train_model(cfg, tr, va, "darkintent", a.seed, log); res = evaluate(m, te, device())
        table[name] = {k: res[k] for k in ("precision", "recall", "f1", "auc")}; table[name]["pr_curve"] = {"y_true": res["y_true"], "y_prob": res["y_prob"]}
        log.info(f"{name}: " + " ".join(f"{k}={res[k]:.4f}" for k in ("precision", "recall", "f1", "auc")))
    save_json(table, a.out)


if __name__ == "__main__":
    main()
