"""Shared training / evaluation loop for all experiments."""
import time, copy
import numpy as np
import torch
from .data.loader import load_events
from .data.graph_builder import GraphBuilder, sliding_windows, NODE_FEATURE_DIM
from .data.features import EDGE_FEATURE_DIM
from .models.darkintent_gnn import DarkIntentGNN
from .models.losses import MultiTaskLoss
from .models.baselines import build_baseline
from .utils.metrics import binary_metrics, per_class_metrics, lead_time_stats
from .utils.common import set_seed, device


def prepare_graphs(cfg, events=None, stride_hours=24.0, max_windows=None, hetero=None):
    ev = events if events is not None else load_events(cfg["dataset"], cfg["data_root"], **cfg.get("data_kwargs", {}))
    hetero = cfg["model"].get("use_hetero_graph", True) if hetero is None else hetero
    gb = GraphBuilder(cfg["temporal_window_hours"], cfg["snapshot_hours"], hetero=hetero)
    graphs = sliding_windows(ev, gb, stride_hours, max_windows)
    return ev, graphs


def temporal_split(graphs, train=0.6, val=0.2):
    n = len(graphs); a = int(n * train); b = int(n * (train + val))
    return graphs[:a], graphs[a:b], graphs[b:]


def user_edges(graph):
    snap = graph.snapshots[-1]; ui = graph.user_index
    pos = torch.full((graph.num_nodes,), -1, dtype=torch.long, device=ui.device); pos[ui] = torch.arange(len(ui), device=ui.device)
    s, d = pos[snap.edge_index[0]], pos[snap.edge_index[1]]
    m = (s >= 0) & (d >= 0)
    return torch.stack([s[m], d[m]])


def make_model(cfg, name="darkintent"):
    if name == "darkintent":
        return DarkIntentGNN(NODE_FEATURE_DIM, EDGE_FEATURE_DIM, cfg["model"])
    return build_baseline(name, NODE_FEATURE_DIM, EDGE_FEATURE_DIM, cfg["model"])


def best_threshold(y, p):
    from sklearn.metrics import f1_score
    ths = np.linspace(0.05, 0.95, 91)
    f = [f1_score(y, (p >= t).astype(int), zero_division=0) for t in ths]
    return float(ths[int(np.argmax(f))])


def evaluate(model, graphs, dev, threshold=None, num_types=5):
    threshold = getattr(model, "threshold", 0.5) if threshold is None else threshold
    model.eval(); ys, ps, yc, pc, lead_alert, lead_attack = [], [], [], [], [], []
    with torch.no_grad():
        for g in graphs:
            g.to(dev); out = model(g)
            p = out["p_intent"].cpu().numpy(); y = g.y_intent.cpu().numpy()
            ys.append(y); ps.append(p)
            if "category_logits" in out:
                m = (g.y_category >= 0).cpu().numpy()
                yc.append(g.y_category.cpu().numpy()[m]); pc.append(out["category_logits"].argmax(-1).cpu().numpy()[m])
            atk = g.attack_time.cpu().numpy()
            hit = (p >= threshold) & (y == 1) & ~np.isnan(atk)
            lead_alert.extend([g.window_end] * int(hit.sum())); lead_attack.extend(atk[hit].tolist())
    y = np.concatenate(ys); p = np.concatenate(ps)
    res = binary_metrics(y, p, threshold)
    if yc:
        yc = np.concatenate(yc); pc = np.concatenate(pc)
        res["per_class"] = per_class_metrics(yc, pc, num_types)
    if lead_alert:
        res["lead_time"] = lead_time_stats(lead_alert, lead_attack)
    res["y_true"] = y.tolist(); res["y_prob"] = p.tolist()
    return res


def train_model(cfg, train_g, val_g, name="darkintent", seed=42, log=None, epochs=None):
    set_seed(seed); dev = device()
    model = make_model(cfg, name).to(dev)
    tcfg = cfg["train"]; epochs = epochs or tcfg["epochs"]
    opt = torch.optim.Adam(model.parameters(), lr=tcfg["lr"], betas=(0.9, 0.999), weight_decay=tcfg["weight_decay"])
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs) if tcfg.get("cosine_annealing") else None
    crit = MultiTaskLoss(tuple(tcfg["task_weights_init"]), tcfg["meta_lr"], tcfg["focal_alpha"], tcfg["focal_gamma"], tcfg["lambda_smooth"]).to(dev)
    best, best_state, patience, t0 = -1, None, 0, time.time()
    for ep in range(epochs):
        model.train(); tot = 0.0
        for g in train_g:
            g.to(dev); opt.zero_grad()
            out = model(g)
            loss, comp = crit(out, g, model, user_edges(g)) if name == "darkintent" else (crit.components(out, g, model)["focal"], {})
            loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0); opt.step(); tot += float(loss.detach())
        if sched: sched.step()
        # validation and meta task weight update (Eq. 29)
        model.eval()
        with torch.no_grad():
            vcomp = {"focal": 0, "anomaly": 0, "category": 0, "reg": 0}
            for g in val_g:
                g.to(dev); c = crit.components(model(g), g, model, user_edges(g))
                for k in vcomp: vcomp[k] += float(c[k]) / max(len(val_g), 1)
        if name == "darkintent" and cfg["model"].get("use_multitask", True):
            crit.meta_update(vcomp)
        vres = evaluate(model, val_g, dev) if val_g else {"f1": tot}
        score = (vres["auc"] if vres["auc"] == vres["auc"] else vres["f1"]) if val_g else -tot
        if log and (ep % 5 == 0 or ep == epochs - 1):
            log.info(f"[{name}] seed={seed} epoch={ep+1}/{epochs} loss={tot/len(train_g):.4f} val_f1={vres.get('f1', float('nan')):.4f} lr={opt.param_groups[0]['lr']:.2e} w={crit.w.tolist()}")
        if score > best:
            best, best_state, patience = score, copy.deepcopy(model.state_dict()), 0
        else:
            patience += 1
            if patience >= tcfg["early_stop_patience"]:
                break
    if best_state is not None:
        model.load_state_dict(best_state)
    if val_g:                                   # decision threshold chosen on validation F1
        v = evaluate(model, val_g, dev, threshold=0.5); model.threshold = best_threshold(np.array(v["y_true"]), np.array(v["y_prob"]))
    else:
        model.threshold = 0.5
    return model, {"train_minutes": (time.time() - t0) / 60.0, "epochs_run": ep + 1, "params_M": sum(p.numel() for p in model.parameters()) / 1e6}


def summarize(runs, keys=("accuracy", "precision", "recall", "f1", "auc", "fpr")):
    out = {}
    for k in keys:
        v = np.array([r[k] for r in runs if k in r], dtype=float)
        out[k] = {"mean": float(np.nanmean(v)), "std": float(np.nanstd(v))}
    return out
