"""Table 9 / Fig. 12: early warning lead time analysis (Section IV-I)."""
import argparse
import numpy as np
from .utils.common import load_config, get_logger, save_json
from .experiment import prepare_graphs, temporal_split, train_model, device
from .data.schema import THREAT_TYPES
import torch


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--config", default="configs/default.yaml"); ap.add_argument("--dataset", default=None)
    ap.add_argument("--epochs", type=int, default=None); ap.add_argument("--max_windows", type=int, default=None); ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--stride_hours", type=float, default=6.0); ap.add_argument("--threshold", type=float, default=0.5)
    ap.add_argument("--out", default="results/tables/early_warning.json"); a = ap.parse_args()
    cfg = load_config(a.config, {"dataset": a.dataset} if a.dataset else None)
    if a.epochs: cfg["train"]["epochs"] = a.epochs
    log = get_logger("early_warning"); ev, graphs = prepare_graphs(cfg, stride_hours=a.stride_hours, max_windows=a.max_windows)
    tr, va, te = temporal_split(graphs); m, _ = train_model(cfg, tr, va, "darkintent", a.seed, log); m.eval(); dev = device()
    first_alert, attack, ttype, fp_alerts, tp_alerts = {}, {}, {}, 0, 0
    with torch.no_grad():
        for g in te:
            g.to(dev); p = m(g)["p_intent"].cpu().numpy(); y = g.y_intent.cpu().numpy(); atk = g.attack_time.cpu().numpy(); cat = g.y_category.cpu().numpy()
            for i, ui in enumerate(g.user_index.cpu().numpy()):
                name = g.node_names[ui]
                if p[i] >= a.threshold:
                    if y[i] == 1:
                        tp_alerts += 1
                        if name not in first_alert: first_alert[name] = g.window_end; attack[name] = atk[i]; ttype[name] = int(cat[i])
                    else:
                        fp_alerts += 1
    lead = np.array([attack[k] - first_alert[k] for k in first_alert if not np.isnan(attack[k])])
    n_mal = len(set(ev.loc[ev["label"] == 1, "user"]))
    table = {"precision_of_alerts": tp_alerts / max(tp_alerts + fp_alerts, 1), "mean_lead_hours": float(lead.mean()) if len(lead) else None, "windows": {}}
    for th in (24, 12, 6, 3, 1):
        table["windows"][f">{th}h"] = {"detection_rate": float((lead > th).sum() / max(n_mal, 1))}
    table["by_threat_type"] = {THREAT_TYPES[t]: {"mean_lead_hours": float(np.mean([attack[k] - first_alert[k] for k in first_alert if ttype[k] == t])) }
                               for t in set(ttype.values()) if t >= 0}
    log.info(table); save_json(table, a.out)


if __name__ == "__main__":
    main()
