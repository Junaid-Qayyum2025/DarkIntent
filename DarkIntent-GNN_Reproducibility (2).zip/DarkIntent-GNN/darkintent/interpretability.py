"""Fig. 13: export attention weights, critical subgraph, temporal activation, feature importance (SHAP-style permutation)."""
import argparse
import numpy as np, torch
from .utils.common import load_config, get_logger, save_json
from .experiment import prepare_graphs, temporal_split, train_model, device
from .data.features import USER_FEATURE_DIM
from .data.schema import NODE_TYPES

FEAT = ["access_frequency", "time_patterns", "resource_diversity", "data_volume", "action_sequence", "role_context", "dept",
        "tenure", "privilege_level", "location_div", "mu_access", "sigma_access", "behavioral_entropy", "rareness"]


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--config", default="configs/default.yaml"); ap.add_argument("--dataset", default=None)
    ap.add_argument("--epochs", type=int, default=None); ap.add_argument("--max_windows", type=int, default=None); ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default="results/tables/interpretability.json"); a = ap.parse_args()
    cfg = load_config(a.config, {"dataset": a.dataset} if a.dataset else None)
    if a.epochs: cfg["train"]["epochs"] = a.epochs
    log = get_logger("interp"); ev, graphs = prepare_graphs(cfg, max_windows=a.max_windows); tr, va, te = temporal_split(graphs)
    m, _ = train_model(cfg, tr, va, "darkintent", a.seed, log); m.eval(); dev = device(); g = te[-1].to(dev)
    with torch.no_grad():
        out = m(g); p = out["p_intent"].cpu().numpy(); feat_att, layer_atts = out["attention"]; snap = g.snapshots[-1]
        # (a) edge attention around the top-scoring user
        edge_alpha = layer_atts[-1]["edge"].cpu().numpy(); top = int(np.argmax(p)); top_node = int(g.user_index[top])
        ei = snap.edge_index.cpu().numpy(); msk = (ei[0] == top_node) | (ei[1] == top_node)
        edges = [{"src": g.node_names[ei[0][i]], "dst": g.node_names[ei[1][i]], "attention": float(edge_alpha[i])} for i in np.where(msk)[0]]
        # (c) node-type attention normal vs threat: mean incoming attention grouped by dst node type, split by user label
        nt = g.node_type.cpu().numpy(); y = g.y_intent.cpu().numpy(); ui = g.user_index.cpu().numpy()
        mal_nodes = set(ui[y == 1]); ben_nodes = set(ui[y == 0])
        type_att = {"normal": {}, "threat": {}}
        for t, name in enumerate(NODE_TYPES):
            for grp, S in (("normal", ben_nodes), ("threat", mal_nodes)):
                sel = [i for i in range(ei.shape[1]) if ei[0][i] in S and nt[ei[1][i]] == t]
                type_att[grp][name] = float(edge_alpha[sel].mean()) if sel else 0.0
        # (b) subgraph attention per relation (beta) averaged over nodes
        beta = layer_atts[-1]["subgraph"]; rel_att = beta.mean(1).cpu().numpy().tolist() if beta is not None else None
        # (d) temporal activation of the top user across windows
        traj = []
        for gg in te:
            gg.to(dev); pp = m(gg)["p_intent"].cpu().numpy(); names = [gg.node_names[i] for i in gg.user_index.cpu().numpy()]
            tn = g.node_names[top_node]; traj.append(float(pp[names.index(tn)]) if tn in names else None)
        # (e) permutation feature importance on user features
        base = p.copy(); imp = {}
        for f in range(USER_FEATURE_DIM):
            x0 = snap.x.clone(); perm = torch.randperm(len(ui), device=dev); snap.x[g.user_index, f] = x0[g.user_index[perm], f]
            pf = m(g)["p_intent"].cpu().numpy(); imp[FEAT[f]] = float(np.abs(pf - base).mean()); snap.x = x0
        tot = sum(imp.values()) + 1e-9; imp = {k: v / tot for k, v in sorted(imp.items(), key=lambda kv: -kv[1])}
    res = {"top_user": g.node_names[top_node], "edge_attention": edges, "node_type_attention": type_att, "relation_attention": rel_att,
           "temporal_activation": traj, "feature_importance": imp, "lambda_learned": float(m.prop.lam) if m.prop is not None else None}
    save_json(res, a.out); log.info(f"saved {a.out}; learned lambda={res['lambda_learned']}")


if __name__ == "__main__":
    main()
