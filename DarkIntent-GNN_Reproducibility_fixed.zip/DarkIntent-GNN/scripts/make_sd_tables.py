"""Turn run outputs into 'mean ± std' rows (four decimals) for Tables 2, 4 and 10.

Usage (after scripts/run_all.sh has written the JSON files):
    python scripts/make_sd_tables.py results/tables/baselines.json results/tables/ablation.json
Writes results/tables/mean_std_tables.csv and prints the rows.
Each JSON is {row_name: {metric: {"mean": m, "std": s}, ...}, ...} over the five seeds (42-46).
Paste these values into the manuscript tables; do not edit them by hand.
"""
import csv, json, os, sys

def main(paths):
    out = []
    for p in paths:
        with open(p) as f:
            tab = json.load(f)
        for row, metrics in tab.items():
            cells = {k: f"{v['mean']:.4f} ± {v['std']:.4f}" for k, v in metrics.items() if isinstance(v, dict) and "mean" in v}
            out.append({"source": os.path.basename(p), "row": row, **cells})
    keys = ["source", "row"] + sorted({k for r in out for k in r if k not in ("source", "row")})
    os.makedirs("results/tables", exist_ok=True)
    with open("results/tables/mean_std_tables.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys); w.writeheader(); w.writerows(out)
    for r in out:
        print(" | ".join(str(r.get(k, "")) for k in keys))

if __name__ == "__main__":
    main(sys.argv[1:] or ["results/tables/baselines.json", "results/tables/ablation.json"])
