import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Liberation Serif", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "font.size": 10.5,
    "axes.titlesize": 11.5,
    "axes.titleweight": "bold",
    "axes.labelsize": 10.5,
    "axes.labelweight": "bold",
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "legend.fontsize": 9,
    "legend.frameon": True,
    "legend.framealpha": 0.95,
    "axes.linewidth": 0.8,
    "axes.grid": True,
    "grid.alpha": 0.3,
    "grid.linewidth": 0.5,
    "savefig.dpi": 600,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.03,
})

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "output")
os.makedirs(OUT, exist_ok=True)

C = {"blue": "#1F5FA8", "orange": "#E07B00", "green": "#2E8B57", "red": "#C0392B",
     "purple": "#7D3C98", "gray": "#7F8C8D", "gold": "#F1C40F", "teal": "#148F77"}

def save(fig, name):
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(OUT, f"{name}.{ext}"))
    plt.close(fig)
# Figure 8: Parameter sensitivity (Table 5)
panels = [
    ("(a) Attention heads", "Number of Attention Heads", [1, 2, 4, 8, 12, 16],
     [0.942, 0.956, 0.968, 0.973, 0.971, 0.969], [0.938, 0.952, 0.964, 0.969, 0.967, 0.965], 8, "±3.2%"),
    ("(b) Hidden dimension", "Hidden Dimension", [64, 128, 256, 384, 512],
     [0.931, 0.954, 0.973, 0.971, 0.969], [0.927, 0.950, 0.969, 0.967, 0.965], 256, "±4.1%"),
    ("(c) Temporal window", "Temporal Window Length (hours)", [24, 48, 72, 96, 120, 144, 168],
     [0.952, 0.963, 0.973, 0.970, 0.968, 0.965, 0.963], [0.948, 0.959, 0.969, 0.966, 0.964, 0.961, 0.958], 72, "±2.8%"),
    ("(d) Graph depth", "Graph Depth (hops)", [1, 2, 3, 4, 5],
     [0.921, 0.955, 0.973, 0.968, 0.965], [0.917, 0.950, 0.969, 0.964, 0.961], 3, "±3.6%"),
]
fig, axes = plt.subplots(2, 2, figsize=(7.16, 5.6), constrained_layout=True)
for ax, (title, xlab, xs, acc, f1, opt, imp) in zip(axes.flat, panels):
    p = np.arange(len(xs))
    ax.plot(p, acc, "-o", color=C["blue"], lw=1.5, ms=5.5, label="Accuracy", markeredgecolor="black", markeredgewidth=0.4)
    ax.plot(p, f1, "-s", color=C["red"], lw=1.5, ms=5, label="F1-Score", markeredgecolor="black", markeredgewidth=0.4)
    ax.fill_between(p, f1, acc, color=C["gray"], alpha=0.15, lw=0)
    io = xs.index(opt)
    ax.axvline(io, color=C["orange"], ls="--", lw=1)
    ax.plot(io, acc[io], marker="*", color=C["gold"], ms=15, markeredgecolor="black", markeredgewidth=0.6, zorder=5)
    ax.text(io, 0.9855, f"Optimal = {opt}", ha="center", va="bottom", fontsize=8.5, color=C["orange"], fontweight="bold")
    ax.text(0.03, 0.05, f"Impact range {imp}", transform=ax.transAxes, fontsize=8.5,
            bbox=dict(boxstyle="round,pad=0.3", fc="white", ec=C["gray"], lw=0.6))
    ax.set_xticks(p); ax.set_xticklabels(xs)
    ax.set_ylim(0.91, 0.995); ax.set_xlabel(xlab); ax.set_ylabel("Performance Score"); ax.set_title(title)
    ax.legend(loc="lower right", handlelength=1.6)
save(fig, "fig8_parameter_sensitivity")
