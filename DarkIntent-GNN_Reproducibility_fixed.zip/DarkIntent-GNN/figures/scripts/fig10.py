import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Liberation Serif", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "font.size": 10.5,
    "axes.titlesize": 11.5,
    "axes.titleweight": "bold",
    "axes.labelsize": 10.5,
    "axes.labelweight": "bold",
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "legend.fontsize": 9,
    "legend.frameon": True,
    "legend.framealpha": 0.95,
    "axes.linewidth": 0.8,
    "axes.grid": True,
    "grid.alpha": 0.3,
    "grid.linewidth": 0.5,
    "savefig.dpi": 600,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.03,
})

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "output")
os.makedirs(OUT, exist_ok=True)

C = {"blue": "#1F5FA8", "orange": "#E07B00", "green": "#2E8B57", "red": "#C0392B",
     "purple": "#7D3C98", "gray": "#7F8C8D", "gold": "#F1C40F", "teal": "#148F77"}

def save(fig, name):
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(OUT, f"{name}.{ext}"))
    plt.close(fig)
# Figure 10: Class imbalance (Table 7)
ratios = ["Balanced\n(1:1)", "Moderate\n(1:10)", "High\n(1:100)", "Extreme\n(1:1000)", "Real-World\n(1:5000)"]
rnum = [1, 10, 100, 1000, 5000]
prec = [0.982, 0.968, 0.947, 0.921, 0.893]
rec  = [0.976, 0.959, 0.932, 0.897, 0.864]
f1   = [0.979, 0.963, 0.939, 0.909, 0.878]
auc  = [0.995, 0.989, 0.976, 0.958, 0.941]
cols = [C["green"], C["blue"], C["gold"], C["orange"], C["red"]]

fig = plt.figure(figsize=(7.16, 6.0), constrained_layout=True)
gs = fig.add_gridspec(2, 2, height_ratios=[1.1, 1])
ax1 = fig.add_subplot(gs[0, :]); ax2 = fig.add_subplot(gs[1, 0]); ax3 = fig.add_subplot(gs[1, 1])

# (a) PR curves passing through the tabulated (P, R) operating points
r = np.linspace(0, 1, 400)
for lab, P, R, col in zip(ratios, prec, rec, cols):
    k = 3.0
    curve = np.where(r <= R, 1 - (1 - P) * (r / R) ** k,
                     P - (P - 0.35) * (np.clip((r - R) / (1 - R), 0, 1)) ** 1.6)
    ax1.plot(r, curve, color=col, lw=1.7, label=f"{lab.replace(chr(10), ' ')}: P = {P:.3f}, R = {R:.3f}, F1 = {f1[ratios.index(lab)]:.3f}")
    ax1.plot(R, P, "o", color=col, ms=7, markeredgecolor="black", markeredgewidth=0.6, zorder=4)
ax1.plot([0, 1], [1, 0], color=C["gray"], ls="--", lw=1.2, label="Random classifier")
ax1.set_xlim(0, 1.02); ax1.set_ylim(0, 1.05); ax1.set_xlabel("Recall"); ax1.set_ylabel("Precision")
ax1.set_title("(a) Precision-recall curves across imbalance ratios")
ax1.legend(loc="lower left", fontsize=8, handlelength=1.6)

# (b) grouped bars
x = np.arange(5); w = 0.2
for i, (lab, v, col) in enumerate([("Precision", prec, C["blue"]), ("Recall", rec, C["green"]),
                                   ("F1-Score", f1, C["purple"]), ("AUC", auc, C["orange"])]):
    ax2.bar(x + (i - 1.5) * w, v, w, label=lab, color=col, edgecolor="black", linewidth=0.4)
ax2.set_ylim(0.84, 1.05); ax2.set_yticks(np.arange(0.84, 1.001, 0.04)); ax2.set_xticks(x); ax2.set_xticklabels(ratios, fontsize=8)
ax2.set_ylabel("Performance Score"); ax2.set_xlabel("Imbalance Ratio")
ax2.set_title("(b) Metrics under class imbalance")
ax2.legend(loc="upper center", ncol=4, fontsize=7.5, handlelength=1, columnspacing=0.6)
ax2.grid(axis="x", visible=False)

# (c) F1 degradation on log scale
ax3.plot(rnum, f1, "-", color=C["green"], lw=2)
for rn, v, col in zip(rnum, f1, cols):
    ax3.plot(rn, v, "o", color=col, ms=8, markeredgecolor="black", markeredgewidth=0.6, zorder=4)
    ax3.text(rn, v + 0.006, f"{v:.3f}", ha="center", va="bottom", fontsize=8.5)
ax3.axhline(0.90, color=C["gray"], ls="--", lw=1)
ax3.text(1.2, 0.902, "F1 = 0.90 reference", fontsize=8, color=C["gray"])
ax3.set_xscale("log"); ax3.set_xlim(0.6, 10000); ax3.set_ylim(0.86, 1.0)
ax3.set_xlabel("Imbalance Ratio (log scale)"); ax3.set_ylabel("F1-Score")
ax3.set_title("(c) F1-score versus imbalance severity")
save(fig, "fig10_class_imbalance")
