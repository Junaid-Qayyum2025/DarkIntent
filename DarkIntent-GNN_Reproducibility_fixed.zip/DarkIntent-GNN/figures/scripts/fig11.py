import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Liberation Serif", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "font.size": 10.5,
    "axes.titlesize": 11.5,
    "axes.titleweight": "bold",
    "axes.labelsize": 10.5,
    "axes.labelweight": "bold",
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "legend.fontsize": 9,
    "legend.frameon": True,
    "legend.framealpha": 0.95,
    "axes.linewidth": 0.8,
    "axes.grid": True,
    "grid.alpha": 0.3,
    "grid.linewidth": 0.5,
    "savefig.dpi": 600,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.03,
})

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "output")
os.makedirs(OUT, exist_ok=True)

C = {"blue": "#1F5FA8", "orange": "#E07B00", "green": "#2E8B57", "red": "#C0392B",
     "purple": "#7D3C98", "gray": "#7F8C8D", "gold": "#F1C40F", "teal": "#148F77"}

def save(fig, name):
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(OUT, f"{name}.{ext}"))
    plt.close(fig)
# Figure 11: Zero-day detection (Table 8)
methods = ["Random Forest", "LSTM", "GCN", "GraphCH", "ITDSTS", "DarkIntent-GNN"]
known = [0.806, 0.824, 0.861, 0.912, 0.917, 0.974]
zero  = [0.542, 0.611, 0.698, 0.802, 0.819, 0.894]
deg   = [32.8, 25.9, 18.9, 12.1, 10.7, 8.2]
months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
di = [0.974, 0.971, 0.968, 0.952, 0.937, 0.920, 0.905, 0.895, 0.889, 0.891, 0.893, 0.894]
it = [0.917, 0.912, 0.907, 0.883, 0.861, 0.841, 0.828, 0.819, 0.815, 0.817, 0.818, 0.819]
gc = [0.912, 0.905, 0.898, 0.870, 0.845, 0.822, 0.807, 0.802, 0.799, 0.801, 0.802, 0.802]

fig = plt.figure(figsize=(7.16, 6.0), constrained_layout=True)
gs = fig.add_gridspec(2, 2, height_ratios=[1, 1.05])
ax1 = fig.add_subplot(gs[0, 0]); ax2 = fig.add_subplot(gs[0, 1]); ax3 = fig.add_subplot(gs[1, :])

x = np.arange(len(methods)); w = 0.38
ax1.bar(x - w / 2, known, w, color=C["green"], edgecolor="black", linewidth=0.4, label="Known attacks")
ax1.bar(x + w / 2, zero, w, color=C["red"], edgecolor="black", linewidth=0.4, label="Zero-day attacks")
ax1.set_ylim(0.5, 1.0); ax1.set_xticks(x); ax1.set_xticklabels(methods, fontsize=8, rotation=45, ha="right")
ax1.set_ylabel("F1-Score"); ax1.set_title("(a) Known versus zero-day F1")
ax1.legend(loc="upper left", fontsize=8, handlelength=1.2); ax1.grid(axis="x", visible=False)

cols = [C["gray"], C["blue"], C["green"], C["orange"], C["red"], C["gold"]]
y = np.arange(len(methods))
ax2.axvspan(0, 10, color=C["green"], alpha=0.12, lw=0); ax2.axvspan(10, 20, color=C["gold"], alpha=0.15, lw=0)
ax2.axvspan(20, 38, color=C["red"], alpha=0.10, lw=0)
for yi, d, col in zip(y, deg, cols):
    ax2.plot([0, d], [yi, yi], color=col, lw=3, solid_capstyle="round")
    ax2.plot(d, yi, "o", color=col, ms=9, markeredgecolor="black", markeredgewidth=0.6)
    ax2.text(d + 1.2, yi, f"{d}%", va="center", fontsize=8.5, fontweight="bold")
ax2.set_yticks(y); ax2.set_yticklabels(methods, fontsize=8.5)
ax2.set_xlim(0, 38); ax2.set_ylim(5.6, -0.9); ax2.set_xlabel("Performance Degradation (%)")
ax2.set_title("(b) Known-to-zero-day degradation"); ax2.grid(axis="y", visible=False)
ax2.text(5, -0.6, "<10%", ha="center", fontsize=7.5, color=C["green"]); ax2.text(15, -0.6, "10 to 20%", ha="center", fontsize=7.5, color="#B7950B")
ax2.text(29, -0.6, ">20%", ha="center", fontsize=7.5, color=C["red"])

m = np.arange(12)
ax3.axvspan(-0.5, 7.5, color=C["blue"], alpha=0.08, lw=0); ax3.axvspan(7.5, 11.5, color=C["red"], alpha=0.08, lw=0)
ax3.axvline(7.5, color="black", ls="--", lw=1.3)
ax3.plot(m, di, "-o", color=C["orange"], lw=2, ms=6, label="DarkIntent-GNN", markeredgecolor="black", markeredgewidth=0.4)
ax3.plot(m, it, "-s", color=C["red"], lw=1.5, ms=5, label="ITDSTS", markeredgecolor="black", markeredgewidth=0.4)
ax3.plot(m, gc, "-^", color=C["purple"], lw=1.5, ms=5, label="GraphCH", markeredgecolor="black", markeredgewidth=0.4)
ax3.text(3.5, 0.765, "Training period (known attacks)", ha="center", fontsize=9, color=C["blue"], fontweight="bold")
ax3.text(9.5, 0.765, "Testing period\n(zero-day attacks)", ha="center", fontsize=9, color=C["red"], fontweight="bold")
ax3.text(7.55, 1.0, " Temporal split", va="top", fontsize=8.5)
ax3.set_xticks(m); ax3.set_xticklabels(months); ax3.set_xlim(-0.5, 11.5); ax3.set_ylim(0.75, 1.01)
ax3.set_xlabel("Time (months)"); ax3.set_ylabel("Detection Accuracy")
ax3.set_title("(c) Temporal hold-out validation with zero-day emergence")
ax3.legend(loc="lower left", bbox_to_anchor=(0.0, 0.14), fontsize=8.5, handlelength=1.8)
save(fig, "fig11_zero_day_detection")
