import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Liberation Serif", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "font.size": 10.5,
    "axes.titlesize": 11.5,
    "axes.titleweight": "bold",
    "axes.labelsize": 10.5,
    "axes.labelweight": "bold",
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "legend.fontsize": 9,
    "legend.frameon": True,
    "legend.framealpha": 0.95,
    "axes.linewidth": 0.8,
    "axes.grid": True,
    "grid.alpha": 0.3,
    "grid.linewidth": 0.5,
    "savefig.dpi": 600,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.03,
})

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "output")
os.makedirs(OUT, exist_ok=True)

C = {"blue": "#1F5FA8", "orange": "#E07B00", "green": "#2E8B57", "red": "#C0392B",
     "purple": "#7D3C98", "gray": "#7F8C8D", "gold": "#F1C40F", "teal": "#148F77"}

def save(fig, name):
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(OUT, f"{name}.{ext}"))
    plt.close(fig)
# Figure 9: Computational efficiency (Table 6)
methods = ["Random Forest", "LSTM", "GCN", "GAT", "GraphCH", "ITDSTS", "DarkIntent-GNN"]
train = [8.3, 12.7, 18.4, 23.7, 28.6, 26.4, 34.8]
infer = [2.1, 5.4, 8.2, 11.6, 13.7, 12.9, 15.7]
mem   = [0.4, 1.2, 2.3, 3.1, 3.8, 3.5, 4.6]
params= [0.2, 2.8, 3.7, 5.9, 6.9, 6.4, 8.7]
nodes = [1000, 2500, 5000, 10000, 15000, 20000]
scale = {"LSTM": [3, 6, 13, 27, 43, 62], "GCN": [5, 9, 19, 39, 63, 92], "GAT": [6, 12, 24, 48, 77, 106],
         "GraphCH": [7, 14, 28, 56, 85, 116], "DarkIntent-GNN": [9, 16, 35, 64, 92, 118]}

fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(7.16, 3.1), constrained_layout=True)
x = np.arange(len(methods)); w = 0.38
b1 = ax1.bar(x - w / 2, train, w, color=C["blue"], edgecolor="black", linewidth=0.4, label="Training time (min/epoch)")
ax1b = ax1.twinx(); ax1b.grid(False)
b2 = ax1b.bar(x + w / 2, infer, w, color=C["red"], edgecolor="black", linewidth=0.4, label="Inference latency (ms)")
ax1.set_ylim(0, 44); ax1b.set_ylim(0, 22)
ax1.set_xticks(x); ax1.set_xticklabels(methods, rotation=45, ha="right", fontsize=8)
ax1.set_ylabel("Training Time (min)"); ax1b.set_ylabel("Inference Latency (ms)")
ax1.legend(handles=[b1, b2], loc="upper left", fontsize=7.5, handlelength=1.2)
ax1.set_title("(a) Training and inference cost")

cols = [C["gray"], C["blue"], C["green"], C["purple"], C["orange"], C["red"], C["gold"]]
labels = list(methods)
for mi, pi, col, lab in zip(mem, params, cols, labels):
    ax2.scatter(mi, pi, s=40 + pi * 28, color=col, edgecolor="black", linewidth=0.6, zorder=3)
offs = {"Random Forest": (0.15, 0.4), "LSTM": (0.15, 0.4), "GCN": (0.15, 0.4), "GAT": (-0.9, -0.2),
        "GraphCH": (1.0, 0.4), "ITDSTS": (0.9, -1.1), "DarkIntent-GNN": (-1.0, 1.0)}
for mi, pi, lab in zip(mem, params, labels):
    dx, dy = offs[lab]
    ax2.annotate(lab, (mi, pi), (mi + dx, pi + dy), fontsize=7.5, ha="center",
                 arrowprops=dict(arrowstyle="-", lw=0.5, color="gray"))
ax2.set_xlim(0, 5.6); ax2.set_ylim(-0.5, 11)
ax2.set_xlabel("Memory Consumption (GB)"); ax2.set_ylabel("Parameters (M)")
ax2.set_title("(b) Memory vs. parameters")

mk = {"LSTM": "o", "GCN": "s", "GAT": "^", "GraphCH": "D", "DarkIntent-GNN": "*"}
cl = {"LSTM": C["blue"], "GCN": C["green"], "GAT": C["purple"], "GraphCH": C["orange"], "DarkIntent-GNN": C["red"]}
for k, v in scale.items():
    ax3.plot(nodes, v, marker=mk[k], color=cl[k], lw=1.3, ms=6 if k != "DarkIntent-GNN" else 9,
             label=k, markeredgecolor="black", markeredgewidth=0.4)
ax3.set_xlabel("Network Size (nodes)"); ax3.set_ylabel("Training Time (min)")
ax3.set_xticks([0, 5000, 10000, 15000, 20000]); ax3.set_xticklabels(["0", "5k", "10k", "15k", "20k"])
ax3.set_title("(c) Scalability")
ax3.legend(loc="upper left", fontsize=7.5, handlelength=1.6)
save(fig, "fig9_computational_efficiency")
