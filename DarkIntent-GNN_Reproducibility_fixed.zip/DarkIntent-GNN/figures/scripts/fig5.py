import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Liberation Serif", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "font.size": 10.5,
    "axes.titlesize": 11.5,
    "axes.titleweight": "bold",
    "axes.labelsize": 10.5,
    "axes.labelweight": "bold",
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "legend.fontsize": 9,
    "legend.frameon": True,
    "legend.framealpha": 0.95,
    "axes.linewidth": 0.8,
    "axes.grid": True,
    "grid.alpha": 0.3,
    "grid.linewidth": 0.5,
    "savefig.dpi": 600,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.03,
})

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "output")
os.makedirs(OUT, exist_ok=True)

C = {"blue": "#1F5FA8", "orange": "#E07B00", "green": "#2E8B57", "red": "#C0392B",
     "purple": "#7D3C98", "gray": "#7F8C8D", "gold": "#F1C40F", "teal": "#148F77"}

def save(fig, name):
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(OUT, f"{name}.{ext}"))
    plt.close(fig)
# Figure 5: Overall detection performance (Table 2)
methods = ["Random Forest", "LSTM", "GCN", "GAT", "FedGAT", "E-GRACL", "GraphCH", "ITDSTS", "DarkIntent-GNN"]
acc  = [0.847, 0.862, 0.891, 0.903, 0.912, 0.918, 0.931, 0.936, 0.973]
prec = [0.823, 0.841, 0.872, 0.887, 0.896, 0.903, 0.918, 0.923, 0.968]
rec  = [0.791, 0.808, 0.851, 0.869, 0.881, 0.889, 0.906, 0.912, 0.959]
f1   = [0.806, 0.824, 0.861, 0.878, 0.888, 0.896, 0.912, 0.917, 0.963]
metrics = [("Accuracy", acc, C["blue"]), ("Precision", prec, C["orange"]),
           ("Recall", rec, C["green"]), ("F1-Score", f1, C["red"])]

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.16, 3.3), constrained_layout=True)
x = np.arange(len(methods)); w = 0.2
for i, (lab, v, col) in enumerate(metrics):
    bars = ax1.bar(x + (i - 1.5) * w, v, w, label=lab, color=col,
                   edgecolor="black", linewidth=0.4)
ax1.set_ylim(0.75, 1.0); ax1.set_xticks(x); ax1.set_xticklabels(methods, rotation=45, ha="right")
ax1.set_ylabel("Performance Score"); ax1.set_xlabel("Method")
ax1.set_title("(a) Detection metrics by method")
ax1.axvspan(x[-1] - 0.5, x[-1] + 0.5, color=C["gold"], alpha=0.15, lw=0)
ax1.legend(loc="upper left", ncol=2, handlelength=1.2, columnspacing=0.8)

markers = ["o", "s", "^", "D"]
for i, (lab, v, col) in enumerate(metrics):
    ax2.plot(x, v, marker=markers[i], color=col, label=lab, lw=1.4, ms=5,
             markeredgecolor="black", markeredgewidth=0.4)
ax2.set_ylim(0.78, 0.985); ax2.set_xticks(x); ax2.set_xticklabels(methods, rotation=45, ha="right")
ax2.set_ylabel("Performance Score"); ax2.set_xlabel("Method")
ax2.set_title("(b) Trend across methods")
ax2.axvspan(x[-1] - 0.5, x[-1] + 0.5, color=C["gold"], alpha=0.15, lw=0)
ax2.legend(loc="lower right", handlelength=1.6)
save(fig, "fig5_overall_performance")
