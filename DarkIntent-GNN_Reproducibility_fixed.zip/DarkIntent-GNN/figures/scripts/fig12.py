import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Liberation Serif", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "font.size": 10.5,
    "axes.titlesize": 11.5,
    "axes.titleweight": "bold",
    "axes.labelsize": 10.5,
    "axes.labelweight": "bold",
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "legend.fontsize": 9,
    "legend.frameon": True,
    "legend.framealpha": 0.95,
    "axes.linewidth": 0.8,
    "axes.grid": True,
    "grid.alpha": 0.3,
    "grid.linewidth": 0.5,
    "savefig.dpi": 600,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.03,
})

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "output")
os.makedirs(OUT, exist_ok=True)

C = {"blue": "#1F5FA8", "orange": "#E07B00", "green": "#2E8B57", "red": "#C0392B",
     "purple": "#7D3C98", "gray": "#7F8C8D", "gold": "#F1C40F", "teal": "#148F77"}

def save(fig, name):
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(OUT, f"{name}.{ext}"))
    plt.close(fig)
# Figure 12: Early warning capability (Table 9, Table 3)
hours = [0, 1, 3, 6, 12, 18, 24, 30, 36, 42, 48]
cum   = [100, 96.8, 93.2, 87.9, 76.4, 69.0, 61.3, 53.0, 43.0, 31.0, 18.0]
tab_h = [1, 3, 6, 12, 24]; tab_v = [96.8, 93.2, 87.9, 76.4, 61.3]
win = [">24 h", ">12 h", ">6 h", ">3 h", ">1 h"]
det = [61.3, 76.4, 87.9, 93.2, 96.8]; prc = [97.3, 96.1, 94.2, 92.1, 89.3]

threats = ["Insider Threat", "APT", "Data Exfiltration", "Privilege Abuse", "Lateral Movement"]
lead = [18.7, 14.3, 22.4, 16.8, 12.1]; drate = [96.5, 95.4, 97.8, 96.1, 94.7]

fig = plt.figure(figsize=(7.16, 6.0), constrained_layout=True)
gs = fig.add_gridspec(2, 2, height_ratios=[1, 1])
ax1 = fig.add_subplot(gs[0, :]); ax2 = fig.add_subplot(gs[1, 0]); ax3 = fig.add_subplot(gs[1, 1])

ax1.axhspan(80, 100, color=C["green"], alpha=0.10, lw=0); ax1.axhspan(60, 80, color=C["gold"], alpha=0.12, lw=0)
ax1.axhspan(0, 60, color=C["red"], alpha=0.08, lw=0)
ax1.plot(hours, cum, "-", color=C["blue"], lw=2.2, label="Cumulative detection rate")
ax1.plot(hours, cum, "o", color=C["orange"], ms=6, markeredgecolor="black", markeredgewidth=0.5, label="Tabulated points")
ax1.axvline(16.9, color=C["red"], lw=1.5)
ax1.text(17.4, 22, "Average lead time\n16.9 h", fontsize=8.5, color=C["red"], fontweight="bold")
ax1.text(47.5, 90, "Excellent", ha="right", fontsize=8.5, color=C["green"], style="italic")
ax1.text(47.5, 70, "Good", ha="right", fontsize=8.5, color="#B7950B", style="italic")
ax1.text(47.5, 50, "Limited", ha="right", fontsize=8.5, color=C["red"], style="italic")
ax1.set_xlim(0, 48); ax1.set_ylim(0, 108); ax1.set_xlabel("Lead Time Before Attack (hours)"); ax1.set_ylabel("Cumulative Detection Rate (%)")
ax1.set_title("(a) Cumulative detection rate versus lead time"); ax1.legend(loc="lower left", fontsize=8.5, handlelength=1.6)

x = np.arange(5); w = 0.32
for i, (lab, v, col) in enumerate([("Detection rate", det, C["blue"]), ("Precision", prc, C["green"])]):
    ax2.bar(x + (i - 0.5) * w, v, w, label=lab, color=col, edgecolor="black", linewidth=0.4)
ax2.set_ylim(50, 118); ax2.set_xticks(x); ax2.set_xticklabels(win)
ax2.set_xlabel("Lead Time Threshold"); ax2.set_ylabel("Metric (%)")
ax2.set_title("(b) Metrics at lead-time thresholds")
ax2.legend(loc="upper left", ncol=2, fontsize=7.5, handlelength=1, columnspacing=0.6); ax2.grid(axis="x", visible=False)

cols = [C["blue"], C["orange"], C["green"], C["red"], C["purple"]]
offs = [(0, 0.28), (0, 0.28), (0, 0.28), (0, -0.4), (0, 0.28)]
for t, l, d, col, (dx, dy) in zip(threats, lead, drate, cols, offs):
    ax3.scatter(l, d, s=180, color=col, edgecolor="black", linewidth=0.7, zorder=3)
    ax3.text(l + dx, d + dy, t, ha="center", va="bottom" if dy > 0 else "top", fontsize=8)
ax3.axvline(16.9, color=C["gray"], ls="--", lw=1); ax3.axhline(96.1, color=C["gray"], ls="--", lw=1)
ax3.text(10.3, 96.2, "Avg detection 96.1%", fontsize=7.5, color=C["gray"], va="bottom")
ax3.text(17.1, 93.3, "Avg lead 16.9 h", fontsize=7.5, color=C["gray"], rotation=90, va="bottom")
ax3.set_xlim(10, 25); ax3.set_ylim(93, 99)
ax3.set_xlabel("Average Lead Time (hours)"); ax3.set_ylabel("Detection Rate (%)")
ax3.set_title("(c) Lead time and detection by threat type")
save(fig, "fig12_early_warning")
