# DarkIntent-GNN — Reproduction Guide

This guide documents the exact steps to reproduce every table in the paper from scratch.

## Prerequisites

```bash
pip install -r requirements.txt
```

Hardware used in the paper: NVIDIA A100 GPU (40 GB), 64 GB RAM.
All experiments fall back to CPU if no GPU is available (slower but correct).

## Step 1: Download Datasets

```bash
bash data/download_datasets.sh
```

Follow the printed instructions to download CERT r4.2, LANL, UNSW-NB15,
and CIC-IDS2017 from their official sources. If datasets are unavailable,
synthetic data is used automatically (see data_loader.py).

## Step 2: Run Experiments

Each experiment script maps 1-to-1 to a table in the paper.

| Script | Table | Description |
|---|---|---|
| experiments/run_table2_overall_performance.py | Table 2 | Overall detection performance across 4 datasets |
| experiments/run_table3_threat_type.py | Table 3 | Per-threat-type F1 and lead time (CERT) |
| experiments/run_table4_ablation.py | Table 4 | Ablation study (CERT) |
| experiments/run_table5_sensitivity.py | Table 5 | Hyperparameter sensitivity |
| experiments/run_table6_computational.py | Table 6 | Computational efficiency |
| experiments/run_table7_class_imbalance.py | Table 7 | Class imbalance robustness |
| experiments/run_table8_zero_day.py | Table 8 | Zero-day detection |
| experiments/run_table9_early_warning.py | Table 9 | Lead time distribution |
| experiments/run_table10_sota_comparison.py | Table 10 | Full SOTA comparison |

Run all tables:

```bash
cd experiments
python run_table2_overall_performance.py
python run_table3_threat_type.py
python run_table4_ablation.py
python run_table5_sensitivity.py
python run_table6_computational.py
python run_table7_class_imbalance.py
python run_table8_zero_day.py
python run_table9_early_warning.py
python run_table10_sota_comparison.py
```

Results are saved to `results/tables/` as JSON files.

## Step 3: Verify Results

```bash
pytest tests/test_reproducibility.py -v
```

All tests must pass. The critical test is `test_lambda_init_exactly_05`.

## Key Reproducibility Notes

1. All reported metrics in the paper are mean values across 5 independent runs
   with seeds [42, 123, 456, 789, 1000]. Standard deviations are in the range
   ±0.0008 to ±0.0013 for all metrics.

2. The threat propagation decay factor λ is a learnable parameter initialized
   via `sigmoid(logit(0.5)) = 0.5` and converges to approximately 0.48 across
   all datasets and seeds (Table 5).

3. The mixing coefficient α_neural in Equation 24 is a fixed scalar set to 0.7.
   It is stored as a non-learnable buffer and is not updated during training.

4. Baseline models (Table 2, Table 10) receive the same raw tabular input
   features as DarkIntent-GNN without graph-structural augmentation, ensuring
   fair comparison.
