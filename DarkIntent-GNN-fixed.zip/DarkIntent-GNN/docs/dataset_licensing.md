# Dataset Licensing

## CERT Insider Threat Dataset r4.2
- Source: Carnegie Mellon University CERT Division
- URL: https://kilthub.cmu.edu/articles/dataset/Insider_Threat_Test_Dataset/12841247
- License: Requires registration. For research use only. Do not redistribute.
- Citation: Lindauer, B., et al. (2020). Generating a Realistic Insider Threat Test Dataset.
  CMU/SEI-2020-TR-006.

## LANL Cybersecurity Dataset
- Source: Los Alamos National Laboratory
- URL: https://csr.lanl.gov/data/cyber1/
- License: Publicly available for research. See LANL data use terms.
- Citation: Kent, A. (2015). Comprehensive, Multi-Source Cyber-Security Events.
  Los Alamos National Laboratory. DOI: 10.17021/1179829

## UNSW-NB15
- Source: University of New South Wales Canberra
- URL: https://research.unsw.edu.au/projects/unsw-nb15-dataset
- License: Publicly available for research.
- Citation: Moustafa, N., & Slay, J. (2015). UNSW-NB15: A comprehensive data set
  for network intrusion detection systems. MilCIS 2015.

## CIC-IDS2017
- Source: Canadian Institute for Cybersecurity, University of New Brunswick
- URL: https://www.unb.ca/cic/datasets/ids-2017.html
- License: Publicly available for research.
- Citation: Sharafaldin, I., et al. (2018). Toward Generating a New Intrusion
  Detection Dataset and Intrusion Traffic Characterization. ICISSP 2018.
