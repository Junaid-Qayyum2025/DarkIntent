# Changelog

## Round 6 — September 2026

### Fixed
- **Issue 5 (alpha_neural):** Reverted `alpha_neural` from a learnable
  `nn.Parameter` to a fixed scalar buffer (`alpha_neural = 0.7`) registered
  via `register_buffer`. This matches the paper's Equation 24 definition,
  which presents α_neural as a fixed hyperparameter. The learnable version
  was introduced erroneously in Round 5.

### Fixed (Round 5, carried forward)
- **Lambda initialization:** Corrected `log_lambda` initialization from
  `torch.log(tensor(0.5))` (buggy; gives sigmoid output of 0.333) to
  `torch.logit(tensor(0.5))` (correct; gives sigmoid output of exactly 0.5).
  Verified independently: `sigmoid(logit(0.5)) = 0.500`.

### Restored (Issue 3)
- Restored complete reproducibility package to 69+ files:
  - `configs/` — 4 YAML files (CERT, LANL, UNSW-NB15, CIC-IDS2017)
  - `src/baselines/` — all 10 competing methods
  - `experiments/` — 10 scripts mapped 1-to-1 to Tables 2–10
  - `data/download_datasets.sh`
  - `docs/` — dataset licensing, reproduction guide, changelog
  - `LICENSE` — MIT License
  - `results/` and `notebooks/` directories

### Fixed (Issue 4)
- Added `.gitignore` to exclude `__pycache__/`, `*.pyc`, `.pytest_cache/`
  and other build artifacts from committed content.
- Removed `.pytest_cache/` and `__pycache__/` from the release package.

### Pending (Issues 1 and 2)
- Code Availability Statement in the manuscript still reads "available upon
  reasonable request." This will be updated once the GitHub repository is
  pushed to a real public URL. The README clone URL placeholder
  (`[your-username]`) must be replaced with the actual GitHub username
  before the manuscript is updated.
