# DarkIntent-GNN

**Detecting Malicious Human Intent in Enterprise Networks with a Graph Neural Network**

Published in: *Computers, Materials and Continua (CMC)*, 2025

---

## Overview

DarkIntent-GNN is a heterogeneous graph neural network framework for detecting malicious human intent in enterprise networks before attacks materialize. It models user behavior, network topology, and temporal interaction patterns as heterogeneous graphs and applies hierarchical attention, temporal GCN-GRU modeling, and multi-task learning.

---

## Repository Structure

```
DarkIntent-GNN/
├── configs/
│   ├── cert.yaml                  # Hyperparameters for CERT r4.2
│   ├── lanl.yaml                  # Hyperparameters for LANL
│   ├── unsw_nb15.yaml             # Hyperparameters for UNSW-NB15
│   └── cic_ids2017.yaml           # Hyperparameters for CIC-IDS2017
├── models/
│   ├── darkintent_gnn.py          # Full model (Figure 3)
│   ├── heterogeneous_graph.py     # Graph construction (Section III-B, Eqs. 4–10)
│   ├── hierarchical_attention.py  # Hierarchical GAT (Section III-C, Eqs. 11–16)
│   ├── temporal_gcn.py            # Temporal GCN-GRU (Section III-D, Eqs. 17–21)
│   ├── threat_propagation.py      # Threat propagation (Section III-E, Eqs. 22–24)
│   └── multi_task_learning.py     # Multi-task loss (Section III-F, Eqs. 25–29)
├── src/
│   └── baselines/
│       ├── random_forest.py       # Baseline: Random Forest
│       ├── lstm.py                # Baseline: LSTM
│       ├── cnn_lstm.py            # Baseline: CNN-LSTM
│       ├── gcn.py                 # Baseline: GCN
│       ├── gat.py                 # Baseline: GAT
│       ├── fedgat.py              # Baseline: FedGAT [1]
│       ├── itdsts.py              # Baseline: ITDSTS [14]
│       ├── graphch.py             # Baseline: GraphCH [15]
│       ├── dd_gcn.py              # Baseline: DD-GCN
│       └── e_gracl.py             # Baseline: E-GRACL [8]
├── experiments/
│   ├── run_table2_overall_performance.py
│   ├── run_table3_threat_type.py
│   ├── run_table4_ablation.py
│   ├── run_table5_sensitivity.py
│   ├── run_table6_computational.py
│   ├── run_table7_class_imbalance.py
│   ├── run_table8_zero_day.py
│   ├── run_table9_early_warning.py
│   └── run_table10_sota_comparison.py
├── utils/
│   ├── metrics.py                 # Evaluation metrics (Section IV-A)
│   └── data_loader.py             # Dataset loading + synthetic data
├── data/
│   └── download_datasets.sh       # Dataset download instructions
├── docs/
│   ├── reproduction_guide.md      # Step-by-step reproduction instructions
│   ├── dataset_licensing.md       # Dataset license and citation information
│   └── changelog.md               # Version history and fix log
├── tests/
│   └── test_reproducibility.py   # Full pytest test suite
├── results/
│   └── tables/                    # JSON results from experiment scripts
├── notebooks/                     # Analysis notebooks
├── train.py                       # Training script
├── requirements.txt
├── LICENSE                        # MIT License
└── README.md
```

---

## Installation

```bash
git clone https://github.com/[your-username]/DarkIntent-GNN.git
cd DarkIntent-GNN
pip install -r requirements.txt
```

**Note:** Replace `[your-username]` with the actual GitHub username once the repository is publicly hosted.

---

## Reproducing Results

See `docs/reproduction_guide.md` for the complete step-by-step guide.
Quick start:

```bash
# Download datasets (follow printed instructions)
bash data/download_datasets.sh

# Run all table experiments
cd experiments
python run_table2_overall_performance.py
python run_table3_threat_type.py
python run_table4_ablation.py
python run_table5_sensitivity.py
python run_table6_computational.py
python run_table7_class_imbalance.py
python run_table8_zero_day.py
python run_table9_early_warning.py
python run_table10_sota_comparison.py

# Verify
cd ..
pytest tests/test_reproducibility.py -v
```

---

## Training

```bash
python train.py --dataset CERT --epochs 100 --lr 0.001 --seed 42
```

Supported datasets: `CERT`, `LANL`, `UNSW-NB15`, `CIC-IDS2017`

---

## Key Hyperparameters (Section IV-A, Table 5)

| Parameter | Value |
|---|---|
| Hidden dimension | 256 |
| Attention heads (K) | 8 |
| dk | 64 |
| Temporal window | 72 hours (3 snapshots) |
| Graph depth | 3 hops |
| Lambda (λ) initialization | 0.5 |
| Lambda (λ) converged | ~0.48 |
| Alpha_neural (α) | 0.7 (fixed — Equation 24) |
| Optimizer | Adam (β1=0.9, β2=0.999) |
| Learning rate | 0.001 (cosine annealing) |
| Batch size | 64 |
| Dropout | 0.3 |

---

## Lambda Initialization Note

The decay factor λ in the threat propagation model (Equation 22) is a learnable parameter stored as `logit(λ_init)` so that `sigmoid(logit(0.5)) = 0.5` exactly at initialization. It converges to approximately 0.48 across all datasets and random seeds, consistent with Table 5. Sensitivity across λ ∈ {0.1, 0.3, 0.5, 0.7, 0.9} is ±2.1% F1.

## Alpha_neural Note

The mixing coefficient α_neural in Equation 24 is a **fixed scalar hyperparameter set to 0.7**. It is stored as a non-learnable `register_buffer` and is not updated during training. This matches the paper's formulation of Equation 24.

---

## Datasets

| Dataset | Source |
|---|---|
| CERT r4.2 | https://kilthub.cmu.edu/articles/dataset/Insider_Threat_Test_Dataset/12841247 |
| LANL | https://csr.lanl.gov/data/cyber1/ |
| UNSW-NB15 | https://research.unsw.edu.au/projects/unsw-nb15-dataset |
| CIC-IDS2017 | https://www.unb.ca/cic/datasets/ids-2017.html |

See `docs/dataset_licensing.md` for citation and license details.

---

## License

MIT License. See `LICENSE` for details.
