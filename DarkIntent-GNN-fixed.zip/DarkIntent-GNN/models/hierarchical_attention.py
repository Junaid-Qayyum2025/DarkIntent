"""
Hierarchical Graph Attention Network — DarkIntent-GNN
Implements Section III-C: Node-Level, Edge-Level, and Subgraph-Level Attention.

Equations 11–16 from the paper.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List


class NodeLevelAttention(nn.Module):
    """
    Node-level self-attention for feature importance weighting.
    Implements Equations 11 and 12 from Section III-C.

    alpha_v^feat = softmax(Q_v K_v^T / sqrt(d_k))   (Eq. 11)
    x_v' = alpha_v^feat * W_V * x_v + x_v           (Eq. 12)
    """

    def __init__(self, hidden_dim: int = 256, dk: int = 64):
        super(NodeLevelAttention, self).__init__()
        self.dk = dk
        self.WQ = nn.Linear(hidden_dim, dk, bias=False)
        self.WK = nn.Linear(hidden_dim, dk, bias=False)
        self.WV = nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.norm = nn.LayerNorm(hidden_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Node features [N, hidden_dim]

        Returns:
            Attended node features [N, hidden_dim]
        """
        Q = self.WQ(x)  # [N, dk]
        K = self.WK(x)  # [N, dk]
        V = self.WV(x)  # [N, hidden_dim]

        # Eq. 11: scaled dot-product attention
        scale = self.dk ** 0.5
        attn = torch.softmax(torch.matmul(Q, K.T) / scale, dim=-1)  # [N, N]

        # Eq. 12: residual connection
        x_attended = torch.matmul(attn, V) + x
        return self.norm(x_attended)


class EdgeLevelAttention(nn.Module):
    """
    Multi-head edge-level attention for message passing.
    Implements Equations 13 and 14 from Section III-C.

    alpha_uv = softmax over neighbors (LeakyReLU of attention coefficients)  (Eq. 13)
    h_v = ELU(1/K * sum_k sum_{u in N(v)} alpha_uv^k * W_h^k * x_u)         (Eq. 14)
    """

    def __init__(self, hidden_dim: int = 256, num_heads: int = 8,
                 dropout: float = 0.3):
        super(EdgeLevelAttention, self).__init__()
        self.num_heads = num_heads
        self.head_dim = hidden_dim // num_heads
        self.hidden_dim = hidden_dim

        # Per-head weight matrices W_h^k
        self.Wh = nn.ModuleList([
            nn.Linear(hidden_dim, self.head_dim, bias=False)
            for _ in range(num_heads)
        ])

        # Attention vector a (shared across heads for simplicity)
        self.attn_vec = nn.Parameter(torch.Tensor(2 * self.head_dim + 64))
        nn.init.xavier_uniform_(self.attn_vec.unsqueeze(0))

        self.leaky_relu = nn.LeakyReLU(0.2)
        self.dropout = nn.Dropout(dropout)
        self.norm = nn.LayerNorm(hidden_dim)

        # Edge feature projection to match head_dim for concatenation
        self.edge_proj = nn.Linear(64, 64, bias=False)

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor,
                edge_feats: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x:           Node features [N, hidden_dim]
            edge_index:  [2, E] source-destination pairs
            edge_feats:  Edge embeddings [E, 64]

        Returns:
            Updated node embeddings [N, hidden_dim]
        """
        N = x.size(0)
        src, dst = edge_index[0], edge_index[1]
        head_outputs = []

        for k in range(self.num_heads):
            Wh_x = self.Wh[k](x)  # [N, head_dim]

            # Concatenate src, dst, and edge features for attention (Eq. 13)
            e_proj = self.edge_proj(edge_feats)  # [E, 64]
            concat = torch.cat([Wh_x[src], Wh_x[dst], e_proj], dim=-1)  # [E, 2*head_dim+64]
            attn_vec_k = self.attn_vec[:concat.size(-1)]
            e_scores = self.leaky_relu(concat @ attn_vec_k)  # [E]

            # Softmax over neighborhood
            attn_weights = torch.zeros(N, N, device=x.device)
            attn_weights[dst, src] = e_scores
            attn_weights = F.softmax(attn_weights, dim=-1)
            attn_weights = self.dropout(attn_weights)

            # Aggregate messages (Eq. 14)
            h_k = torch.matmul(attn_weights, Wh_x)  # [N, head_dim]
            head_outputs.append(h_k)

        # Average across heads and apply ELU (Eq. 14)
        h = torch.stack(head_outputs, dim=0).mean(dim=0)  # [N, head_dim]

        # Project back to hidden_dim
        h = h.repeat(1, self.num_heads)  # [N, hidden_dim] simple concat
        h = F.elu(h)
        return self.norm(h + x)


class SubgraphLevelAttention(nn.Module):
    """
    Subgraph-level attention over relation-specific subgraphs.
    Implements Equations 15 and 16 from Section III-C.

    beta_r = softmax over relations (q^T tanh(W_r h_v^r + b_r))  (Eq. 15)
    z_v = sum_r beta_r * h_v^r                                     (Eq. 16)
    """

    def __init__(self, hidden_dim: int = 256, num_relations: int = 8):
        super(SubgraphLevelAttention, self).__init__()
        self.num_relations = num_relations

        # Per-relation projection matrices W_r and biases b_r
        self.Wr = nn.ModuleList([
            nn.Linear(hidden_dim, hidden_dim) for _ in range(num_relations)
        ])

        # Global query vector q
        self.q = nn.Parameter(torch.Tensor(hidden_dim))
        nn.init.xavier_uniform_(self.q.unsqueeze(0))

        self.norm = nn.LayerNorm(hidden_dim)

    def forward(self, relation_embeddings: List[torch.Tensor]) -> torch.Tensor:
        """
        Args:
            relation_embeddings: List of R tensors each [N, hidden_dim],
                                 one per relation type

        Returns:
            Final node embeddings z_v [N, hidden_dim]
        """
        assert len(relation_embeddings) == self.num_relations

        # Eq. 15: compute attention scores for each relation
        scores = []
        transformed = []
        for r, h_r in enumerate(relation_embeddings):
            t = torch.tanh(self.Wr[r](h_r))      # [N, hidden_dim]
            score = (t @ self.q).mean()            # scalar per relation
            scores.append(score)
            transformed.append(t)

        beta = torch.softmax(torch.stack(scores), dim=0)  # [R]

        # Eq. 16: weighted sum over relation embeddings
        z = sum(beta[r] * transformed[r] for r in range(self.num_relations))
        return self.norm(z)


class HierarchicalGAT(nn.Module):
    """
    Full three-level hierarchical graph attention.
    Combines NodeLevelAttention, EdgeLevelAttention, SubgraphLevelAttention.
    """

    def __init__(self, hidden_dim: int = 256, dk: int = 64,
                 num_heads: int = 8, num_relations: int = 8,
                 dropout: float = 0.3):
        super(HierarchicalGAT, self).__init__()

        self.node_attn = NodeLevelAttention(hidden_dim, dk)
        self.edge_attn = EdgeLevelAttention(hidden_dim, num_heads, dropout)
        self.subgraph_attn = SubgraphLevelAttention(hidden_dim, num_relations)

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor,
                edge_feats: torch.Tensor,
                relation_masks: List[torch.Tensor]) -> torch.Tensor:
        """
        Args:
            x:               Node features [N, hidden_dim]
            edge_index:      [2, E]
            edge_feats:      Edge embeddings [E, 64]
            relation_masks:  List of R boolean masks over edges, one per relation

        Returns:
            Final node embeddings [N, hidden_dim]
        """
        # Level 1: node-level attention (Eqs. 11-12)
        x = self.node_attn(x)

        # Level 2: edge-level attention per relation (Eqs. 13-14)
        relation_embeddings = []
        for mask in relation_masks:
            ei_r = edge_index[:, mask]
            ef_r = edge_feats[mask]
            if ei_r.size(1) > 0:
                h_r = self.edge_attn(x, ei_r, ef_r)
            else:
                h_r = x
            relation_embeddings.append(h_r)

        # Level 3: subgraph-level attention (Eqs. 15-16)
        z = self.subgraph_attn(relation_embeddings)
        return z
