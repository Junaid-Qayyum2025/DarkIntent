"""
Temporal Graph Convolutional Network — DarkIntent-GNN
Implements Section III-D: Temporal GCN with GRU memory.

Equations 17–21 from the paper.
"""

import torch
import torch.nn as nn
from typing import List


class TemporalGCNLayer(nn.Module):
    """
    Single-step graph convolution.
    Implements Equation 17: H_t = sigma(D^{-1/2} A_t D^{-1/2} H_{t-1} W_t)
    """

    def __init__(self, hidden_dim: int = 256):
        super(TemporalGCNLayer, self).__init__()
        self.W = nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.norm = nn.LayerNorm(hidden_dim)

    def forward(self, H: torch.Tensor,
                adj_norm: torch.Tensor) -> torch.Tensor:
        """
        Args:
            H:        Node features at time t-1, [N, hidden_dim]
            adj_norm: Symmetric normalized adjacency D^{-1/2} A D^{-1/2}, [N, N]

        Returns:
            Updated node features H_t [N, hidden_dim]
        """
        # Eq. 17
        H_t = torch.relu(self.norm(torch.matmul(adj_norm, self.W(H))))
        return H_t


class TemporalGCNGRU(nn.Module):
    """
    Temporal GCN augmented with GRU-based memory.
    Implements Equations 17–21 from Section III-D.

    Eq. 17: H_t = sigma(D^{-1/2} A_t D^{-1/2} H_{t-1} W_t)
    Eq. 18: z_t = sigma(W_z [H_t, h_{t-1}])
    Eq. 19: r_t = sigma(W_r [H_t, h_{t-1}])
    Eq. 20: h_t_tilde = tanh(W_h [H_t, r_t * h_{t-1}])
    Eq. 21: h_t = (1 - z_t) * h_{t-1} + z_t * h_t_tilde
    """

    def __init__(self, hidden_dim: int = 256, num_layers: int = 2,
                 temporal_window: int = 3):
        """
        Args:
            hidden_dim:      Feature dimension
            num_layers:      Number of stacked GCN layers
            temporal_window: Number of graph snapshots to process
        """
        super(TemporalGCNGRU, self).__init__()

        self.hidden_dim = hidden_dim
        self.temporal_window = temporal_window

        # Stack of GCN layers
        self.gcn_layers = nn.ModuleList([
            TemporalGCNLayer(hidden_dim) for _ in range(num_layers)
        ])

        # GRU gate weights (Eqs. 18-21)
        # Input is concat of [H_t, h_{t-1}], so input_size = 2 * hidden_dim
        self.Wz = nn.Linear(2 * hidden_dim, hidden_dim)   # Eq. 18
        self.Wr = nn.Linear(2 * hidden_dim, hidden_dim)   # Eq. 19
        self.Wh = nn.Linear(2 * hidden_dim, hidden_dim)   # Eq. 20

        self.norm = nn.LayerNorm(hidden_dim)

    def gru_step(self, H_t: torch.Tensor,
                 h_prev: torch.Tensor) -> torch.Tensor:
        """
        One GRU update step (Equations 18-21).

        Args:
            H_t:    GCN output at time t [N, hidden_dim]
            h_prev: Hidden state from time t-1 [N, hidden_dim]

        Returns:
            New hidden state h_t [N, hidden_dim]
        """
        combined = torch.cat([H_t, h_prev], dim=-1)  # [N, 2*hidden_dim]

        z_t = torch.sigmoid(self.Wz(combined))        # Eq. 18: update gate
        r_t = torch.sigmoid(self.Wr(combined))        # Eq. 19: reset gate

        h_tilde_input = torch.cat([H_t, r_t * h_prev], dim=-1)
        h_tilde = torch.tanh(self.Wh(h_tilde_input))  # Eq. 20: candidate

        h_t = (1.0 - z_t) * h_prev + z_t * h_tilde   # Eq. 21
        return h_t

    def forward(self, snapshot_list: List[torch.Tensor],
                adj_list: List[torch.Tensor]) -> torch.Tensor:
        """
        Process a sequence of T graph snapshots.

        Args:
            snapshot_list: List of T node feature tensors [N, hidden_dim]
            adj_list:      List of T normalized adjacency matrices [N, N]

        Returns:
            Final hidden state h_T [N, hidden_dim]
        """
        assert len(snapshot_list) == len(adj_list)
        N = snapshot_list[0].size(0)

        h = torch.zeros(N, self.hidden_dim,
                        device=snapshot_list[0].device)

        for H_raw, adj in zip(snapshot_list, adj_list):
            # Apply GCN layers (Eq. 17)
            H_t = H_raw
            for gcn in self.gcn_layers:
                H_t = gcn(H_t, adj)

            # Apply GRU update (Eqs. 18-21)
            h = self.gru_step(H_t, h)

        return self.norm(h)
