"""
DarkIntent-GNN — Full Model
Combines all components: Heterogeneous Graph, Hierarchical GAT,
Temporal GCN-GRU, Threat Propagation, Multi-Task Learning.

Implements the complete pipeline from Figure 2 and Figure 3 of the paper.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Tuple, Dict

from models.heterogeneous_graph import NodeFeatureEncoder, EdgeFeatureEncoder, HeterogeneousGraphBuilder
from models.hierarchical_attention import HierarchicalGAT
from models.temporal_gcn import TemporalGCNGRU
from models.threat_propagation import ThreatPropagationModel
from models.multi_task_learning import MultiTaskLoss


class DarkIntentGNN(nn.Module):
    """
    Full DarkIntent-GNN model.

    Architecture (Figure 3):
    Raw logs → Node/Edge encoding → Hierarchical GAT →
    Temporal GCN-GRU → Threat Propagation → Multi-Task Heads
    """

    def __init__(self,
                 behav_dim: int = 32,
                 context_dim: int = 16,
                 stat_dim: int = 16,
                 hidden_dim: int = 256,
                 dk: int = 64,
                 num_heads: int = 8,
                 num_relations: int = 8,
                 num_gcn_layers: int = 2,
                 temporal_window: int = 3,
                 num_threat_classes: int = 5,
                 lambda_init: float = 0.5,
                 num_prop_steps: int = 3,
                 dropout: float = 0.3):
        super(DarkIntentGNN, self).__init__()

        # --- Encoding ---
        self.node_encoder = NodeFeatureEncoder(
            behav_dim, context_dim, stat_dim, hidden_dim)
        self.edge_encoder = EdgeFeatureEncoder(5, dk)

        # --- Hierarchical Graph Attention (Section III-C) ---
        self.hgat = HierarchicalGAT(
            hidden_dim, dk, num_heads, num_relations, dropout)

        # --- Temporal GCN-GRU (Section III-D) ---
        self.temporal_gcn = TemporalGCNGRU(
            hidden_dim, num_gcn_layers, temporal_window)

        # --- Threat Propagation (Section III-E) ---
        self.threat_prop = ThreatPropagationModel(
            hidden_dim, num_prop_steps, lambda_init)

        # --- Multi-Task Heads (Section III-F) ---
        # Intent classification head
        self.intent_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 2, 1),
            nn.Sigmoid()
        )

        # Anomaly scoring head
        self.anomaly_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 2, 1),
            nn.Sigmoid()
        )

        # Threat categorization head
        self.category_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 2, num_threat_classes)
        )

        # --- Loss ---
        self.loss_fn = MultiTaskLoss(
            num_classes=num_threat_classes,
            focal_alpha=0.25,
            focal_gamma=2.0,
            lambda_smooth=0.01,
            lambda_reg=1e-4
        )

        self.hidden_dim = hidden_dim

    def encode_nodes(self, x_behav: torch.Tensor, x_context: torch.Tensor,
                     x_stat: torch.Tensor,
                     node_types: torch.Tensor) -> torch.Tensor:
        return self.node_encoder(x_behav, x_context, x_stat, node_types)

    def encode_edges(self, edge_feats: torch.Tensor,
                     edge_types: torch.Tensor,
                     t_current: float) -> torch.Tensor:
        return self.edge_encoder(edge_feats, edge_types, t_current)

    def forward(self,
                x_behav: torch.Tensor,
                x_context: torch.Tensor,
                x_stat: torch.Tensor,
                node_types: torch.Tensor,
                edge_index: torch.Tensor,
                edge_feats: torch.Tensor,
                edge_types: torch.Tensor,
                relation_masks: List[torch.Tensor],
                snapshot_list: List[torch.Tensor],
                adj_list: List[torch.Tensor],
                adj_prop: torch.Tensor,
                t_current: float
                ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Full forward pass.

        Returns:
            intent_probs:    Intent probabilities [N]
            anomaly_scores:  Anomaly scores [N]
            category_logits: Threat category logits [N, C]
        """
        # Step 1: Encode nodes and edges
        x = self.encode_nodes(x_behav, x_context, x_stat, node_types)
        e = self.encode_edges(edge_feats, edge_types, t_current)

        # Step 2: Hierarchical Graph Attention
        z = self.hgat(x, edge_index, e, relation_masks)

        # Step 3: Temporal GCN-GRU
        # Use z as the initial snapshot feature if no snapshots provided
        if len(snapshot_list) == 0:
            snapshot_list = [z]
            adj_list = [adj_prop]
        h = self.temporal_gcn(snapshot_list, adj_list)

        # Step 4: Multi-task heads
        intent_probs = self.intent_head(h).squeeze(-1)    # [N]
        anomaly_scores = self.anomaly_head(h).squeeze(-1)  # [N]
        category_logits = self.category_head(h)            # [N, C]

        # Step 5: Threat Propagation (Eqs. 22-24)
        intent_probs = self.threat_prop(h, adj_prop, intent_probs)
        intent_probs = intent_probs.clamp(0.0, 1.0)

        return intent_probs, anomaly_scores, category_logits

    def compute_loss(self,
                     intent_probs: torch.Tensor,
                     intent_targets: torch.Tensor,
                     anomaly_scores: torch.Tensor,
                     anomaly_targets: torch.Tensor,
                     category_logits: torch.Tensor,
                     category_targets: torch.Tensor
                     ) -> Tuple[torch.Tensor, Dict]:
        return self.loss_fn(
            intent_probs, intent_targets,
            anomaly_scores, anomaly_targets,
            category_logits, category_targets,
            list(self.parameters())
        )
