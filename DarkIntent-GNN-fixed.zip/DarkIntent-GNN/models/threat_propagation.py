"""
Threat Propagation Model — DarkIntent-GNN
Implements Equations 22, 23, 24 from Section III-E of the paper.

Equation 22: dP_v(t)/dt = -lambda * P_v(t) + sum_{u in N(v)} w_uv * P_u(t)
Equation 23: p^{k+1} = (1 - lambda) * p^k + lambda * A * p^k
Equation 24: p_final = alpha_neural * p_GNN + (1 - alpha_neural) * p_prop
"""

import torch
import torch.nn as nn


class ThreatPropagationModel(nn.Module):
    """
    Discrete-time threat propagation model with learnable decay factor lambda.

    Lambda is stored as its logit so that sigmoid(logit(x)) = x exactly,
    recovering lambda_init = 0.5 at initialization (fixes the log/sigmoid bug).
    Sensitivity experiments in the paper (Table 5) confirm lambda converges
    to approximately 0.48 across all datasets and random seeds.

    alpha_neural is a fixed scalar hyperparameter (alpha_neural = 0.7) as
    defined in Equation 24. It controls the relative contribution of the
    GNN-predicted scores versus the propagation-estimated scores and is
    not updated during training.
    """

    def __init__(self, hidden_dim: int = 256, num_prop_steps: int = 3,
                 lambda_init: float = 0.5):
        super(ThreatPropagationModel, self).__init__()

        self.hidden_dim = hidden_dim
        self.num_prop_steps = num_prop_steps

        # CORRECT initialization: store logit of lambda_init so that
        # sigmoid(self.log_lambda) == lambda_init at step 0.
        # sigmoid(log(0.5)) = 0.333  <-- WRONG (old bug)
        # sigmoid(logit(0.5)) = 0.500 <-- CORRECT (this fix)
        self.log_lambda = nn.Parameter(torch.logit(torch.tensor(lambda_init)))

        # alpha_neural: fixed mixing coefficient (Equation 24).
        # Defined as a fixed scalar = 0.7 per the paper's formulation.
        # Registered as a buffer (not a learnable parameter) so it is
        # saved/loaded with the model state dict but not updated by the optimizer.
        self.register_buffer('alpha_neural', torch.tensor(0.7))

        # Optional projection layer for node threat scores
        self.score_proj = nn.Linear(hidden_dim, 1)

    def get_lambda(self) -> torch.Tensor:
        """Returns lambda in (0, 1) via sigmoid."""
        return torch.sigmoid(self.log_lambda)

    def propagate(self, p: torch.Tensor,
                  adj: torch.Tensor) -> torch.Tensor:
        """
        Iterative discrete-time propagation (Equation 23).

        Args:
            p:   Initial threat score vector, shape [N]
            adj: Row-normalized adjacency matrix, shape [N, N]

        Returns:
            Propagated threat scores, shape [N]
        """
        lam = self.get_lambda()
        for _ in range(self.num_prop_steps):
            p = (1.0 - lam) * p + lam * torch.matmul(adj, p)
        return p

    def forward(self, node_embeddings: torch.Tensor,
                adj: torch.Tensor,
                p_gnn: torch.Tensor) -> torch.Tensor:
        """
        Combines GNN-predicted scores with propagation scores (Equation 24).

        p_final = alpha_neural * p_GNN + (1 - alpha_neural) * p_prop

        Args:
            node_embeddings: Node feature matrix, shape [N, hidden_dim]
            adj:             Row-normalized adjacency matrix, shape [N, N]
            p_gnn:           GNN intent scores, shape [N]

        Returns:
            Final threat scores p_final, shape [N]
        """
        # Run propagation starting from GNN scores
        p_prop = self.propagate(p_gnn.clone(), adj)

        # Mix GNN scores and propagated scores (Equation 24)
        # alpha_neural = 0.7 (fixed, per paper definition)
        p_final = self.alpha_neural * p_gnn + (1.0 - self.alpha_neural) * p_prop

        return p_final
