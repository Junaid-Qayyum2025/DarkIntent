"""
Heterogeneous Graph Construction — DarkIntent-GNN
Implements Section III-B: Node Feature Engineering and Edge Feature Engineering.

Equations 4–10 from the paper.
"""

import torch
import torch.nn as nn
import numpy as np
from typing import Dict, List, Tuple


class NodeFeatureEncoder(nn.Module):
    """
    Encodes raw node features into a unified representation.
    Implements Equations 5, 6, 7, 8 from Section III-B.

    Feature vector: x_v = x_v^behav ⊕ x_v^context ⊕ x_v^stat  (Eq. 8)
    """

    def __init__(self, behav_dim: int = 32, context_dim: int = 16,
                 stat_dim: int = 16, hidden_dim: int = 256):
        super(NodeFeatureEncoder, self).__init__()

        input_dim = behav_dim + context_dim + stat_dim

        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU()
        )

        # Type-specific embeddings for 5 node types:
        # Vuser, Vresource, Vdevice, Vapplication, Vlocation
        self.type_embedding = nn.Embedding(5, hidden_dim)

    def forward(self, x_behav: torch.Tensor, x_context: torch.Tensor,
                x_stat: torch.Tensor,
                node_types: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x_behav:    Behavioral features [N, behav_dim]   (Eq. 5)
            x_context:  Contextual features [N, context_dim] (Eq. 6)
            x_stat:     Statistical features [N, stat_dim]   (Eq. 7)
            node_types: Integer type labels [N]

        Returns:
            Node embeddings [N, hidden_dim]
        """
        x = torch.cat([x_behav, x_context, x_stat], dim=-1)  # Eq. 8
        h = self.encoder(x)
        type_emb = self.type_embedding(node_types)
        return h + type_emb


class EdgeFeatureEncoder(nn.Module):
    """
    Encodes edge features including recency-weighted importance.
    Implements Equations 9 and 10 from Section III-B.

    e_uv = (w_freq, w_recency, w_importance, t_first, t_last)  (Eq. 9)
    w_recency(t) = exp(-(t_current - t) / tau)                  (Eq. 10)
    """

    def __init__(self, edge_feat_dim: int = 5, hidden_dim: int = 64,
                 tau: float = 86400.0):
        """
        Args:
            tau: Time decay constant in seconds (default = 1 day)
        """
        super(EdgeFeatureEncoder, self).__init__()
        self.tau = tau

        # 8 edge type embeddings matching Equation 4:
        # Eaccess, Ecomm, Eown, Etrust, Ehier, Esim, Etemp, Epriv
        self.edge_type_embedding = nn.Embedding(8, hidden_dim)

        self.encoder = nn.Sequential(
            nn.Linear(edge_feat_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim)
        )

    def compute_recency_weight(self, t_current: float,
                               t_last: torch.Tensor) -> torch.Tensor:
        """Equation 10: w_recency(t) = exp(-(t_current - t) / tau)"""
        return torch.exp(-(t_current - t_last) / self.tau)

    def forward(self, edge_feats: torch.Tensor,
                edge_types: torch.Tensor,
                t_current: float) -> torch.Tensor:
        """
        Args:
            edge_feats:  Raw edge features [E, edge_feat_dim]
            edge_types:  Integer type labels [E]
            t_current:   Current timestamp (scalar)

        Returns:
            Edge embeddings [E, hidden_dim]
        """
        # Recompute recency weight using last-interaction timestamp (col index 4)
        t_last = edge_feats[:, 4]
        w_recency = self.compute_recency_weight(t_current, t_last)
        edge_feats = edge_feats.clone()
        edge_feats[:, 1] = w_recency  # overwrite recency column (Eq. 10)

        h_edge = self.encoder(edge_feats)
        type_emb = self.edge_type_embedding(edge_types)
        return h_edge + type_emb


class HeterogeneousGraphBuilder:
    """
    Builds the heterogeneous graph G = (V, E_edge, X, T).
    Implements Equations 2 and 4 from Section III-B.

    V = U ∪ R ∪ D   (Eq. 2)
    E_edge = Eaccess ∪ Ecomm ∪ Eown ∪ Etrust ∪ Ehier ∪ Esim ∪ Etemp ∪ Epriv  (Eq. 4)
    """

    NODE_TYPES = {
        'user': 0,
        'resource': 1,
        'device': 2,
        'application': 3,
        'location': 4
    }

    EDGE_TYPES = {
        'access': 0,
        'communication': 1,
        'ownership': 2,
        'trust': 3,
        'hierarchy': 4,
        'similarity': 5,
        'temporal': 6,
        'privilege': 7
    }

    def __init__(self, num_nodes: int):
        self.num_nodes = num_nodes

    def build_adjacency(self, edge_index: torch.Tensor,
                        num_nodes: int) -> torch.Tensor:
        """
        Builds row-normalized adjacency matrix for propagation.

        Args:
            edge_index: [2, E] tensor of (src, dst) pairs
            num_nodes:  Total number of nodes N

        Returns:
            Row-normalized adjacency matrix [N, N]
        """
        adj = torch.zeros(num_nodes, num_nodes)
        src, dst = edge_index[0], edge_index[1]
        adj[dst, src] = 1.0

        # Row normalization
        row_sum = adj.sum(dim=1, keepdim=True).clamp(min=1e-8)
        adj = adj / row_sum
        return adj
