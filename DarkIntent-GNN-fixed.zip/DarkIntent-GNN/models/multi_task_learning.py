"""
Multi-Task Learning Framework — DarkIntent-GNN
Implements Section III-F: Intent Classification, Anomaly Scoring, Threat Categorization.

Equations 25–29 from the paper.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple


class FocalLoss(nn.Module):
    """
    Focal loss for intent classification under class imbalance.
    Implements Equation 25: L_focal = -1/N sum_i alpha_i (1-y_i)^gamma y_i log(y_i)
    """

    def __init__(self, alpha: float = 0.25, gamma: float = 2.0):
        super(FocalLoss, self).__init__()
        self.alpha = alpha
        self.gamma = gamma

    def forward(self, preds: torch.Tensor,
                targets: torch.Tensor) -> torch.Tensor:
        """
        Args:
            preds:   Predicted probabilities [N]
            targets: Binary ground truth [N]

        Returns:
            Scalar focal loss
        """
        preds = preds.clamp(1e-7, 1.0 - 1e-7)
        bce = -targets * torch.log(preds) - (1 - targets) * torch.log(1 - preds)
        pt = targets * preds + (1 - targets) * (1 - preds)
        focal_weight = self.alpha * (1.0 - pt) ** self.gamma
        return (focal_weight * bce).mean()  # Eq. 25


class AnomalyScoreLoss(nn.Module):
    """
    Anomaly scoring loss with smoothness regularization.
    Implements Equation 26:
    L_anomaly = 1/N sum_i (s_i - s_i*)^2 + lambda_smooth ||grad s||^2
    """

    def __init__(self, lambda_smooth: float = 0.01):
        super(AnomalyScoreLoss, self).__init__()
        self.lambda_smooth = lambda_smooth

    def forward(self, scores: torch.Tensor,
                targets: torch.Tensor) -> torch.Tensor:
        """
        Args:
            scores:  Predicted anomaly scores [N]
            targets: Ground truth anomaly scores [N]

        Returns:
            Scalar anomaly loss
        """
        reconstruction = F.mse_loss(scores, targets)

        # Smoothness: approximate gradient norm via differences
        if scores.size(0) > 1:
            grad_s = scores[1:] - scores[:-1]
            smoothness = self.lambda_smooth * (grad_s ** 2).mean()
        else:
            smoothness = torch.tensor(0.0, device=scores.device)

        return reconstruction + smoothness  # Eq. 26


class ThreatCategorizationLoss(nn.Module):
    """
    Multi-class cross-entropy for threat categorization.
    Implements Equation 27: L_category = -1/N sum_i sum_c y_ic log(y_ic_hat)
    """

    def __init__(self, num_classes: int = 5):
        super(ThreatCategorizationLoss, self).__init__()
        self.num_classes = num_classes
        self.ce = nn.CrossEntropyLoss()

    def forward(self, logits: torch.Tensor,
                targets: torch.Tensor) -> torch.Tensor:
        """
        Args:
            logits:  Class logits [N, C]
            targets: Integer class labels [N]

        Returns:
            Scalar cross-entropy loss
        """
        return self.ce(logits, targets)  # Eq. 27


class MultiTaskLoss(nn.Module):
    """
    Combined multi-task loss with meta-learned task weights.
    Implements Equations 28 and 29 from Section III-F.

    L_total = lambda_1 * L_focal + lambda_2 * L_anomaly +
              lambda_3 * L_category + lambda_4 * L_reg    (Eq. 28)

    lambda_i^{t+1} = lambda_i^t - eta * dL_val/d_lambda_i  (Eq. 29)
    """

    def __init__(self, num_classes: int = 5,
                 focal_alpha: float = 0.25, focal_gamma: float = 2.0,
                 lambda_smooth: float = 0.01,
                 lambda_reg: float = 1e-4,
                 meta_lr: float = 0.01):
        super(MultiTaskLoss, self).__init__()

        self.focal_loss = FocalLoss(focal_alpha, focal_gamma)
        self.anomaly_loss = AnomalyScoreLoss(lambda_smooth)
        self.category_loss = ThreatCategorizationLoss(num_classes)

        self.lambda_reg = lambda_reg
        self.meta_lr = meta_lr

        # Learnable task weights (Eq. 28): lambda_1 to lambda_4
        # Stored as log to keep them positive
        self.log_lambdas = nn.Parameter(torch.zeros(4))

    def get_task_weights(self) -> torch.Tensor:
        """Returns positive task weights via softplus."""
        return F.softplus(self.log_lambdas)

    def forward(self, intent_preds: torch.Tensor,
                intent_targets: torch.Tensor,
                anomaly_scores: torch.Tensor,
                anomaly_targets: torch.Tensor,
                category_logits: torch.Tensor,
                category_targets: torch.Tensor,
                model_params: list) -> Tuple[torch.Tensor, dict]:
        """
        Args:
            intent_preds:      Predicted intent probabilities [N]
            intent_targets:    Binary intent labels [N]
            anomaly_scores:    Predicted anomaly scores [N]
            anomaly_targets:   Target anomaly scores [N]
            category_logits:   Threat category logits [N, C]
            category_targets:  Threat category labels [N]
            model_params:      Model parameters for L2 regularization

        Returns:
            total_loss: Scalar
            loss_dict:  Individual loss components for logging
        """
        lam = self.get_task_weights()  # [4]

        L_focal = self.focal_loss(intent_preds, intent_targets)
        L_anomaly = self.anomaly_loss(anomaly_scores, anomaly_targets)
        L_category = self.category_loss(category_logits, category_targets)

        # L2 regularization
        L_reg = sum(p.pow(2).sum() for p in model_params)

        # Eq. 28: weighted total loss
        L_total = (lam[0] * L_focal +
                   lam[1] * L_anomaly +
                   lam[2] * L_category +
                   lam[3] * self.lambda_reg * L_reg)

        loss_dict = {
            'L_focal': L_focal.item(),
            'L_anomaly': L_anomaly.item(),
            'L_category': L_category.item(),
            'L_reg': L_reg.item(),
            'lambda_1': lam[0].item(),
            'lambda_2': lam[1].item(),
            'lambda_3': lam[2].item(),
            'lambda_4': lam[3].item()
        }

        return L_total, loss_dict
