"""
Experiment: Table 6 — Computational Efficiency Comparison
Measures training time, inference latency, memory, parameter count.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import torch, time, json
from utils.data_loader import load_dataset
from models.darkintent_gnn import DarkIntentGNN

def count_params(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad) / 1e6

def main():
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    train, val, test = load_dataset('CERT', '../data', 64)
    model = DarkIntentGNN(
        behav_dim=32, context_dim=16, stat_dim=16, hidden_dim=256,
        dk=64, num_heads=8, num_relations=8, num_gcn_layers=2,
        temporal_window=3, num_threat_classes=5, lambda_init=0.5,
        num_prop_steps=3, dropout=0.3).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

    # Measure training time for 1 epoch
    start = time.time()
    model.train()
    optimizer.zero_grad()
    intent_probs, anomaly_scores, category_logits = model(
        train['x_behav'].to(device), train['x_context'].to(device),
        train['x_stat'].to(device), train['node_types'].to(device),
        train['edge_index'].to(device), train['edge_feats'].to(device),
        train['edge_types'].to(device),
        [m.to(device) for m in train['relation_masks']],
        [s.to(device) for s in train['snapshot_list']],
        [a.to(device) for a in train['adj_list']],
        train['adj_prop'].to(device), train['t_current'])
    loss, _ = model.compute_loss(
        intent_probs, train['intent_labels'].float().to(device),
        anomaly_scores, train['anomaly_scores'].float().to(device),
        category_logits, train['category_labels'].long().to(device))
    loss.backward()
    optimizer.step()
    train_time = (time.time() - start) / 60

    # Inference latency
    model.eval()
    start = time.time()
    with torch.no_grad():
        for _ in range(100):
            model(train['x_behav'].to(device), train['x_context'].to(device),
                  train['x_stat'].to(device), train['node_types'].to(device),
                  train['edge_index'].to(device), train['edge_feats'].to(device),
                  train['edge_types'].to(device),
                  [m.to(device) for m in train['relation_masks']],
                  [s.to(device) for s in train['snapshot_list']],
                  [a.to(device) for a in train['adj_list']],
                  train['adj_prop'].to(device), train['t_current'])
    infer_ms = (time.time() - start) * 1000 / 100

    params_m = count_params(model)
    results = {
        'DarkIntent-GNN': {
            'train_time_min': round(train_time, 1),
            'inference_ms': round(infer_ms, 1),
            'params_M': round(params_m, 1)
        }
    }
    print(f"Train time: {train_time:.1f} min | Inference: {infer_ms:.1f} ms | Params: {params_m:.1f}M")
    os.makedirs('../results/tables', exist_ok=True)
    with open('../results/tables/table6_computational.json', 'w') as f:
        json.dump(results, f, indent=2)
    print("Saved results/tables/table6_computational.json")

if __name__ == '__main__':
    main()
