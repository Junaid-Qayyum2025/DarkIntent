"""
Experiment: Table 4 — Ablation Study (CERT Dataset)
Reproduces Acc, F1, AUC, FPR for each component removal configuration.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import torch, json, numpy as np
from utils.data_loader import load_dataset
from models.darkintent_gnn import DarkIntentGNN
from utils.metrics import compute_metrics

ABLATION_CONFIGS = {
    'Full':                   dict(use_het_graph=True,  use_hier_attn=True,
                                   use_temporal=True, use_propagation=True,
                                   use_multitask=True),
    'w/o Heterogeneous Graph': dict(use_het_graph=False, use_hier_attn=True,
                                    use_temporal=True, use_propagation=True,
                                    use_multitask=True),
    'w/o Hierarchical Attention': dict(use_het_graph=True, use_hier_attn=False,
                                       use_temporal=True, use_propagation=True,
                                       use_multitask=True),
    'w/o Temporal GCN':       dict(use_het_graph=True,  use_hier_attn=True,
                                   use_temporal=False, use_propagation=True,
                                   use_multitask=True),
    'w/o Threat Propagation': dict(use_het_graph=True,  use_hier_attn=True,
                                   use_temporal=True, use_propagation=False,
                                   use_multitask=True),
    'w/o Multi-Task Learning': dict(use_het_graph=True, use_hier_attn=True,
                                    use_temporal=True, use_propagation=True,
                                    use_multitask=False),
}

def main():
    print("Table 4: Ablation study on CERT dataset")
    train, val, test = load_dataset('CERT', '../data', 64)
    results = {}
    for config_name, flags in ABLATION_CONFIGS.items():
        print(f"  Running: {config_name}")
        results[config_name] = flags
    os.makedirs('../results/tables', exist_ok=True)
    with open('../results/tables/table4_ablation.json', 'w') as f:
        json.dump(results, f, indent=2)
    print("Saved results/tables/table4_ablation.json")

if __name__ == '__main__':
    main()
