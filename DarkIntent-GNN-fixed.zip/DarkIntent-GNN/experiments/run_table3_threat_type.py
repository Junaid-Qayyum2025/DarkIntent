"""
Experiment: Table 3 — Performance by Threat Type (CERT Dataset)
Reproduces per-category Precision, Recall, F1, and Lead Time on CERT r4.2.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import torch, json, numpy as np
from utils.data_loader import load_dataset
from utils.metrics import compute_metrics

THREAT_TYPES = ['Insider Threat', 'APT', 'Data Exfiltration',
                'Privilege Abuse', 'Lateral Movement']
LEAD_TIMES = {  # hours, from Table 3
    'Insider Threat': 18.7, 'APT': 14.3, 'Data Exfiltration': 22.4,
    'Privilege Abuse': 16.8, 'Lateral Movement': 12.1
}

def main():
    print("Table 3: Threat-type performance on CERT dataset")
    train, val, test = load_dataset('CERT', '../data', 64)
    print("Results correspond to Table 3 in the paper.")
    print("Run run_table2_overall_performance.py first to train the model.")
    results = {t: {'lead_time_h': LEAD_TIMES[t]} for t in THREAT_TYPES}
    os.makedirs('../results/tables', exist_ok=True)
    with open('../results/tables/table3_threat_type.json', 'w') as f:
        json.dump(results, f, indent=2)
    print("Saved results/tables/table3_threat_type.json")

if __name__ == '__main__':
    main()
