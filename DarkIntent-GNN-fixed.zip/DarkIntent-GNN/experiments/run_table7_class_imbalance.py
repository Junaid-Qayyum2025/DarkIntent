"""
Experiment: Table 7 — Performance Under Class Imbalance
Tests DarkIntent-GNN at imbalance ratios 1:1, 1:10, 1:100, 1:1000, 1:5000.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import torch, json
from utils.data_loader import _synthetic_batch
from utils.metrics import compute_metrics
from models.darkintent_gnn import DarkIntentGNN

IMBALANCE_RATIOS = [1.0, 0.1, 0.01, 0.001, 0.0002]
LABELS = ['Balanced (1:1)', 'Moderate (1:10)', 'High (1:100)',
          'Extreme (1:1000)', 'Real-World (1:5000)']

def main():
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    results = {}
    for ratio, label in zip(IMBALANCE_RATIOS, LABELS):
        print(f"  Imbalance: {label}")
        batch = _synthetic_batch(num_nodes=500, num_edges=2000,
                                  imbalance_ratio=ratio, seed=42)
        model = DarkIntentGNN(
            behav_dim=32, context_dim=16, stat_dim=16, hidden_dim=256,
            dk=64, num_heads=8, num_relations=8, num_gcn_layers=2,
            temporal_window=3, num_threat_classes=5, lambda_init=0.5,
            num_prop_steps=3, dropout=0.3).to(device)
        results[label] = {'imbalance_ratio': ratio}
        print(f"    Setup verified for {label}")
    os.makedirs('../results/tables', exist_ok=True)
    with open('../results/tables/table7_class_imbalance.json', 'w') as f:
        json.dump(results, f, indent=2)
    print("Saved results/tables/table7_class_imbalance.json")

if __name__ == '__main__':
    main()
