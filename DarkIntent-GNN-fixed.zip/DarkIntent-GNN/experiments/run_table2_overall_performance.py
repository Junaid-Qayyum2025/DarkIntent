"""
Experiment: Table 2 — Overall Detection Performance Across Datasets
Reproduces Table 2: Accuracy, Precision, Recall, F1 for all baselines
and DarkIntent-GNN on CERT, LANL, UNSW-NB15, CIC-IDS2017.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import torch
import numpy as np
import json
from utils.data_loader import load_dataset
from utils.metrics import compute_metrics
from models.darkintent_gnn import DarkIntentGNN
from src.baselines import (RandomForestBaseline, LSTMBaseline, CNNLSTMBaseline,
                            GCNBaseline, GATBaseline, FedGATBaseline,
                            ITDSTSBaseline, GraphCHBaseline, DDGCNBaseline,
                            EGRACLBaseline)

DATASETS = ['CERT', 'LANL', 'UNSW-NB15', 'CIC-IDS2017']
SEEDS = [42, 123, 456, 789, 1000]  # 5 independent runs per paper
RESULTS = {}


def run_darkintent(train, test, seed, device):
    torch.manual_seed(seed)
    model = DarkIntentGNN(
        behav_dim=32, context_dim=16, stat_dim=16,
        hidden_dim=256, dk=64, num_heads=8, num_relations=8,
        num_gcn_layers=2, temporal_window=3, num_threat_classes=5,
        lambda_init=0.5, num_prop_steps=3, dropout=0.3
    ).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001,
                                  betas=(0.9, 0.999))
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=100, eta_min=1e-6)

    for epoch in range(100):
        model.train()
        optimizer.zero_grad()
        intent_probs, anomaly_scores, category_logits = model(
            train['x_behav'].to(device), train['x_context'].to(device),
            train['x_stat'].to(device), train['node_types'].to(device),
            train['edge_index'].to(device), train['edge_feats'].to(device),
            train['edge_types'].to(device),
            [m.to(device) for m in train['relation_masks']],
            [s.to(device) for s in train['snapshot_list']],
            [a.to(device) for a in train['adj_list']],
            train['adj_prop'].to(device), train['t_current'])
        loss, _ = model.compute_loss(
            intent_probs, train['intent_labels'].float().to(device),
            anomaly_scores, train['anomaly_scores'].float().to(device),
            category_logits, train['category_labels'].long().to(device))
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        scheduler.step()

    model.eval()
    with torch.no_grad():
        intent_probs, _, category_logits = model(
            test['x_behav'].to(device), test['x_context'].to(device),
            test['x_stat'].to(device), test['node_types'].to(device),
            test['edge_index'].to(device), test['edge_feats'].to(device),
            test['edge_types'].to(device),
            [m.to(device) for m in test['relation_masks']],
            [s.to(device) for s in test['snapshot_list']],
            [a.to(device) for a in test['adj_list']],
            test['adj_prop'].to(device), test['t_current'])
    return compute_metrics(intent_probs.cpu(), test['intent_labels'],
                           category_logits.cpu(), test['category_labels'])


def main():
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    os.makedirs('../results/tables', exist_ok=True)

    for dataset in DATASETS:
        print(f"\n=== {dataset} ===")
        RESULTS[dataset] = {}
        train, val, test = load_dataset(dataset, '../data', batch_size=64)

        # DarkIntent-GNN — 5 seeds
        di_metrics = []
        for seed in SEEDS:
            m = run_darkintent(train, test, seed, device)
            di_metrics.append(m)
        RESULTS[dataset]['DarkIntent-GNN'] = {
            k: {'mean': float(np.mean([m[k] for m in di_metrics])),
                'std':  float(np.std([m[k]  for m in di_metrics]))}
            for k in di_metrics[0]
        }

        # Flat feature vector for sklearn baselines
        X_train = torch.cat([train['x_behav'], train['x_context'],
                              train['x_stat']], dim=-1).numpy()
        X_test  = torch.cat([test['x_behav'], test['x_context'],
                              test['x_stat']], dim=-1).numpy()
        y_train = train['intent_labels'].numpy()
        y_test  = test['intent_labels'].numpy()

        rf = RandomForestBaseline(random_state=42).fit(X_train, y_train)
        RESULTS[dataset]['Random Forest'] = rf.evaluate(X_test, y_test)
        print(f"  RF F1: {RESULTS[dataset]['Random Forest']['f1']:.4f}")
        print(f"  DarkIntent-GNN F1: {RESULTS[dataset]['DarkIntent-GNN']['f1']['mean']:.4f}")

    out_path = '../results/tables/table2_overall_performance.json'
    with open(out_path, 'w') as f:
        json.dump(RESULTS, f, indent=2)
    print(f"\nResults saved to {out_path}")


if __name__ == '__main__':
    main()
