"""
Training Script — DarkIntent-GNN

Trains the model on CERT / LANL / UNSW-NB15 / CIC-IDS2017 datasets.
Implementation details from Section IV-A of the paper:
  - Hidden dim: 256, dk: 64, K: 8 attention heads
  - Temporal window: 72 hours, 3-hop neighborhood
  - Optimizer: Adam with beta1=0.9, beta2=0.999
  - Learning rate: 0.001 with cosine annealing
  - Batch size: 64 users
  - Dropout: 0.3
"""

import torch
import torch.optim as optim
from torch.optim.lr_scheduler import CosineAnnealingLR
import numpy as np
import random
import argparse
import os
from typing import Dict

from models.darkintent_gnn import DarkIntentGNN
from utils.metrics import compute_metrics
from utils.data_loader import load_dataset, create_graph_snapshots


def set_seed(seed: int = 42):
    """Fix all random seeds for reproducibility."""
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def train_epoch(model: DarkIntentGNN,
                optimizer: optim.Optimizer,
                batch: Dict,
                device: torch.device) -> Dict:
    model.train()
    optimizer.zero_grad()

    # Move tensors to device
    x_behav = batch['x_behav'].to(device)
    x_context = batch['x_context'].to(device)
    x_stat = batch['x_stat'].to(device)
    node_types = batch['node_types'].to(device)
    edge_index = batch['edge_index'].to(device)
    edge_feats = batch['edge_feats'].to(device)
    edge_types = batch['edge_types'].to(device)
    relation_masks = [m.to(device) for m in batch['relation_masks']]
    snapshot_list = [s.to(device) for s in batch['snapshot_list']]
    adj_list = [a.to(device) for a in batch['adj_list']]
    adj_prop = batch['adj_prop'].to(device)
    t_current = batch['t_current']

    intent_targets = batch['intent_labels'].float().to(device)
    anomaly_targets = batch['anomaly_scores'].float().to(device)
    category_targets = batch['category_labels'].long().to(device)

    # Forward pass
    intent_probs, anomaly_scores, category_logits = model(
        x_behav, x_context, x_stat, node_types,
        edge_index, edge_feats, edge_types, relation_masks,
        snapshot_list, adj_list, adj_prop, t_current
    )

    # Loss (Eq. 28)
    loss, loss_dict = model.compute_loss(
        intent_probs, intent_targets,
        anomaly_scores, anomaly_targets,
        category_logits, category_targets
    )

    loss.backward()
    torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
    optimizer.step()

    return loss_dict


def evaluate(model: DarkIntentGNN,
             batch: Dict,
             device: torch.device) -> Dict:
    model.eval()
    with torch.no_grad():
        x_behav = batch['x_behav'].to(device)
        x_context = batch['x_context'].to(device)
        x_stat = batch['x_stat'].to(device)
        node_types = batch['node_types'].to(device)
        edge_index = batch['edge_index'].to(device)
        edge_feats = batch['edge_feats'].to(device)
        edge_types = batch['edge_types'].to(device)
        relation_masks = [m.to(device) for m in batch['relation_masks']]
        snapshot_list = [s.to(device) for s in batch['snapshot_list']]
        adj_list = [a.to(device) for a in batch['adj_list']]
        adj_prop = batch['adj_prop'].to(device)
        t_current = batch['t_current']
        intent_targets = batch['intent_labels'].to(device)

        intent_probs, anomaly_scores, category_logits = model(
            x_behav, x_context, x_stat, node_types,
            edge_index, edge_feats, edge_types, relation_masks,
            snapshot_list, adj_list, adj_prop, t_current
        )

        metrics = compute_metrics(
            intent_probs.cpu(), intent_targets.cpu(),
            category_logits.cpu(),
            batch['category_labels']
        )

    return metrics


def main(args):
    set_seed(args.seed)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Device: {device}")
    print(f"Seed: {args.seed}")
    print(f"Dataset: {args.dataset}")

    # Model initialization (Section IV-A hyperparameters)
    model = DarkIntentGNN(
        behav_dim=32,
        context_dim=16,
        stat_dim=16,
        hidden_dim=256,
        dk=64,
        num_heads=8,
        num_relations=8,
        num_gcn_layers=2,
        temporal_window=3,
        num_threat_classes=5,
        lambda_init=0.5,     # Initialized at 0.5, converges to ~0.48
        num_prop_steps=3,
        dropout=0.3
    ).to(device)

    # Optimizer: Adam with beta1=0.9, beta2=0.999 (Section IV-A)
    optimizer = optim.Adam(model.parameters(),
                           lr=args.lr,
                           betas=(0.9, 0.999))

    # Learning rate scheduler: cosine annealing (Section IV-A)
    scheduler = CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=1e-6)

    # Load dataset
    print(f"Loading {args.dataset} dataset...")
    train_batch, val_batch, test_batch = load_dataset(
        args.dataset, args.data_dir, args.batch_size)

    best_f1 = 0.0
    os.makedirs(args.save_dir, exist_ok=True)

    for epoch in range(1, args.epochs + 1):
        loss_dict = train_epoch(model, optimizer, train_batch, device)
        scheduler.step()

        if epoch % args.eval_every == 0:
            val_metrics = evaluate(model, val_batch, device)
            print(f"Epoch {epoch:03d} | "
                  f"Loss: {loss_dict['L_focal']:.4f} | "
                  f"Val Acc: {val_metrics['accuracy']:.4f} | "
                  f"Val F1: {val_metrics['f1']:.4f} | "
                  f"Val FPR: {val_metrics['fpr']:.4f} | "
                  f"Lambda: {model.threat_prop.get_lambda().item():.4f}")

            if val_metrics['f1'] > best_f1:
                best_f1 = val_metrics['f1']
                torch.save(model.state_dict(),
                           os.path.join(args.save_dir, 'best_model.pt'))

    # Final test evaluation
    model.load_state_dict(
        torch.load(os.path.join(args.save_dir, 'best_model.pt'),
                   map_location=device))
    test_metrics = evaluate(model, test_batch, device)
    print("\n--- Test Results ---")
    for k, v in test_metrics.items():
        print(f"  {k}: {v:.4f}")

    print(f"\nFinal lambda value: "
          f"{model.threat_prop.get_lambda().item():.4f}")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Train DarkIntent-GNN')
    parser.add_argument('--dataset', type=str, default='CERT',
                        choices=['CERT', 'LANL', 'UNSW-NB15', 'CIC-IDS2017'])
    parser.add_argument('--data_dir', type=str, default='./data')
    parser.add_argument('--save_dir', type=str, default='./checkpoints')
    parser.add_argument('--epochs', type=int, default=100)
    parser.add_argument('--lr', type=float, default=0.001)
    parser.add_argument('--batch_size', type=int, default=64)
    parser.add_argument('--eval_every', type=int, default=5)
    parser.add_argument('--seed', type=int, default=42)
    args = parser.parse_args()
    main(args)
