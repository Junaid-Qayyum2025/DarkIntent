"""
Evaluation Metrics — DarkIntent-GNN
Implements all metrics from Section IV-A of the paper:
Accuracy, Precision, Recall, F1-Score, AUC-ROC, False Positive Rate.
"""

import torch
import numpy as np
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                              f1_score, roc_auc_score, confusion_matrix)
from typing import Dict


def compute_metrics(intent_probs: torch.Tensor,
                    intent_targets: torch.Tensor,
                    category_logits: torch.Tensor = None,
                    category_targets: torch.Tensor = None,
                    threshold: float = 0.5) -> Dict[str, float]:
    """
    Computes all evaluation metrics from Section IV-A.

    Accuracy  = (TP + TN) / (TP + TN + FP + FN)
    Precision = TP / (TP + FP)
    Recall    = TP / (TP + FN)
    F1-Score  = 2 * Precision * Recall / (Precision + Recall)
    AUC-ROC   = Area under ROC curve
    FPR       = FP / (FP + TN)

    Args:
        intent_probs:    Predicted probabilities [N]
        intent_targets:  Binary ground truth [N]
        category_logits: Optional category logits [N, C]
        category_targets: Optional category labels [N]
        threshold:        Decision threshold

    Returns:
        Dictionary of metric names to values
    """
    probs = intent_probs.numpy()
    targets = intent_targets.numpy().astype(int)
    preds = (probs >= threshold).astype(int)

    acc = accuracy_score(targets, preds)
    prec = precision_score(targets, preds, zero_division=0)
    rec = recall_score(targets, preds, zero_division=0)
    f1 = f1_score(targets, preds, zero_division=0)

    try:
        auc = roc_auc_score(targets, probs)
    except ValueError:
        auc = 0.0

    tn, fp, fn, tp = confusion_matrix(targets, preds, labels=[0, 1]).ravel()
    fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0

    metrics = {
        'accuracy': float(acc),
        'precision': float(prec),
        'recall': float(rec),
        'f1': float(f1),
        'auc': float(auc),
        'fpr': float(fpr)
    }

    # Category accuracy if provided
    if category_logits is not None and category_targets is not None:
        cat_preds = category_logits.argmax(dim=-1).numpy()
        cat_targets = category_targets.numpy().astype(int)
        metrics['category_accuracy'] = float(
            accuracy_score(cat_targets, cat_preds))

    return metrics
