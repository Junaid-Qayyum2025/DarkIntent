"""
Data Loader — DarkIntent-GNN

Loads CERT, LANL, UNSW-NB15, or CIC-IDS2017 datasets.
Falls back to synthetic data for reproducibility testing when
raw datasets are not available locally.

Dataset sources (from Section IV-A of the paper):
  CERT r4.2:   https://kilthub.cmu.edu/articles/dataset/Insider_Threat_Test_Dataset/12841247
  LANL:        https://csr.lanl.gov/data/cyber1/
  UNSW-NB15:   https://research.unsw.edu.au/projects/unsw-nb15-dataset
  CIC-IDS2017: https://www.unb.ca/cic/datasets/ids-2017.html
"""

import torch
import numpy as np
import os
from typing import Tuple, Dict


NUM_RELATIONS = 8
BEHAV_DIM = 32
CONTEXT_DIM = 16
STAT_DIM = 16
EDGE_FEAT_DIM = 5
EDGE_EMBED_DIM = 64


def _synthetic_batch(num_nodes: int = 200,
                     num_edges: int = 800,
                     num_snapshots: int = 3,
                     num_threat_classes: int = 5,
                     imbalance_ratio: float = 0.01,
                     seed: int = 42) -> Dict:
    """
    Generates a synthetic batch for reproducibility testing.
    Class imbalance matches real-world setting (malicious < 1%).
    """
    rng = np.random.default_rng(seed)

    x_behav = torch.tensor(
        rng.standard_normal((num_nodes, BEHAV_DIM)), dtype=torch.float32)
    x_context = torch.tensor(
        rng.standard_normal((num_nodes, CONTEXT_DIM)), dtype=torch.float32)
    x_stat = torch.tensor(
        rng.standard_normal((num_nodes, STAT_DIM)), dtype=torch.float32)
    node_types = torch.randint(0, 5, (num_nodes,))

    src = torch.randint(0, num_nodes, (num_edges,))
    dst = torch.randint(0, num_nodes, (num_edges,))
    edge_index = torch.stack([src, dst], dim=0)
    edge_feats = torch.tensor(
        rng.standard_normal((num_edges, EDGE_FEAT_DIM)), dtype=torch.float32)
    edge_feats[:, 4] = torch.tensor(
        rng.uniform(0, 86400, (num_edges,)), dtype=torch.float32)
    edge_types = torch.randint(0, NUM_RELATIONS, (num_edges,))

    relation_masks = [
        (edge_types == r) for r in range(NUM_RELATIONS)
    ]

    # Build adjacency for propagation
    adj = torch.zeros(num_nodes, num_nodes)
    adj[dst, src] = 1.0
    row_sum = adj.sum(dim=1, keepdim=True).clamp(min=1e-8)
    adj_prop = adj / row_sum

    # Snapshots
    snapshot_list = [
        torch.tensor(rng.standard_normal((num_nodes, 256)),
                     dtype=torch.float32)
        for _ in range(num_snapshots)
    ]
    adj_list = [adj_prop] * num_snapshots

    # Labels with class imbalance
    num_malicious = max(1, int(num_nodes * imbalance_ratio))
    intent_labels = torch.zeros(num_nodes)
    malicious_idx = rng.choice(num_nodes, num_malicious, replace=False)
    intent_labels[malicious_idx] = 1.0

    anomaly_scores = intent_labels + torch.tensor(
        rng.normal(0, 0.1, (num_nodes,)), dtype=torch.float32).clamp(0, 1)
    category_labels = torch.randint(0, num_threat_classes, (num_nodes,))
    category_labels[malicious_idx] = torch.randint(
        0, num_threat_classes, (num_malicious,))

    return {
        'x_behav': x_behav,
        'x_context': x_context,
        'x_stat': x_stat,
        'node_types': node_types,
        'edge_index': edge_index,
        'edge_feats': edge_feats,
        'edge_types': edge_types,
        'relation_masks': relation_masks,
        'snapshot_list': snapshot_list,
        'adj_list': adj_list,
        'adj_prop': adj_prop,
        't_current': 86400.0,
        'intent_labels': intent_labels,
        'anomaly_scores': anomaly_scores,
        'category_labels': category_labels
    }


def load_dataset(dataset_name: str, data_dir: str,
                 batch_size: int = 64) -> Tuple[Dict, Dict, Dict]:
    """
    Loads a dataset. Uses synthetic data if raw files not found.

    Returns:
        (train_batch, val_batch, test_batch)
    """
    raw_path = os.path.join(data_dir, dataset_name)

    if not os.path.exists(raw_path):
        print(f"[INFO] {dataset_name} raw data not found at {raw_path}.")
        print("[INFO] Using synthetic data for reproducibility testing.")
        train = _synthetic_batch(num_nodes=500, num_edges=2000, seed=0)
        val = _synthetic_batch(num_nodes=200, num_edges=800, seed=1)
        test = _synthetic_batch(num_nodes=200, num_edges=800, seed=2)
        return train, val, test

    # Real dataset loading would go here depending on format.
    # Placeholder — replace with actual CSV/log parsers per dataset.
    raise NotImplementedError(
        f"Real data loader for {dataset_name} not yet implemented. "
        "Please preprocess the raw files and place them under "
        f"{raw_path}/train.pt, {raw_path}/val.pt, {raw_path}/test.pt"
    )


def create_graph_snapshots(events: list, window_hours: int = 72,
                           num_snapshots: int = 3):
    """
    Splits event logs into temporal snapshots of window_hours / num_snapshots.
    Used for Temporal GCN input construction.
    """
    step = window_hours / num_snapshots
    snapshots = []
    for i in range(num_snapshots):
        t_start = i * step
        t_end = (i + 1) * step
        snap = [e for e in events
                if t_start <= e.get('hour', 0) < t_end]
        snapshots.append(snap)
    return snapshots
