#!/usr/bin/env bash
# download_datasets.sh — DarkIntent-GNN
# Downloads and verifies the four benchmark datasets used in the paper.
# Run from the repository root: bash data/download_datasets.sh

set -euo pipefail

DATA_DIR="$(dirname "$0")"

echo "========================================"
echo " DarkIntent-GNN Dataset Download Guide"
echo "========================================"
echo ""
echo "The four datasets used in this paper must be downloaded manually"
echo "from their official sources due to access agreements and size."
echo "Place each dataset under ./data/<DATASET_NAME>/ as described below."
echo ""

echo "------------------------------------------------------------"
echo "1. CERT Insider Threat Dataset r4.2"
echo "   Source : https://kilthub.cmu.edu/articles/dataset/Insider_Threat_Test_Dataset/12841247"
echo "   License: Requires registration with CMU CERT"
echo "   Place at: ./data/CERT/"
echo "   Expected files: r4.2/LDAP.csv, r4.2/logon.csv, r4.2/device.csv,"
echo "                   r4.2/email.csv, r4.2/file.csv, r4.2/http.csv,"
echo "                   r4.2/answers/insiders.csv"
echo ""

echo "------------------------------------------------------------"
echo "2. LANL Cybersecurity Dataset"
echo "   Source : https://csr.lanl.gov/data/cyber1/"
echo "   License: Publicly available; see LANL data terms"
echo "   Place at: ./data/LANL/"
echo "   Expected files: auth.txt.gz, proc.txt.gz, flows.txt.gz,"
echo "                   dns.txt.gz, redteam.txt.gz"
echo ""

echo "------------------------------------------------------------"
echo "3. UNSW-NB15 Dataset"
echo "   Source : https://research.unsw.edu.au/projects/unsw-nb15-dataset"
echo "   License: Publicly available; see UNSW terms"
echo "   Place at: ./data/UNSW-NB15/"
echo "   Expected files: UNSW_NB15_training-set.csv, UNSW_NB15_testing-set.csv"
echo ""

echo "------------------------------------------------------------"
echo "4. CIC-IDS2017 Dataset"
echo "   Source : https://www.unb.ca/cic/datasets/ids-2017.html"
echo "   License: Publicly available; see UNB CIC terms"
echo "   Place at: ./data/CIC-IDS2017/"
echo "   Expected files: Monday-WorkingHours.pcap_ISCX.csv,"
echo "                   Tuesday-WorkingHours.pcap_ISCX.csv,"
echo "                   Wednesday-workingHours.pcap_ISCX.csv,"
echo "                   Thursday-WorkingHours-Morning-WebAttacks.pcap_ISCX.csv,"
echo "                   Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv"
echo ""

echo "========================================"
echo " Synthetic Data Fallback"
echo "========================================"
echo ""
echo "If raw datasets are not available, the data_loader.py module"
echo "automatically falls back to synthetic data with matching class"
echo "imbalance ratios for reproducibility testing of model architecture."
echo "Run: python train.py --dataset CERT  (synthetic data used automatically)"
echo ""

echo "All dataset directories initialized under ./data/"
mkdir -p "$DATA_DIR/CERT" "$DATA_DIR/LANL" "$DATA_DIR/UNSW-NB15" "$DATA_DIR/CIC-IDS2017"
echo "Done. Place downloaded files in the directories above."
