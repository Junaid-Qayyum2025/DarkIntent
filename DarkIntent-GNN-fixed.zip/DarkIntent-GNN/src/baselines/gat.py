"""
Baseline: GAT (Table 2, Table 10)
Velickovic et al. (2018). Graph attention networks. ICLR 2018.
Single-level attention; no temporal or subgraph modeling.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class GATLayer(nn.Module):
    def __init__(self, in_dim: int, out_dim: int, num_heads: int = 8,
                 dropout: float = 0.3):
        super().__init__()
        self.num_heads = num_heads
        self.head_dim = out_dim // num_heads
        self.W = nn.Linear(in_dim, out_dim, bias=False)
        self.a = nn.Parameter(torch.Tensor(2 * self.head_dim))
        nn.init.xavier_uniform_(self.a.unsqueeze(0))
        self.leaky_relu = nn.LeakyReLU(0.2)
        self.dropout = nn.Dropout(dropout)
        self.norm = nn.LayerNorm(out_dim)

    def forward(self, x: torch.Tensor, adj: torch.Tensor) -> torch.Tensor:
        N = x.size(0)
        Wx = self.W(x).view(N, self.num_heads, self.head_dim)
        src = Wx.unsqueeze(1).expand(-1, N, -1, -1)
        dst = Wx.unsqueeze(0).expand(N, -1, -1, -1)
        e = self.leaky_relu(
            (torch.cat([src, dst], dim=-1) * self.a).sum(-1))
        e = e.mean(dim=-1)
        mask = (adj == 0)
        e = e.masked_fill(mask, float('-inf'))
        alpha = F.softmax(e, dim=-1)
        alpha = self.dropout(alpha)
        h = torch.matmul(alpha, x)
        return F.elu(self.norm(h))


class GATModel(nn.Module):
    def __init__(self, input_dim: int = 64, hidden_dim: int = 256,
                 num_heads: int = 8, num_layers: int = 2, dropout: float = 0.3):
        super().__init__()
        self.layers = nn.ModuleList()
        self.layers.append(GATLayer(input_dim, hidden_dim, num_heads, dropout))
        for _ in range(num_layers - 1):
            self.layers.append(GATLayer(hidden_dim, hidden_dim, num_heads, dropout))
        self.classifier = nn.Sequential(nn.Linear(hidden_dim, 1), nn.Sigmoid())

    def forward(self, x: torch.Tensor, adj: torch.Tensor) -> torch.Tensor:
        for layer in self.layers:
            x = layer(x, adj)
        return self.classifier(x).squeeze(-1)


class GATBaseline:
    """GAT baseline — single-level attention, homogeneous graph."""

    def __init__(self, input_dim: int = 64, hidden_dim: int = 256,
                 num_heads: int = 8, dropout: float = 0.3,
                 lr: float = 0.001, epochs: int = 100):
        self.model = GATModel(input_dim, hidden_dim, num_heads, dropout=dropout)
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=lr,
                                          betas=(0.9, 0.999))
        self.criterion = nn.BCELoss()
        self.epochs = epochs
        self.name = 'GAT'

    def fit(self, x: torch.Tensor, adj: torch.Tensor,
            y: torch.Tensor) -> 'GATBaseline':
        self.model.train()
        for _ in range(self.epochs):
            self.optimizer.zero_grad()
            preds = self.model(x, adj)
            loss = self.criterion(preds, y.float())
            loss.backward()
            self.optimizer.step()
        return self

    def predict(self, x: torch.Tensor, adj: torch.Tensor,
                threshold: float = 0.5) -> torch.Tensor:
        self.model.eval()
        with torch.no_grad():
            return (self.model(x, adj) >= threshold).float()

    def predict_proba(self, x: torch.Tensor, adj: torch.Tensor) -> torch.Tensor:
        self.model.eval()
        with torch.no_grad():
            return self.model(x, adj)
