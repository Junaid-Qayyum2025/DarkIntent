"""
Baseline: DD-GCN (Table 2, Table 10)
Dynamic-directed GCN for anomaly detection on directed graphs.
Uses directed adjacency without heterogeneous relation types.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class DDGCNModel(nn.Module):
    """Directed dynamic GCN — directed adjacency, no relation heterogeneity."""

    def __init__(self, input_dim: int = 64, hidden_dim: int = 256,
                 num_layers: int = 3, dropout: float = 0.3):
        super().__init__()
        self.layers = nn.ModuleList()
        self.layers.append(nn.Linear(input_dim, hidden_dim))
        for _ in range(num_layers - 1):
            self.layers.append(nn.Linear(hidden_dim, hidden_dim))
        self.norms = nn.ModuleList([nn.LayerNorm(hidden_dim)
                                    for _ in range(num_layers)])
        self.dropout = nn.Dropout(dropout)
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, 1), nn.Sigmoid())

    def forward(self, x: torch.Tensor, adj: torch.Tensor) -> torch.Tensor:
        for layer, norm in zip(self.layers, self.norms):
            x = self.dropout(F.relu(norm(torch.matmul(adj, layer(x)))))
        return self.classifier(x).squeeze(-1)


class DDGCNBaseline:
    """DD-GCN baseline."""

    def __init__(self, input_dim: int = 64, hidden_dim: int = 256,
                 num_layers: int = 3, dropout: float = 0.3,
                 lr: float = 0.001, epochs: int = 100):
        self.model = DDGCNModel(input_dim, hidden_dim, num_layers, dropout)
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=lr,
                                          betas=(0.9, 0.999))
        self.criterion = nn.BCELoss()
        self.epochs = epochs
        self.name = 'DD-GCN'

    def fit(self, x: torch.Tensor, adj: torch.Tensor,
            y: torch.Tensor) -> 'DDGCNBaseline':
        self.model.train()
        for _ in range(self.epochs):
            self.optimizer.zero_grad()
            preds = self.model(x, adj)
            loss = self.criterion(preds, y.float())
            loss.backward()
            self.optimizer.step()
        return self

    def predict(self, x: torch.Tensor, adj: torch.Tensor,
                threshold: float = 0.5) -> torch.Tensor:
        self.model.eval()
        with torch.no_grad():
            return (self.model(x, adj) >= threshold).float()

    def predict_proba(self, x: torch.Tensor, adj: torch.Tensor) -> torch.Tensor:
        self.model.eval()
        with torch.no_grad():
            return self.model(x, adj)
