"""
Baseline: FedGAT [1] (Table 2, Table 10)
Jianping et al. (2024). Federated learning for network attack detection using
attention-based graph neural networks. Scientific Reports, 14, 19088.
DOI: 10.1038/s41598-024-70032-2
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from .gat import GATModel


class FedGATBaseline:
    """
    Federated GAT baseline — simulates the federated averaging setting of [1].
    In single-node evaluation, this reduces to a standard GAT with
    federated-style weight averaging across synthetic client splits.
    Uses the same adjacency structure as DarkIntent-GNN without
    heterogeneous relation types or temporal modeling.
    """

    def __init__(self, input_dim: int = 64, hidden_dim: int = 256,
                 num_heads: int = 8, num_clients: int = 5,
                 dropout: float = 0.3, lr: float = 0.001, epochs: int = 100):
        self.num_clients = num_clients
        self.global_model = GATModel(input_dim, hidden_dim, num_heads,
                                     dropout=dropout)
        self.client_models = [
            GATModel(input_dim, hidden_dim, num_heads, dropout=dropout)
            for _ in range(num_clients)
        ]
        self.lr = lr
        self.epochs = epochs
        self.name = 'FedGAT [1]'

    def _fedavg(self):
        """Federated averaging: average client weights into global model."""
        global_dict = self.global_model.state_dict()
        for key in global_dict:
            global_dict[key] = torch.stack(
                [c.state_dict()[key].float() for c in self.client_models]
            ).mean(dim=0)
        self.global_model.load_state_dict(global_dict)
        for client in self.client_models:
            client.load_state_dict(global_dict)

    def fit(self, x: torch.Tensor, adj: torch.Tensor,
            y: torch.Tensor) -> 'FedGATBaseline':
        # Simulate federated rounds with client data splits
        N = x.size(0)
        split_size = N // self.num_clients
        for _ in range(self.epochs):
            for i, client in enumerate(self.client_models):
                start = i * split_size
                end = start + split_size if i < self.num_clients - 1 else N
                x_c = x[start:end]
                adj_c = adj[start:end, start:end]
                y_c = y[start:end]
                opt = torch.optim.Adam(client.parameters(), lr=self.lr,
                                       betas=(0.9, 0.999))
                client.train()
                opt.zero_grad()
                preds = client(x_c, adj_c)
                loss = F.binary_cross_entropy(preds, y_c.float())
                loss.backward()
                opt.step()
            self._fedavg()
        return self

    def predict(self, x: torch.Tensor, adj: torch.Tensor,
                threshold: float = 0.5) -> torch.Tensor:
        self.global_model.eval()
        with torch.no_grad():
            return (self.global_model(x, adj) >= threshold).float()

    def predict_proba(self, x: torch.Tensor, adj: torch.Tensor) -> torch.Tensor:
        self.global_model.eval()
        with torch.no_grad():
            return self.global_model(x, adj)
