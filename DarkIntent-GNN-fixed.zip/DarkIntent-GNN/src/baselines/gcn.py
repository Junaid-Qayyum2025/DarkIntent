"""
Baseline: GCN (Table 2, Table 10)
Kipf & Welling (2017). Semi-supervised classification with graph convolutional networks.
Homogeneous graph; no temporal or intent modeling.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class GCNLayer(nn.Module):
    def __init__(self, in_dim: int, out_dim: int):
        super().__init__()
        self.W = nn.Linear(in_dim, out_dim, bias=False)
        self.norm = nn.LayerNorm(out_dim)

    def forward(self, x: torch.Tensor, adj: torch.Tensor) -> torch.Tensor:
        return F.relu(self.norm(torch.matmul(adj, self.W(x))))


class GCNModel(nn.Module):
    def __init__(self, input_dim: int = 64, hidden_dim: int = 256,
                 num_layers: int = 2, dropout: float = 0.3):
        super().__init__()
        self.layers = nn.ModuleList()
        self.layers.append(GCNLayer(input_dim, hidden_dim))
        for _ in range(num_layers - 1):
            self.layers.append(GCNLayer(hidden_dim, hidden_dim))
        self.dropout = nn.Dropout(dropout)
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, 1),
            nn.Sigmoid()
        )

    def forward(self, x: torch.Tensor, adj: torch.Tensor) -> torch.Tensor:
        for layer in self.layers:
            x = self.dropout(layer(x, adj))
        return self.classifier(x).squeeze(-1)


class GCNBaseline:
    """Standard GCN baseline — homogeneous graph, no temporal modeling."""

    def __init__(self, input_dim: int = 64, hidden_dim: int = 256,
                 num_layers: int = 2, dropout: float = 0.3,
                 lr: float = 0.001, epochs: int = 100):
        self.model = GCNModel(input_dim, hidden_dim, num_layers, dropout)
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=lr,
                                          betas=(0.9, 0.999))
        self.criterion = nn.BCELoss()
        self.epochs = epochs
        self.name = 'GCN'

    def fit(self, x: torch.Tensor, adj: torch.Tensor,
            y: torch.Tensor) -> 'GCNBaseline':
        self.model.train()
        for _ in range(self.epochs):
            self.optimizer.zero_grad()
            preds = self.model(x, adj)
            loss = self.criterion(preds, y.float())
            loss.backward()
            self.optimizer.step()
        return self

    def predict(self, x: torch.Tensor, adj: torch.Tensor,
                threshold: float = 0.5) -> torch.Tensor:
        self.model.eval()
        with torch.no_grad():
            return (self.model(x, adj) >= threshold).float()

    def predict_proba(self, x: torch.Tensor, adj: torch.Tensor) -> torch.Tensor:
        self.model.eval()
        with torch.no_grad():
            return self.model(x, adj)
