"""
Baseline: CNN-LSTM (Table 2, Table 10)
Hybrid convolutional + LSTM on tabular feature sequences.
"""
import torch
import torch.nn as nn


class CNNLSTMModel(nn.Module):
    def __init__(self, input_dim: int = 64, hidden_dim: int = 256,
                 num_filters: int = 64, kernel_size: int = 3,
                 dropout: float = 0.3):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv1d(input_dim, num_filters, kernel_size, padding=kernel_size // 2),
            nn.ReLU(),
            nn.Dropout(dropout)
        )
        self.lstm = nn.LSTM(num_filters, hidden_dim, batch_first=True)
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 2, 1),
            nn.Sigmoid()
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, T, D] -> conv expects [B, D, T]
        x = self.conv(x.permute(0, 2, 1)).permute(0, 2, 1)
        out, _ = self.lstm(x)
        return self.classifier(out[:, -1, :]).squeeze(-1)


class CNNLSTMBaseline:
    """CNN-LSTM baseline — no graph structure."""

    def __init__(self, input_dim: int = 64, hidden_dim: int = 256,
                 dropout: float = 0.3, lr: float = 0.001, epochs: int = 100):
        self.model = CNNLSTMModel(input_dim, hidden_dim, dropout=dropout)
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=lr,
                                          betas=(0.9, 0.999))
        self.criterion = nn.BCELoss()
        self.epochs = epochs
        self.name = 'CNN-LSTM'

    def fit(self, X_train: torch.Tensor, y_train: torch.Tensor) -> 'CNNLSTMBaseline':
        self.model.train()
        for _ in range(self.epochs):
            self.optimizer.zero_grad()
            preds = self.model(X_train)
            loss = self.criterion(preds, y_train.float())
            loss.backward()
            self.optimizer.step()
        return self

    def predict(self, X: torch.Tensor, threshold: float = 0.5) -> torch.Tensor:
        self.model.eval()
        with torch.no_grad():
            return (self.model(X) >= threshold).float()

    def predict_proba(self, X: torch.Tensor) -> torch.Tensor:
        self.model.eval()
        with torch.no_grad():
            return self.model(X)
