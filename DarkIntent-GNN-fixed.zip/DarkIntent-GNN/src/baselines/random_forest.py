"""
Baseline: Random Forest (Table 2, Table 10)
Reference: Breiman, L. (2001). Random forests. Machine Learning, 45(1), 5–32.
"""
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from typing import Dict


class RandomForestBaseline:
    """
    Random Forest baseline operating on tabular feature representations.
    Receives the same raw input features as DarkIntent-GNN (behavioral,
    contextual, and statistical feature vectors concatenated), without
    graph-structural augmentation.
    """

    def __init__(self, n_estimators: int = 100, max_depth: int = None,
                 random_state: int = 42):
        self.model = RandomForestClassifier(
            n_estimators=n_estimators,
            max_depth=max_depth,
            class_weight='balanced',
            random_state=random_state,
            n_jobs=-1
        )
        self.name = 'Random Forest'

    def fit(self, X_train: np.ndarray, y_train: np.ndarray) -> 'RandomForestBaseline':
        self.model.fit(X_train, y_train)
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        return self.model.predict(X)

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        return self.model.predict_proba(X)[:, 1]

    def evaluate(self, X_test: np.ndarray, y_test: np.ndarray) -> Dict[str, float]:
        preds = self.predict(X_test)
        probs = self.predict_proba(X_test)
        from sklearn.metrics import roc_auc_score, confusion_matrix
        tn, fp, fn, tp = confusion_matrix(y_test, preds, labels=[0, 1]).ravel()
        return {
            'accuracy':  float(accuracy_score(y_test, preds)),
            'precision': float(precision_score(y_test, preds, zero_division=0)),
            'recall':    float(recall_score(y_test, preds, zero_division=0)),
            'f1':        float(f1_score(y_test, preds, zero_division=0)),
            'auc':       float(roc_auc_score(y_test, probs)),
            'fpr':       float(fp / (fp + tn)) if (fp + tn) > 0 else 0.0
        }
