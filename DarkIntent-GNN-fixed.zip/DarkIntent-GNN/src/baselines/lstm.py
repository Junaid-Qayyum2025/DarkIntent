"""
Baseline: LSTM (Table 2, Table 10)
Standard LSTM on tabular feature sequences without graph structure.
"""
import torch
import torch.nn as nn
from typing import Dict


class LSTMModel(nn.Module):
    def __init__(self, input_dim: int = 64, hidden_dim: int = 256,
                 num_layers: int = 2, dropout: float = 0.3):
        super().__init__()
        self.lstm = nn.LSTM(input_dim, hidden_dim, num_layers,
                            batch_first=True, dropout=dropout)
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 2, 1),
            nn.Sigmoid()
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out, _ = self.lstm(x)
        return self.classifier(out[:, -1, :]).squeeze(-1)


class LSTMBaseline:
    """LSTM baseline — flat feature sequences, no graph structure."""

    def __init__(self, input_dim: int = 64, hidden_dim: int = 256,
                 num_layers: int = 2, dropout: float = 0.3,
                 lr: float = 0.001, epochs: int = 100):
        self.model = LSTMModel(input_dim, hidden_dim, num_layers, dropout)
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=lr,
                                          betas=(0.9, 0.999))
        self.criterion = nn.BCELoss()
        self.epochs = epochs
        self.name = 'LSTM'

    def fit(self, X_train: torch.Tensor, y_train: torch.Tensor) -> 'LSTMBaseline':
        self.model.train()
        for _ in range(self.epochs):
            self.optimizer.zero_grad()
            preds = self.model(X_train)
            loss = self.criterion(preds, y_train.float())
            loss.backward()
            self.optimizer.step()
        return self

    def predict(self, X: torch.Tensor, threshold: float = 0.5) -> torch.Tensor:
        self.model.eval()
        with torch.no_grad():
            probs = self.model(X)
        return (probs >= threshold).float()

    def predict_proba(self, X: torch.Tensor) -> torch.Tensor:
        self.model.eval()
        with torch.no_grad():
            return self.model(X)
