"""
Baseline: GraphCH [15] (Table 2, Table 10)
Roy & Chen (2024). GraphCH: A deep framework for cyber-human aspects in
insider threat detection. IEEE Trans. Dependable and Secure Computing,
21(5), 4495–4509. DOI: 10.1109/TDSC.2024.3353929

Heterogeneous graph with psychological features integrated.
No temporal propagation modeling.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class GraphCHModel(nn.Module):
    """
    Cyber-human heterogeneous GNN. Integrates behavioral and psychological
    node features. Uses relation-specific projection without hierarchical
    subgraph attention or temporal memory.
    """
    def __init__(self, input_dim: int = 64, psych_dim: int = 16,
                 hidden_dim: int = 256, num_relations: int = 4,
                 dropout: float = 0.3):
        super().__init__()
        self.node_proj = nn.Linear(input_dim + psych_dim, hidden_dim)
        self.relation_layers = nn.ModuleList([
            nn.Linear(hidden_dim, hidden_dim) for _ in range(num_relations)
        ])
        self.dropout = nn.Dropout(dropout)
        self.norm = nn.LayerNorm(hidden_dim)
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2), nn.ReLU(),
            nn.Dropout(dropout), nn.Linear(hidden_dim // 2, 1), nn.Sigmoid()
        )

    def forward(self, x: torch.Tensor, x_psych: torch.Tensor,
                adj: torch.Tensor) -> torch.Tensor:
        x_combined = torch.cat([x, x_psych], dim=-1)
        h = F.relu(self.node_proj(x_combined))
        # Average across relation-specific transforms
        h_rel = torch.stack([layer(h) for layer in self.relation_layers]).mean(0)
        h = self.dropout(F.relu(self.norm(torch.matmul(adj, h_rel) + h)))
        return self.classifier(h).squeeze(-1)


class GraphCHBaseline:
    """
    GraphCH baseline — cyber-human heterogeneous graph with psychological
    features; no temporal GCN or propagation modeling.
    """
    def __init__(self, input_dim: int = 64, psych_dim: int = 16,
                 hidden_dim: int = 256, num_relations: int = 4,
                 dropout: float = 0.3, lr: float = 0.001, epochs: int = 100):
        self.psych_dim = psych_dim
        self.model = GraphCHModel(input_dim, psych_dim, hidden_dim,
                                  num_relations, dropout)
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=lr,
                                          betas=(0.9, 0.999))
        self.criterion = nn.BCELoss()
        self.epochs = epochs
        self.name = 'GraphCH [15]'

    def fit(self, x: torch.Tensor, adj: torch.Tensor,
            y: torch.Tensor) -> 'GraphCHBaseline':
        N = x.size(0)
        x_psych = torch.zeros(N, self.psych_dim)  # placeholder psychological features
        self.model.train()
        for _ in range(self.epochs):
            self.optimizer.zero_grad()
            preds = self.model(x, x_psych, adj)
            loss = self.criterion(preds, y.float())
            loss.backward()
            self.optimizer.step()
        return self

    def predict(self, x: torch.Tensor, adj: torch.Tensor,
                threshold: float = 0.5) -> torch.Tensor:
        N = x.size(0)
        x_psych = torch.zeros(N, self.psych_dim)
        self.model.eval()
        with torch.no_grad():
            return (self.model(x, x_psych, adj) >= threshold).float()

    def predict_proba(self, x: torch.Tensor, adj: torch.Tensor) -> torch.Tensor:
        N = x.size(0)
        x_psych = torch.zeros(N, self.psych_dim)
        self.model.eval()
        with torch.no_grad():
            return self.model(x, x_psych, adj)
