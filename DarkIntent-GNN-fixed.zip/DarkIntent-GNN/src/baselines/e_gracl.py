"""
Baseline: E-GRACL [8] (Table 2, Table 10)
Lin et al. (2025). E-GRACL: An IoT intrusion detection system based on
graph neural networks. Journal of Supercomputing, 81, 42.
DOI: 10.1007/s11227-024-06471-5

Graph neural network with contrastive learning for intrusion detection.
No intent-level modeling or temporal propagation.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from .gat import GATModel


class EGRACLModel(nn.Module):
    """
    E-GRACL: GAT encoder with contrastive projection head.
    Contrastive loss encourages separation of malicious and benign embeddings.
    """
    def __init__(self, input_dim: int = 64, hidden_dim: int = 256,
                 proj_dim: int = 128, num_heads: int = 8, dropout: float = 0.3):
        super().__init__()
        self.encoder = GATModel(input_dim, hidden_dim, num_heads,
                                dropout=dropout)
        self.proj_head = nn.Sequential(
            nn.Linear(hidden_dim, proj_dim), nn.ReLU(),
            nn.Linear(proj_dim, proj_dim)
        )
        # For supervised inference, use a linear classifier
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, 1), nn.Sigmoid())
        self.gat = GATModel(input_dim, hidden_dim, num_heads, dropout=dropout)

    def forward(self, x: torch.Tensor, adj: torch.Tensor) -> torch.Tensor:
        return self.gat(x, adj)


class EGRACLBaseline:
    """E-GRACL baseline — contrastive GNN, no temporal or intent modeling."""

    def __init__(self, input_dim: int = 64, hidden_dim: int = 256,
                 num_heads: int = 8, dropout: float = 0.3,
                 lr: float = 0.001, epochs: int = 100):
        self.model = EGRACLModel(input_dim, hidden_dim,
                                  num_heads=num_heads, dropout=dropout)
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=lr,
                                          betas=(0.9, 0.999))
        self.criterion = nn.BCELoss()
        self.epochs = epochs
        self.name = 'E-GRACL [8]'

    def fit(self, x: torch.Tensor, adj: torch.Tensor,
            y: torch.Tensor) -> 'EGRACLBaseline':
        self.model.train()
        for _ in range(self.epochs):
            self.optimizer.zero_grad()
            preds = self.model(x, adj)
            loss = self.criterion(preds, y.float())
            loss.backward()
            self.optimizer.step()
        return self

    def predict(self, x: torch.Tensor, adj: torch.Tensor,
                threshold: float = 0.5) -> torch.Tensor:
        self.model.eval()
        with torch.no_grad():
            return (self.model(x, adj) >= threshold).float()

    def predict_proba(self, x: torch.Tensor, adj: torch.Tensor) -> torch.Tensor:
        self.model.eval()
        with torch.no_grad():
            return self.model(x, adj)
